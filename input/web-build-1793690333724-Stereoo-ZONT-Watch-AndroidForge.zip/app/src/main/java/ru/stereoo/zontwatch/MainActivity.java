package ru.stereoo.zontwatch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.wear.remote.interactions.RemoteActivityHelper;
import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Wear OS 2 compatible single-activity interface, styled for small circular screens. */
public final class MainActivity extends Activity {
    // Direct, user-supplied MAX contact profile. Do not shorten or substitute it.
    private static final String MAX_CONTACT_URL =
        "https://max.ru/u/f9LHodD0cOIvFUqFHruX6ZUwfTUbDrQ1kAskhE3eCqWuk0VTOJ-IygB7jsM";

    private static final int WHITE = Color.rgb(241, 250, 251);
    private static final int MUTED = Color.rgb(156, 179, 187);
    private static final int GREEN = Color.rgb(69, 229, 189);
    private static final int ORANGE = Color.rgb(255, 184, 95);
    private static final int RED = Color.rgb(255, 114, 131);
    private static final int BLUE = Color.rgb(90, 175, 248);
    private static final int BACKGROUND = Color.rgb(6, 14, 23);
    private static final int CARD = Color.rgb(18, 34, 46);
    private static final int EDGE = Color.rgb(43, 71, 83);

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ZontApi api = new ZontApi();
    private SecureStore store;
    private LinearLayout root;
    private TextView notice;
    private boolean busy;
    private JSONArray availableDevices;
    private JSONObject currentDevice;
    private ZontApi.Voltage currentVoltage;
    private long lastRefreshAt;
    private final Runnable refreshAfterCommand = this::refresh;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(BACKGROUND);
        store = new SecureStore(this);
        if (store.getToken().isEmpty()) showLogin();
        else { showDashboard(); refresh(); }
    }

    private int dp(float amount) {
        return (int) (amount * getResources().getDisplayMetrics().density + .5f);
    }

    private GradientDrawable background(int fill, int border, float radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(fill);
        shape.setCornerRadius(dp(radius));
        if (border != Color.TRANSPARENT) shape.setStroke(dp(1), border);
        return shape;
    }

    private LinearLayout column() {
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setGravity(Gravity.CENTER_HORIZONTAL);
        return view;
    }

    private void makePage() {
        notice = null;
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        scroll.setVerticalScrollBarEnabled(false);
        root = column();
        // Extra vertical inset keeps the header inside the circular display perimeter.
        root.setPadding(dp(22), dp(34), dp(22), dp(35));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);

        TextView monogram = text("⌁", 24, GREEN, true);
        monogram.setBackground(background(CARD, EDGE, 99));
        LinearLayout.LayoutParams badge = (LinearLayout.LayoutParams) monogram.getLayoutParams();
        badge.width = dp(38); badge.height = dp(38);
        badge.bottomMargin = dp(7);
        monogram.setLayoutParams(badge);
        text("ZONT", 22, WHITE, true);
        TextView sub = text("S T E R E O O   /   W A T C H", 8, GREEN, true);
        sub.setLetterSpacing(0.04f);
        gap(13);
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER);
        view.setIncludeFontPadding(true);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setPadding(dp(2), dp(1), dp(2), dp(1));
        root.addView(view, new LinearLayout.LayoutParams(-1, -2));
        return view;
    }

    private void gap(int height) {
        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private LinearLayout card() {
        LinearLayout card = column();
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(background(CARD, EDGE, 20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(0), dp(1), dp(0), dp(7));
        root.addView(card, lp);
        return card;
    }

    private TextView cardText(LinearLayout parent, String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(0), dp(1), dp(0), dp(1));
        parent.addView(t, new LinearLayout.LayoutParams(-1, -2));
        return t;
    }

    private void section(String label) {
        gap(7);
        TextView t = text(label, 11, MUTED, true);
        t.setLetterSpacing(0.055f);
        gap(5);
    }

    private Button button(String title, int tint, boolean primary, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(title);
        b.setTextSize(12.5f);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(primary ? BACKGROUND : WHITE);
        b.setMinHeight(dp(48));
        b.setPadding(dp(5), 0, dp(5), 0);
        b.setBackground(background(primary ? tint : CARD, primary ? Color.TRANSPARENT : tint, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.setMargins(dp(0), dp(2), dp(0), dp(5));
        root.addView(b, lp);
        b.setOnClickListener(v -> {
            if (!busy && listener != null) listener.onClick(v);
        });
        return b;
    }

    private EditText input(String hint, int type) {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setTextColor(WHITE);
        field.setHintTextColor(MUTED);
        field.setHint(hint);
        field.setTextSize(13.5f);
        field.setInputType(type);
        field.setGravity(Gravity.CENTER);
        field.setPadding(dp(6), 0, dp(6), 0);
        field.setBackground(background(CARD, EDGE, 15));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.setMargins(dp(0), dp(2), dp(0), dp(5));
        root.addView(field, lp);
        return field;
    }

    private void message(String value, int tint) {
        if (notice != null) {
            notice.setText(value);
            notice.setTextColor(tint);
        }
    }

    private void createMessage() {
        notice = text("", 11, MUTED, false);
    }

    private void showLogin() {
        makePage();
        currentDevice = null;
        currentVoltage = null;
        text("ВХОД В ZONT", 12, WHITE, true);
        text("Данные аккаунта", 10, MUTED, false);
        gap(9);
        EditText login = input("Логин ZONT", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        login.setText(store.getContact());
        EditText password = input("Пароль", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        button("ВОЙТИ", GREEN, true, v -> {
            String user = login.getText().toString().trim();
            String pass = password.getText().toString();
            if (user.isEmpty() || pass.isEmpty()) {
                message("Нужны логин и пароль", RED);
                return;
            }
            password.setText("");
            work("Подключаемся…", () -> api.authenticate(user, pass), token -> {
                try { store.putCredentials(user, token); }
                catch (Exception e) {
                    message("Ошибка защищённого хранилища", RED);
                    return;
                }
                showDashboard();
                refresh();
            });
        });
        createMessage();
        gap(7);
        text("🔐 Пароль не сохраняется", 10, MUTED, false);
        text("Для входа нужен интернет", 10, MUTED, false);
        footer();
    }

    private void statusPanel(String status, String engine, String auto, int accent) {
        LinearLayout panel = card();
        cardText(panel, "●  СОСТОЯНИЕ ОХРАНЫ", 10, MUTED, true);
        cardText(panel, status, 20, accent, true);
        cardText(panel, engine + "  ·  " + auto, 10, WHITE, false);
    }

    private void metricRow(String tempEngine, String tempCabin, String voltage) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        root.addView(row, new LinearLayout.LayoutParams(-1, -2));
        metricCell(row, "МОТОР", tempEngine == null ? "—" : tempEngine + "°", BLUE);
        metricCell(row, "САЛОН", tempCabin == null ? "—" : tempCabin + "°", BLUE);
        metricCell(row, "АКБ", voltage == null ? "—" : voltage + "В", GREEN);
    }

    private void metricCell(LinearLayout row, String name, String value, int color) {
        LinearLayout cell = column();
        cell.setPadding(dp(2), dp(7), dp(2), dp(7));
        cell.setBackground(background(CARD, EDGE, 13));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(2), 0, dp(2), 0);
        row.addView(cell, lp);
        cardText(cell, name, 8, MUTED, true);
        cardText(cell, value, 12, color, true);
    }

    private void showDashboard() {
        makePage();
        if (currentDevice == null) {
            text("Получаем данные…", 12, MUTED, false);
            gap(6);
        } else {
            String name = currentDevice.optString("name", "Автомобиль");
            String model = currentDevice.optString("devtype", "");
            text(name, 14, WHITE, true);
            if (!model.isEmpty()) text(model, 9, MUTED, false);
            gap(8);
            JSONObject io = currentDevice.optJSONObject("io");
            if (io == null) io = new JSONObject();
            String guard = io.optString("guard-state", "");
            String guardText = "enabled".equals(guard) ? "ПОД ОХРАНОЙ" :
                "disabled".equals(guard) ? "БЕЗ ОХРАНЫ" :
                "enabling".equals(guard) ? "ВКЛЮЧАЕТСЯ" : "НЕТ ДАННЫХ";
            boolean engineRunning = io.optBoolean("engine-state", false);
            String engineText = !io.has("engine-state") ? "Мотор: ?" :
                engineRunning ? "Мотор: работает" : "Мотор: стоп";
            JSONObject auto = io.optJSONObject("auto-ignition");
            String autoState = auto == null ? "" : auto.optString("state", "");
            String autoText = "enabled".equals(autoState) ? "Авто: вкл" :
                "enabling".equals(autoState) ? "Авто: пуск" :
                "disabled".equals(autoState) ? "Авто: выкл" : "Авто: ?";
            int accent = "enabled".equals(guard) ? GREEN :
                "disabled".equals(guard) ? ORANGE : MUTED;
            statusPanel(guardText, engineText, autoText, accent);

            String voltage = currentVoltage == null ? null :
                String.format(Locale.US, "%.1f", currentVoltage.volts);
            metricRow(temperature(currentDevice, "engine"),
                temperature(currentDevice, "cabin"), voltage);
            if (io.optBoolean("siren", false)) {
                gap(4);
                text("⚠  ТРЕВОГА / СИРЕНА", 12, RED, true);
            }
            if (lastRefreshAt > 0) {
                gap(3);
                text("Обновлено в " + new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                    .format(new Date(lastRefreshAt)), 9, MUTED, false);
            }
        }

        section("КОМАНДЫ");
        button("↻  Обновить состояние", BLUE, false, v -> refresh());
        if (currentDevice != null) {
            JSONObject io = currentDevice.optJSONObject("io");
            if (io == null) io = new JSONObject();
            boolean guardAvailable = io.has("guard-state");
            JSONObject auto = io.optJSONObject("auto-ignition");
            boolean autoAvailable = auto != null && auto.optBoolean("available", false);
            boolean engineRunning = io.optBoolean("engine-state", false);
            String autoState = auto == null ? "" : auto.optString("state", "");

            button("🔒  Поставить на охрану", GREEN, true, v -> confirm(Command.ARM))
                .setEnabled(guardAvailable);
            button("🔓  Снять с охраны", ORANGE, false, v -> confirm(Command.DISARM))
                .setEnabled(guardAvailable);
            button("▶  Запустить двигатель", GREEN, false, v -> confirm(Command.START))
                .setEnabled(autoAvailable && !engineRunning && "disabled".equals(autoState));
            button("■  Остановить двигатель", RED, false, v -> confirm(Command.STOP))
                .setEnabled(autoAvailable && ("enabled".equals(autoState) || "enabling".equals(autoState)));
            if (!autoAvailable) text("Автозапуск недоступен или не настроен", 10, MUTED, false);
        }
        section("НАСТРОЙКИ");
        button("Выбрать автомобиль", MUTED, false, v -> chooseDevice());
        button("Выйти из аккаунта", MUTED, false, v -> new AlertDialog.Builder(this)
            .setTitle("Выйти из ZONT?")
            .setMessage("Токен будет удалён с часов.")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Выйти", (dialog, which) -> {
                store.clear();
                availableDevices = null;
                showLogin();
            }).show());
        createMessage();
        text("После команды обновите состояние", 10, MUTED, false);
        footer();
    }

    private void footer() {
        gap(10);
        TextView credit = text("Разработчик: Жданов Александр", 10, MUTED, true);
        credit.setMaxLines(2);
        credit.setGravity(Gravity.CENTER);
        gap(5);
        button("✉  Связаться в MAX", BLUE, false, v -> openMaxOnPhone());
        text("Чат откроется на смартфоне", 9, MUTED, false);
        gap(3);
        text("Stereoo ZONT Watch · v0.2.1", 9, MUTED, false);
    }

    /** Browsable HTTPS URL is handled on the paired phone, normally by MAX if installed. */
    private void openMaxOnPhone() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(MAX_CONTACT_URL));
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        try {
            RemoteActivityHelper helper = new RemoteActivityHelper(this, executor);
            ListenableFuture<Void> request = helper.startRemoteActivity(intent);
            request.addListener(() -> {
                boolean sent;
                try {
                    request.get();
                    sent = true;
                } catch (Exception error) {
                    sent = false;
                }
                final boolean success = sent;
                ui.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    message(success ? "Откройте MAX на телефоне" :
                        "Телефон недоступен. Проверьте подключение.", success ? GREEN : RED);
                });
            }, executor);
        } catch (Exception e) {
            message("Не удалось открыть MAX. Проверьте связь с телефоном.", RED);
        }
    }

    private static String temperature(JSONObject device, String assignment) {
        JSONObject config = device.optJSONObject("temperature_conf");
        JSONObject io = device.optJSONObject("io");
        if (config == null || io == null) return null;
        JSONArray names = config.optJSONArray("assignments");
        JSONArray readings = io.optJSONArray("temperature");
        if (names == null || readings == null) return null;
        for (int i = 0; i < Math.min(names.length(), readings.length()); i++) {
            if (!assignment.equals(names.optString(i))) continue;
            JSONObject sensor = readings.optJSONObject(i);
            if (sensor != null && "ok".equals(sensor.optString("state"))) {
                return String.valueOf(sensor.optInt("value"));
            }
        }
        return null;
    }

    private interface Task<T> { T perform() throws Exception; }
    private interface Done<T> { void complete(T value); }

    private <T> void work(String progress, Task<T> task, Done<T> done) {
        if (busy) return;
        busy = true;
        message(progress, ORANGE);
        executor.submit(() -> {
            try {
                T value = task.perform();
                ui.post(() -> {
                    busy = false;
                    if (!isFinishing() && !isDestroyed()) done.complete(value);
                });
            } catch (Exception error) {
                ui.post(() -> {
                    busy = false;
                    if (isFinishing() || isDestroyed()) return;
                    if (error instanceof ZontApi.ApiException &&
                        (((ZontApi.ApiException) error).httpCode == 403 ||
                         ((ZontApi.ApiException) error).httpCode == 401)) {
                        store.clear();
                        showLogin();
                        message("Доступ ZONT истёк. Войдите снова.", RED);
                    } else {
                        message("Ошибка: " + error.getMessage(), RED);
                    }
                });
            }
        });
    }

    private void refresh() {
        if (busy || store.getToken().isEmpty()) return;
        String token = store.getToken();
        String contact = store.getContact();
        work("Загружаем состояние…", () -> {
            JSONArray devices = api.devices(token, contact);
            long selectedId = store.getDeviceId();
            JSONObject selected = findDevice(devices, selectedId);
            if (selected == null && devices.length() == 1) selected = devices.optJSONObject(0);
            ZontApi.Voltage voltage = null;
            if (selected != null) {
                try { voltage = api.latestVoltage(token, contact, idOf(selected)); }
                catch (Exception ignored) { /* Voltage is optional, never block core controls. */ }
            }
            return new DeviceData(devices, selected, voltage);
        }, data -> {
            availableDevices = data.devices;
            if (data.devices.length() == 0) {
                currentDevice = null;
                showDashboard();
                message("В аккаунте ZONT нет устройств", RED);
                return;
            }
            if (data.selected == null) {
                currentDevice = null;
                showDashboard();
                chooseDevice();
                return;
            }
            currentDevice = data.selected;
            currentVoltage = data.voltage;
            store.setDeviceId(idOf(currentDevice));
            lastRefreshAt = System.currentTimeMillis();
            showDashboard();
        });
    }

    private static long idOf(JSONObject object) {
        if (object == null) return -1L;
        return object.has("id") ? object.optLong("id", -1L) : object.optLong("device_id", -1L);
    }

    private static JSONObject findDevice(JSONArray array, long id) {
        if (array == null || id <= 0) return null;
        for (int i = 0; i < array.length(); i++) {
            JSONObject obj = array.optJSONObject(i);
            if (idOf(obj) == id) return obj;
        }
        return null;
    }

    private static final class DeviceData {
        final JSONArray devices;
        final JSONObject selected;
        final ZontApi.Voltage voltage;
        DeviceData(JSONArray devices, JSONObject selected, ZontApi.Voltage voltage) {
            this.devices = devices; this.selected = selected; this.voltage = voltage;
        }
    }

    private void chooseDevice() {
        if (availableDevices == null || availableDevices.length() == 0) {
            message("Сначала загрузите устройства", ORANGE);
            return;
        }
        String[] titles = new String[availableDevices.length()];
        for (int i = 0; i < titles.length; i++) {
            JSONObject dev = availableDevices.optJSONObject(i);
            titles[i] = (dev == null ? "Устройство" : dev.optString("name", "Устройство")) +
                " (" + (dev == null ? "?" : dev.optString("devtype", "ZONT")) + ")";
        }
        new AlertDialog.Builder(this)
            .setTitle("Выберите машину")
            .setItems(titles, (dialog, index) -> {
                JSONObject device = availableDevices.optJSONObject(index);
                if (device != null) {
                    store.setDeviceId(idOf(device));
                    currentDevice = device;
                    currentVoltage = null;
                    lastRefreshAt = 0;
                    showDashboard();
                    refresh();
                }
            })
            .setNegativeButton("Отмена", null)
            .show();
    }

    private enum Command { ARM, DISARM, START, STOP }

    private void confirm(Command command) {
        if (currentDevice == null || store.getDeviceId() <= 0) return;
        if (System.currentTimeMillis() - lastRefreshAt > 120_000L) {
            message("Данные устарели. Сначала обновите.", ORANGE);
            return;
        }
        String title;
        String explanation;
        switch (command) {
            case ARM:
                title = "Включить охрану?";
                explanation = "Отправить команду постановки на охрану?";
                break;
            case DISARM:
                title = "Снять с охраны?";
                explanation = "Машина станет незащищённой. Подтвердить?";
                break;
            case START:
                title = "Завести двигатель?";
                explanation = "Только на открытом воздухе! Не запускайте машину в гараже. " +
                    "Убедитесь, что автомобиль безопасно подготовлен к автозапуску.";
                break;
            default:
                title = "Остановить автозапуск?";
                explanation = "Остановится только двигатель, запущенный системой автозапуска.";
        }
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(explanation)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Подтвердить", (dialog, which) -> execute(command))
            .show();
    }

    private void execute(Command command) {
        String token = store.getToken();
        String contact = store.getContact();
        long device = store.getDeviceId();
        work("Отправляем команду…", () -> {
            switch (command) {
                case ARM: api.setGuard(token, contact, device, true); break;
                case DISARM: api.setGuard(token, contact, device, false); break;
                case START: api.setAutoIgnition(token, contact, device, true); break;
                case STOP: api.setAutoIgnition(token, contact, device, false); break;
            }
            return true;
        }, ignored -> {
            message("Команда принята сервером. Проверяем выполнение…", GREEN);
            ui.removeCallbacks(refreshAfterCommand);
            ui.postDelayed(refreshAfterCommand, 3500L);
        });
    }

    @Override protected void onDestroy() {
        ui.removeCallbacks(refreshAfterCommand);
        executor.shutdownNow();
        super.onDestroy();
    }
}
