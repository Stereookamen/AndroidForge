package ru.stereoo.morkovsk

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.content.Context

/**
 * Prototype of a supervised UI helper. No network calls, no credential storage,
 * no real-money purchases and no automatic ticket spending.
 * This service is bound to the Ozon app package in the XML configuration.
 */
class MorkovService : AccessibilityService() {
    companion object {
        const val OZON = "ru.ozon.app.android"
        @Volatile var current: MorkovService? = null
            private set
    }

    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("morkovsk", MODE_PRIVATE) }
    private val visitedTasks = mutableSetOf<String>()
    private var lastTickAt = 0L
    private var pendingTick = false
    private var overlay: LinearLayout? = null
    private var overlayLabel: TextView? = null
    private var overlayNext: Button? = null
    private val wm by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }

    override fun onServiceConnected() {
        super.onServiceConnected()
        current = this
        if (prefs.getBoolean("running", false)) {
            // Do not automatically resume automation after process restart.
            stopRun()
        }
    }

    override fun onDestroy() {
        current = null
        removeOverlay()
        super.onDestroy()
    }

    override fun onInterrupt() { stopRun() }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!prefs.getBoolean("running", false)) return
        if (event?.packageName?.toString() != OZON) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastTickAt < 600L || pendingTick) return
        pendingTick = true
        ui.postDelayed({
            pendingTick = false
            lastTickAt = SystemClock.elapsedRealtime()
            tick()
        }, 600)
    }

    fun startRun() {
        visitedTasks.clear()
        prefs.edit().putBoolean("running", true)
            .putString("phase", "Награда за посещение")
            .putString("status", "Открой Морковск. Ищу ежедневную награду.")
            .putInt("visits", 0).putInt("balance", -1).putInt("price", -1).apply()
        showOverlay()
        scheduleTick(1200)
    }

    fun stopRun() {
        prefs.edit().putBoolean("running", false)
            .putString("phase", "Остановлено")
            .putString("status", "Остановка по запросу пользователя.").apply()
        removeOverlay()
    }

    fun continueAfterBasket() {
        if (prefs.getString("phase", "") != "Твоя очередь: Лукошко") {
            setStatus("Нужно сначала завершить этап бесплатных заданий.")
            return
        }
        setPhase("Считываю баланс", "Лукошко завершено. Возвращаюсь на главный экран Морковска.")
        // After the user clicks Continue on a floating control they remain in Ozon.
        performGlobalAction(GLOBAL_ACTION_BACK)
        scheduleTick(1800)
    }

    /** Capture a narrow, opt-in diagnostic view. It never leaves the device unless shared. */
    fun scanNow() {
        val root = rootInActiveWindow
        if (root?.packageName?.toString() != OZON) {
            setStatus("Для сканирования сначала открой приложение Ozon с Морковском.")
            return
        }
        val nodes = flatten(root)
        saveDiagnostics(nodes)
        if (prefs.getString("phase", "") == "Считываю баланс") {
            analyzeScreen(nodes)
        } else {
            setStatus("Диагностика записана. Вернись в приложение и нажми «Скопировать диагностику».")
        }
    }

    private fun tick() {
        if (!prefs.getBoolean("running", false)) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != OZON) return
        val nodes = flatten(root)
        saveDiagnostics(nodes)
        when (prefs.getString("phase", "")) {
            "Награда за посещение" -> dailyReward(nodes)
            "Бесплатные задания" -> freeTasks(nodes)
            "Твоя очередь: Лукошко" -> { /* user operates the roulette */ }
            "Считываю баланс" -> analyzeScreen(nodes)
        }
    }

    private fun dailyReward(nodes: List<NodeLabel>) {
        val buttons = nodes.filter { it.label.contains("забрать", true) || it.label.contains("получить", true) }
        val daily = buttons.firstOrNull { candidate ->
            val pos = nodes.indexOf(candidate)
            val local = neighborhood(nodes, pos, 5)
            listOf("ежеднев", "посещ", "день", "награ", "морков").any { local.contains(it, true) } &&
                !blocked(local)
        }
        if (daily != null && safeClick(daily.node)) {
            setStatus("Нажал на награду за посещение. Проверяю задания.")
        } else {
            setStatus("Награда не обнаружена или недоступна. Проверяю задания.")
        }
        setPhase("Бесплатные задания", prefs.getString("status", "") ?: "")
        scheduleTick(1900)
    }

    private fun freeTasks(nodes: List<NodeLabel>) {
        if (prefs.getInt("visits", 0) >= 15) {
            pauseBasket(nodes, "Достигнут лимит 15 переходов за сеанс.")
            return
        }
        for ((index, candidate) in nodes.withIndex()) {
            if (!Regex("^посетить([\\s!]|$)", RegexOption.IGNORE_CASE).containsMatchIn(candidate.label.trim())) continue
            val context = neighborhood(nodes, index, 4)
            // Conservative: do not open any visit task whose nearby words
            // suggest spending money, registration, banking or subscriptions.
            if (blocked(context)) continue
            val rect = Rect().also { candidate.node.getBoundsInScreen(it) }
            val key = context.take(100) + "@" + rect.centerY()
            if (key in visitedTasks) continue
            visitedTasks.add(key)
            if (safeClick(candidate.node)) {
                val visits = prefs.getInt("visits", 0) + 1
                prefs.edit().putInt("visits", visits).apply()
                setStatus("Открыл бесплатный переход №$visits. Через 5 секунд вернусь к заданиям.")
                setPhase("Открыто задание", prefs.getString("status", "") ?: "")
                ui.postDelayed({
                    if (prefs.getBoolean("running", false) && prefs.getString("phase", "") == "Открыто задание") {
                        performGlobalAction(GLOBAL_ACTION_BACK)
                        setPhase("Бесплатные задания", "Вернулся после посещения. Проверяю оставшиеся задания.")
                        scheduleTick(1800)
                    }
                }, 5000)
                return
            }
        }
        pauseBasket(nodes, "Больше безопасных кнопок «Посетить» не найдено.")
    }

    private fun pauseBasket(nodes: List<NodeLabel>, reason: String) {
        val basket = nodes.firstOrNull { it.label.trim().equals("Лукошко", true) }
        if (basket != null) safeClick(basket.node)
        setPhase("Твоя очередь: Лукошко", "$reason Покрути бесплатное Лукошко самостоятельно. После этого нажми «Продолжить» в панели сверху.")
    }

    private fun analyzeScreen(nodes: List<NodeLabel>) {
        val lines = nodes.map { it.label.trim() }.filter { it.isNotBlank() }
        val combined = lines.joinToString("\n")
        val balance = parseBalance(lines)
        val ticketPrice = parsePrice(combined)
        prefs.edit().putInt("balance", balance ?: -1).putInt("price", ticketPrice ?: -1).apply()
        val summary = if (balance != null && ticketPrice != null && ticketPrice > 0) {
            "Баланс: $balance морковок, билет: $ticketPrice морковок. Можно купить ${balance / ticketPrice} билетов. Автопокупка выключена до проверки интерфейса."
        } else {
            "Нельзя надёжно прочитать баланс или цену билета. Нажми «Сканировать» на главном экране Морковска и пришли диагностику или скриншот."
        }
        setPhase("Готово", summary)
        prefs.edit().putBoolean("running", false).apply()
        removeOverlay()
    }

    private fun parseBalance(lines: List<String>): Int? {
        val digits = "([\\d\\s\\u00a0]{1,12})"
        for ((i, raw) in lines.withIndex()) {
            val lower = raw.lowercase()
            if (!lower.contains("баланс") && !lower.contains("моих морков") && !lower.contains("мои морков")) continue
            val section = (i..minOf(i + 2, lines.lastIndex)).joinToString(" ") { lines[it] }
            val m = Regex("(?:баланс|моих морковок|мои морковки)\\s*[:\\-]?\\s*$digits", RegexOption.IGNORE_CASE).find(section)
                ?: Regex("$digits\\s*(?:🥕|морковок|морковки)").find(section)
            val value = m?.groupValues?.getOrNull(1)?.replace(Regex("\\s"), "")?.toIntOrNull()
            if (value != null) return value
        }
        return null
    }

    private fun parsePrice(s: String): Int? {
        val patterns = listOf(
            Regex("(?:купить\\s+)?билет\\s+за\\s+([\\d\\s]{1,8})\\s*морков", RegexOption.IGNORE_CASE),
            Regex("билет\\s+(?:стоит|—|:)\\s*([\\d\\s]{1,8})\\s*морков", RegexOption.IGNORE_CASE)
        )
        return patterns.asSequence().mapNotNull { it.find(s)?.groupValues?.get(1)?.replace(Regex("\\s"), "")?.toIntOrNull() }.firstOrNull()
    }

    private fun blocked(text: String): Boolean = listOf(
        "₽", "руб", "купить товар", "заказ", "оплат", "оформ", "подписк", "рассроч",
        "кредит", "банк", "платн", "карт", "взнос", "покупк", "премиум"
    ).any { text.contains(it, ignoreCase = true) }

    private fun neighborhood(nodes: List<NodeLabel>, index: Int, distance: Int): String =
        nodes.subList(maxOf(0, index - distance), minOf(nodes.size, index + distance + 1))
            .joinToString(" ") { it.label }

    private fun safeClick(info: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = info
        repeat(5) {
            val currentNode = n ?: return false
            if (currentNode.isVisibleToUser && currentNode.isClickable && currentNode.isEnabled) {
                return currentNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            n = currentNode.parent
        }
        return false
    }

    private data class NodeLabel(val node: AccessibilityNodeInfo, val label: String)

    private fun flatten(root: AccessibilityNodeInfo): List<NodeLabel> {
        val out = mutableListOf<NodeLabel>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var scanned = 0
        while (stack.isNotEmpty() && scanned++ < 450) {
            val n = stack.removeLast()
            val label = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
            if (label.isNotBlank()) out.add(NodeLabel(n, label))
            for (i in n.childCount - 1 downTo 0) {
                n.getChild(i)?.let { stack.add(it) }
            }
        }
        return out
    }

    private fun saveDiagnostics(nodes: List<NodeLabel>) {
        // Only terms relevant to the game, limit output and mask long numbers.
        val keys = listOf("морков", "лукош", "билет", "баланс", "посет", "забрат", "получ", "рулет", "задани", "фортунат", "день")
        val reduced = nodes.map { it.label }
            .filter { label -> keys.any { label.contains(it, true) } || label.trim().matches(Regex("[0-9 ]{1,8}")) }
            .take(80)
            .map { it.take(140).replace(Regex("\\d{7,}"), "*******") }
        prefs.edit().putString("diagnostic", "Экран Ozon, Морковск Авто 0.1\n" + reduced.joinToString("\n")).apply()
    }

    private fun scheduleTick(ms: Long) = ui.postDelayed({ tick() }, ms)

    private fun setPhase(phase: String, message: String) {
        prefs.edit().putString("phase", phase).putString("status", message).apply()
        updateOverlay()
    }

    private fun setStatus(message: String) {
        prefs.edit().putString("status", message).apply()
        updateOverlay()
    }

    private fun showOverlay() {
        removeOverlay()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(35, 38, 57))
            setPadding(8, 4, 8, 4)
        }
        val label = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            text = "🥕 Сбор..."
            maxLines = 2
        }
        val next = Button(this).apply {
            text = "Готово"
            textSize = 11f
            visibility = android.view.View.GONE
            setOnClickListener { continueAfterBasket() }
        }
        val scan = Button(this).apply {
            text = "Скан"
            textSize = 11f
            setOnClickListener { scanNow() }
        }
        val stop = Button(this).apply {
            text = "Стоп"
            textSize = 11f
            setOnClickListener { stopRun() }
        }
        val dp = resources.displayMetrics.density
        fun width(value: Int) = (value * dp).toInt()
        bar.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(next, LinearLayout.LayoutParams(width(79), LinearLayout.LayoutParams.WRAP_CONTENT))
        bar.addView(scan, LinearLayout.LayoutParams(width(73), LinearLayout.LayoutParams.WRAP_CONTENT))
        bar.addView(stop, LinearLayout.LayoutParams(width(70), LinearLayout.LayoutParams.WRAP_CONTENT))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP; y = 32 }
        try {
            wm.addView(bar, lp)
            overlay = bar
            overlayLabel = label
            overlayNext = next
            updateOverlay()
        } catch (_: Exception) {
            // Overlay is optional; controls in MainActivity remain available.
        }
    }

    private fun updateOverlay() {
        overlayLabel?.text = "🥕 " + prefs.getString("phase", "Сбор")
        overlayNext?.visibility = if (prefs.getString("phase", "") == "Твоя очередь: Лукошко")
            android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun removeOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        overlayLabel = null
        overlayNext = null
    }
}
