package ru.stereoo.morkovsk

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val store by lazy { getSharedPreferences("morkovsk", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.accessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.openOzon).setOnClickListener { openOzon() }
        findViewById<Button>(R.id.start).setOnClickListener {
            if (MorkovService.current == null) {
                toast("Сначала включи спецвозможности для «Морковск Авто»")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                MorkovService.current?.startRun()
                openOzon()
            }
            updateStatus()
        }
        findViewById<Button>(R.id.continueBtn).setOnClickListener {
            MorkovService.current?.continueAfterBasket()
                ?: toast("Сначала включи спецвозможности")
            updateStatus()
        }
        findViewById<Button>(R.id.scan).setOnClickListener {
            updateStatus()
            toast("Для съёмки экрана нажми «Скан» на плавающей панели поверх Ozon")
        }
        findViewById<Button>(R.id.diagnostic).setOnClickListener {
            val diagnostic = store.getString("diagnostic", "") ?: ""
            if (diagnostic.isBlank()) {
                toast("Пока нет диагностики. Открой Морковск и нажми «Сканировать».")
            } else {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Морковск: диагностика", diagnostic))
                toast("Скопировано. Проверь текст перед отправкой: в нём могут быть видны данные Ozon.")
            }
        }
        findViewById<Button>(R.id.stop).setOnClickListener {
            MorkovService.current?.stopRun()
            updateStatus()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val enabled = MorkovService.current != null
        val running = store.getBoolean("running", false)
        val count = store.getInt("visits", 0)
        val balance = store.getInt("balance", -1)
        val price = store.getInt("price", -1)
        val total = if (balance >= 0 && price > 0) "\nБилетов возможно: ${balance / price}" else ""
        status.text = "Доступ: ${if (enabled) "включён ✓" else "не включён"}\n" +
            "Режим: ${if (running) "РАБОТАЕТ" else "остановлен"}\n" +
            "Этап: ${store.getString("phase", "-")}\n" +
            "Переходов по заданиям: $count\n" +
            "Баланс: ${if (balance >= 0) "$balance 🥕" else "не определён"}\n" +
            "Цена билета: ${if (price > 0) "$price 🥕" else "не определена"}$total\n\n" +
            store.getString("status", "Открой Морковск, затем начни сбор.")
    }

    private fun openOzon() {
        val link = Uri.parse("https://www.ozon.ru/gameapp/main?miniapp=regularDraw")
        val direct = Intent(Intent.ACTION_VIEW, link).apply {
            setPackage(MorkovService.OZON)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(direct)
        } catch (_: Exception) {
            val ozon = packageManager.getLaunchIntentForPackage(MorkovService.OZON)
            if (ozon != null) {
                startActivity(ozon)
                toast("Открой «Морковск» в Ozon вручную")
            } else {
                toast("Приложение Ozon не найдено")
            }
        }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
}
