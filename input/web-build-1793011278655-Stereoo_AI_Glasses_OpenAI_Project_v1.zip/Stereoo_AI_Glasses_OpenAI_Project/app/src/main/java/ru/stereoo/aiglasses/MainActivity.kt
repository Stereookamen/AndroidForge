package ru.stereoo.aiglasses

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var question: EditText
    private lateinit var answer: TextView
    private lateinit var photoStatus: TextView
    private lateinit var speech: TextToSpeech
    private var imageUri: Uri? = null
    private var imagePath: String? = null
    private val prefs by lazy { getSharedPreferences("stereoo_ai", MODE_PRIVATE) }
    private val apiKey: String get() = prefs.getString("openai_api_key", "").orEmpty()

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            imageUri = uri
            imagePath = null
            photoStatus.text = "Фото выбрано: ${uri.lastPathSegment ?: "изображение"}"
        }
    }
    private val voiceInput = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) {
                question.setText(text)
                sendQuestion()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speech = TextToSpeech(this, this)
        buildUi()
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Stereoo AI Glasses"
            textSize = 25f
        })
        layout.addView(Button(this).apply {
            text = "⚙ Настроить OpenAI API-ключ"
            setOnClickListener { showApiKeyDialog() }
        })
        question = EditText(this).apply {
            hint = "Задай вопрос о фотографии..."
            minLines = 2
            setText("Опиши, что изображено на фотографии.")
        }
        layout.addView(question)
        layout.addView(Button(this).apply {
            text = "Отправить вопрос"
            setOnClickListener { sendQuestion() }
        })
        layout.addView(Button(this).apply {
            text = "🎙 Спросить голосом"
            setOnClickListener { startVoiceInput() }
        })
        layout.addView(Button(this).apply {
            text = "📷 Выбрать фотографию"
            setOnClickListener { imagePicker.launch("image/*") }
        })
        photoStatus = TextView(this).apply {
            text = "Фото не выбрано. Также можно отправить фото сюда через меню «Поделиться»."
            textSize = 14f
        }
        layout.addView(photoStatus)
        layout.addView(Button(this).apply {
            text = "Очистить фото"
            setOnClickListener {
                imageUri = null
                imagePath = null
                photoStatus.text = "Фото очищено."
            }
        })
        answer = TextView(this).apply {
            text = "Готов к работе. Сначала укажи API-ключ OpenAI."
            textSize = 17f
            setPadding(0, 18, 0, 0)
        }
        layout.addView(answer)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val incomingPath = intent.getStringExtra("image_path") ?: intent.getStringExtra("path")
        val incomingUri = intent.getStringExtra("image_uri") ?: intent.getStringExtra("uri")
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val shared = if (android.os.Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
                }
                if (shared != null) { imageUri = shared; imagePath = null }
            }
            Intent.ACTION_VIEW -> {
                val uri = intent.data ?: incomingUri?.let { runCatching { Uri.parse(it) }.getOrNull() }
                if (uri != null && uri.scheme != "file") { imageUri = uri; imagePath = null }
            }
        }
        if (!incomingUri.isNullOrBlank()) {
            imageUri = runCatching { Uri.parse(incomingUri) }.getOrNull()
            imagePath = null
        } else if (!incomingPath.isNullOrBlank()) {
            imagePath = incomingPath
            imageUri = null
        } else if (intent.action == Intent.ACTION_VIEW && intent.data?.scheme == "file") {
            imagePath = intent.data?.path
            imageUri = null
        }
        val incomingQuestion = intent.getStringExtra("question") ?: intent.getStringExtra(Intent.EXTRA_TEXT)
        if (!incomingQuestion.isNullOrBlank()) question.setText(incomingQuestion)
        if (imageUri != null || !imagePath.isNullOrBlank()) {
            photoStatus.text = "Получена фотография извне: ${imageUri?.lastPathSegment ?: imagePath?.substringAfterLast('/') ?: "изображение"}"
        }
    }

    private fun showApiKeyDialog() {
        val field = EditText(this).apply {
            hint = "sk-..."
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(apiKey)
        }
        AlertDialog.Builder(this)
            .setTitle("OpenAI API key")
            .setMessage("Ключ хранится локально в настройках приложения. Не отправляй его другим людям и не публикуй в GitHub.")
            .setView(field)
            .setNegativeButton("Отмена", null)
            .setNeutralButton("Удалить ключ") { _, _ -> prefs.edit().remove("openai_api_key").apply(); answer.text = "API-ключ удалён." }
            .setPositiveButton("Сохранить") { _, _ ->
                val key = field.text.toString().trim()
                prefs.edit().putString("openai_api_key", key).apply()
                answer.text = if (key.isBlank()) "API-ключ не задан." else "API-ключ сохранён на этом устройстве."
            }.show()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = speech.setLanguage(Locale("ru", "RU"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                runOnUiThread { answer.text = "Русский голос TTS не установлен. Ответы будут показаны на экране." }
            }
        }
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Задай вопрос о фотографии")
        }
        try { voiceInput.launch(intent) } catch (_: Exception) {
            answer.text = "Голосовой ввод недоступен на устройстве."
        }
    }

    private fun sendQuestion() {
        val prompt = question.text.toString().trim().ifBlank { "Опиши, что изображено на фотографии." }
        val key = apiKey
        if (key.isBlank()) { answer.text = "Сначала нажми «Настроить OpenAI API-ключ»."; return }
        if (imageUri == null && imagePath.isNullOrBlank() && prompt.isBlank()) {
            answer.text = "Сначала задай вопрос или выбери фотографию."; return
        }
        answer.text = "Отправляю запрос в OpenAI..."
        thread {
            var connection: HttpURLConnection? = null
            try {
                val imageBytes = loadImageBytes()
                val inputContent = JSONArray().put(JSONObject().put("type", "input_text").put("text", prompt))
                if (imageBytes != null) {
                    require(imageBytes.size <= 20 * 1024 * 1024) { "Фотография слишком большая (более 20 МБ)." }
                    val mime = imageMimeType()
                    val dataUrl = "data:$mime;base64," + Base64.encodeToString(imageBytes, Base64.NO_WRAP)
                    inputContent.put(JSONObject().put("type", "input_image").put("image_url", dataUrl))
                }
                val body = JSONObject()
                    .put("model", "gpt-4.1-mini")
                    .put("input", JSONArray().put(JSONObject().put("role", "user").put("content", inputContent)))
                val conn = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Content-Type", "application/json")
                    connectTimeout = 20000
                    readTimeout = 60000
                    doOutput = true
                }
                connection = conn
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val detail = runCatching { JSONObject(responseText).optJSONObject("error")?.optString("message") }.getOrNull()
                    throw IllegalStateException("OpenAI HTTP $code${detail?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ""}")
                }
                val json = JSONObject(responseText)
                val result = StringBuilder()
                val output = json.optJSONArray("output") ?: JSONArray()
                for (i in 0 until output.length()) {
                    val item = output.optJSONObject(i) ?: continue
                    val content = item.optJSONArray("content") ?: continue
                    for (j in 0 until content.length()) {
                        val part = content.optJSONObject(j) ?: continue
                        if (part.optString("type") == "output_text") result.append(part.optString("text"))
                    }
                }
                val message = result.toString().trim().ifBlank { "OpenAI вернул пустой текстовый ответ." }
                runOnUiThread {
                    answer.text = message
                    if (::speech.isInitialized) speech.speak(message, TextToSpeech.QUEUE_FLUSH, null, "stereoo-answer")
                }
            } catch (e: Exception) {
                runOnUiThread { answer.text = "Не удалось отправить запрос: ${e.message ?: e.javaClass.simpleName}" }
            } finally { connection?.disconnect() }
        }
    }

    private fun loadImageBytes(): ByteArray? {
        val path = imagePath
        if (!path.isNullOrBlank()) {
            val file = File(path)
            require(file.isFile && file.canRead()) { "Файл фотографии недоступен: $path" }
            return file.readBytes()
        }
        val uri = imageUri ?: return null
        return contentResolver.openInputStream(uri)?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                total += n
                require(total <= 20 * 1024 * 1024) { "Фотография слишком большая (более 20 МБ)." }
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        } ?: throw IllegalStateException("Не удалось прочитать фотографию.")
    }

    private fun imageMimeType(): String {
        val uri = imageUri
        val fromResolver = uri?.let { contentResolver.getType(it) }
        if (!fromResolver.isNullOrBlank() && fromResolver.startsWith("image/")) return fromResolver
        val name = imagePath?.substringAfterLast('/')?.lowercase(Locale.ROOT).orEmpty()
        return when {
            name.endsWith(".png") -> "image/png"
            name.endsWith(".webp") -> "image/webp"
            name.endsWith(".gif") -> "image/gif"
            else -> "image/jpeg"
        }
    }

    override fun onDestroy() {
        if (::speech.isInitialized) { speech.stop(); speech.shutdown() }
        super.onDestroy()
    }
}
