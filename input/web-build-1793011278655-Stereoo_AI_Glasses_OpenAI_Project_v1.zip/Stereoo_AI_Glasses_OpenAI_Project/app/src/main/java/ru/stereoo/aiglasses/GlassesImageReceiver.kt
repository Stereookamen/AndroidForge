package ru.stereoo.aiglasses

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri

/** Optional hand-off endpoint for an app/automation that has already downloaded a glasses photo. */
class GlassesImageReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "ru.stereoo.aiglasses.AI_IMAGE") return
        val uriText = intent.getStringExtra("image_uri")
            ?: intent.getStringExtra("uri")
        val path = intent.getStringExtra("image_path")
            ?: intent.getStringExtra("path")
        val question = intent.getStringExtra("question") ?: "Опиши, что изображено на фотографии."
        val open = Intent(context, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            if (!uriText.isNullOrBlank()) putExtra("image_uri", uriText)
            if (!path.isNullOrBlank()) putExtra("image_path", path)
            putExtra("question", question)
            if (!uriText.isNullOrBlank()) {
                data = runCatching { Uri.parse(uriText) }.getOrNull()
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        context.startActivity(open)
    }
}
