package ru.stereoo.chatgptwatch;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.wear.remote.interactions.RemoteActivityHelper;
import com.google.android.gms.wearable.Wearable;
import com.google.common.util.concurrent.ListenableFuture;

/** Watch client for Wear OS 2+. User explicitly launches remote ChatGPT on phone. */
public class WatchActivity extends Activity {
    private TextView info;
    private Button launch;
    private boolean busy;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        drawUi();
        // If Wear OS started our app through the voice assistant shortcut, start immediately.
        if (isAssistantIntent(getIntent())) {
            main.postDelayed(this::startRemote, 250);
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (isAssistantIntent(intent)) startRemote();
    }

    private boolean isAssistantIntent(Intent intent) {
        if (intent == null) return false;
        String a = intent.getAction();
        return Intent.ACTION_ASSIST.equals(a)
            || "android.intent.action.VOICE_ASSIST".equals(a)
            || Intent.ACTION_VOICE_COMMAND.equals(a);
    }

    private void startRemote() {
        if (busy) return;
        busy = true;
        launch.setEnabled(false);
        info.setText("Связываюсь с телефоном…");
        Intent remote = new Intent(Intent.ACTION_VIEW,
            Uri.parse("stereoo://chatgpt/open"));
        remote.addCategory(Intent.CATEGORY_BROWSABLE);
        try {
            RemoteActivityHelper helper = new RemoteActivityHelper(this, main::post);
            ListenableFuture<Void> future = helper.startRemoteActivity(remote);
            future.addListener(() -> {
                try {
                    future.get();
                    info.setText("Запрос отправлен!\nПроверь смартфон.");
                } catch (Exception ex) {
                    info.setText("Не удалось открыть через Wear OS.\nПроверяю соединение…");
                    checkPairedPhone();
                } finally {
                    busy = false;
                    launch.setEnabled(true);
                }
            }, main::post);
        } catch (Exception ex) {
            info.setText("Ошибка запуска. Проверяю связь…");
            busy = false;
            launch.setEnabled(true);
            checkPairedPhone();
        }
    }

    // Diagnostic only: no hidden fallback that claims launch succeeded.
    private void checkPairedPhone() {
        Wearable.getNodeClient(this).getConnectedNodes()
            .addOnSuccessListener(nodes -> {
                if (nodes.isEmpty()) {
                    info.setText("Нет соединения с телефоном.\nПроверь Bluetooth и Wear OS.");
                } else {
                    info.setText("Телефон найден, но удалённый запуск не сработал.\nОткрой Bridge на телефоне и повтори.");
                }
            })
            .addOnFailureListener(e -> info.setText("Не удалось проверить соединение.\n" + e.getMessage()));
    }

    private void drawUi() {
        LinearLayout layout = new LinearLayout(this);
        layout.setGravity(Gravity.CENTER);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(28), dp(16), dp(28), dp(14));
        layout.setBackgroundColor(0xff080d19);
        TextView title = label("Stereoo AI", 21, Color.WHITE, true);
        layout.addView(title);
        TextView sub = label("ChatGPT на телефоне", 12, 0xff97abc7, false);
        layout.addView(sub);
        launch = new Button(this);
        launch.setText("ЗАПУСТИТЬ");
        launch.setTextColor(Color.WHITE);
        launch.setTextSize(13);
        launch.setAllCaps(false);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xff4555e9);
        bg.setCornerRadius(dp(45));
        launch.setBackground(bg);
        launch.setOnClickListener(v -> startRemote());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(160), dp(58));
        bp.topMargin = dp(18);
        layout.addView(launch, bp);
        info = label("Нажми, чтобы открыть ChatGPT на смартфоне", 11, 0xffc6d0e4, false);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(13);
        layout.addView(info, ip);
        setContentView(layout);
    }

    private TextView label(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s.replace("\\n", "\n"));
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }
}
