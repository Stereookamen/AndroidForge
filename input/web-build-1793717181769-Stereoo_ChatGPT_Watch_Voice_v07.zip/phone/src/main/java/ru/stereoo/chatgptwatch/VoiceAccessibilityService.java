package ru.stereoo.chatgptwatch;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Opt-in helper for the official ChatGPT UI. Only interacts on a recent explicit
 * user request; does not read/store messages or audio and does not send network traffic.
 *
 * v0.3: independent retry loop (v0.2 could indefinitely postpone retries when
 * accessibility events arrived continuously); tap-to-teach optional fallback.
 */
public class VoiceAccessibilityService extends AccessibilityService {
    private static final String PACKAGE = "com.openai.chatgpt";
    private static final String PREFS = "stereoo_voice";
    private static final String PENDING_SINCE = "pending_since";
    private static final String TRAIN_SINCE = "train_since";
    private static final String LAST_STATUS = "last_status";
    private static final String LAST_DEBUG = "last_debug";
    private static final String CX = "calibration_x";
    private static final String CY = "calibration_y";
    private static final String CW = "calibration_w";
    private static final String CH = "calibration_h";
    private static final long WINDOW_MS = 24000L;
    private static final long TRAIN_MS = 30000L;
    private static final long RETRY_MS = 520L;
    private static VoiceAccessibilityService instance;

    public static boolean isConnected() { return instance != null; }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable retry = this::tryClickVoice;
    private boolean retryScheduled;
    private long attempts;
    private long lastDebugTime;

    private SharedPreferences prefs() { return getSharedPreferences(PREFS, MODE_PRIVATE); }

    public static void arm(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(TRAIN_SINCE)
                .putLong(PENDING_SINCE, SystemClock.elapsedRealtime())
                .putString(LAST_STATUS, "Команда принята. Ожидаю окно ChatGPT…")
                .putString(LAST_DEBUG, "Проверка ещё не началась")
                .apply();
        VoiceAccessibilityService svc = instance;
        if (svc != null) svc.handler.post(() -> svc.scheduleRetry(0));
    }

    public static void learn(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(PENDING_SINCE)
                .putLong(TRAIN_SINCE, SystemClock.elapsedRealtime())
                .putString(LAST_STATUS, "Обучение: вручную нажми кнопку голосового разговора в ChatGPT (30 секунд).")
                .putString(LAST_DEBUG, "Жду доступного Android события нажатия на Voice")
                .apply();
    }

    public static void clear(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(PENDING_SINCE).remove(TRAIN_SINCE).apply();
    }

    public static String lastStatus(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(LAST_STATUS, "Проверка пока не проводилась");
    }

    public static String lastDebug(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(LAST_DEBUG, "Нет данных");
    }

    public static boolean calibrated(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(CX);
    }

    public static void forgetCalibration(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(CX).remove(CY).remove(CW).remove(CH)
                .putString(LAST_STATUS, "Обучение сброшено. Нажатие по координатам отключено.")
                .apply();
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        prefs().edit().putString(LAST_DEBUG, "Служба Android подключена. Ожидаю команду часов.").apply();
        scheduleRetry(50);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null
                || !PACKAGE.contentEquals(event.getPackageName())) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            captureTrainingTap(event);
        }
        // NEVER cancel a previous scheduled attempt here! ChatGPT may send a
        // continuous stream of TYPE_WINDOW_CONTENT_CHANGED events.
        if (prefs().getLong(PENDING_SINCE, 0L) != 0L) scheduleRetry(100);
    }

    @Override public void onInterrupt() { stopRetry(); }
    @Override public boolean onUnbind(android.content.Intent intent) {
        stopRetry();
        if (instance == this) instance = null;
        return super.onUnbind(intent);
    }
    @Override public void onDestroy() {
        stopRetry();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    private void scheduleRetry(long delay) {
        if (retryScheduled) return;
        retryScheduled = true;
        handler.postDelayed(retry, delay);
    }

    private void stopRetry() {
        retryScheduled = false;
        handler.removeCallbacks(retry);
    }

    private void tryClickVoice() {
        retryScheduled = false;
        SharedPreferences p = prefs();
        long since = p.getLong(PENDING_SINCE, 0);
        if (since == 0L) return;
        long elapsed = SystemClock.elapsedRealtime() - since;
        if (elapsed < 0 || elapsed > WINDOW_MS) {
            p.edit().remove(PENDING_SINCE)
                    .putString(LAST_STATUS, "За 24 секунды кнопку Voice найти не удалось. Используй ОБУЧИТЬ КНОПКУ.")
                    .apply();
            return;
        }

        attempts++;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        try {
            if (root == null) {
                statusRateLimited("Ожидаю доступное окно ChatGPT…", "Корень активного окна недоступен");
            } else if (root.getPackageName() == null || !PACKAGE.contentEquals(root.getPackageName())) {
                statusRateLimited("Ожидаю окно ChatGPT…", "На экране другое приложение: " + root.getPackageName());
            } else {
                AccessibilityNodeInfo target = findVoiceButton(root, 0);
                if (target != null) {
                    boolean clicked = target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    if (clicked) {
                        p.edit().remove(PENDING_SINCE)
                                .putString(LAST_STATUS, "✅ Нажата доступная кнопка Voice. Голосовой режим должен открыться.")
                                .putString(LAST_DEBUG, "Кнопка Voice найдена через специальные возможности")
                                .apply();
                        return;
                    }
                }
                // After the UI settles, optional explicitly taught gesture can
                // work even if the Voice icon has no accessible label.
                if (elapsed > 1700 && calibrated(this) && tryCalibratedGesture(root)) return;
                if (elapsed > 500) {
                    String report = bottomRightControls(root);
                    statusRateLimited("ChatGPT открыт. Ищу кнопку Voice…", report);
                }
            }
        } finally {
            if (root != null) root.recycle();
        }
        scheduleRetry(RETRY_MS);
    }

    private void statusRateLimited(String status, String debug) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastDebugTime < 850L) return;
        lastDebugTime = now;
        prefs().edit().putString(LAST_STATUS, status)
                .putString(LAST_DEBUG, debug).apply();
    }

    private boolean tryCalibratedGesture(AccessibilityNodeInfo root) {
        SharedPreferences p = prefs();
        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels;
        int oldW = p.getInt(CW, 0), oldH = p.getInt(CH, 0);
        if (oldW < 1 || oldH < 1 || width < 1 || height < 1
                || Math.abs((width / (float)height) - (oldW / (float)oldH)) > .025f) {
            statusRateLimited("Поворот/размер экрана изменился. Обучи кнопку заново.", "Калибровка только для прежней ориентации");
            return false;
        }
        float x = p.getFloat(CX, -1f) * width;
        float y = p.getFloat(CY, -1f) * height;
        if (x < width * .50f || y < height * .50f || x > width || y > height) return false;
        // Require a visible ChatGPT root with at least one node in the intended region.
        // Do not blindly touch another app or a system permission dialog.
        if (root.getWindowId() < 0) return false;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 75))
                .build();
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                p.edit().remove(PENDING_SINCE)
                        .putString(LAST_STATUS, "✅ Выполнено обученное нажатие Voice. Проверь голосовой режим.")
                        .putString(LAST_DEBUG, "Касание по ранее обученной позиции, если интерфейс изменился — сбрось обучение")
                        .apply();
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                p.edit().remove(PENDING_SINCE)
                        .putString(LAST_STATUS, "Жест отменён Android. Попробуй снова при разблокированном экране.")
                        .apply();
            }
        }, handler);
        if (accepted) return true;
        statusRateLimited("Android отклонил жест. Кнопка Voice не нажата.", "dispatchGesture вернул false");
        return false;
    }

    private void captureTrainingTap(AccessibilityEvent event) {
        SharedPreferences p = prefs();
        long since = p.getLong(TRAIN_SINCE, 0);
        if (since == 0L) return;
        if (SystemClock.elapsedRealtime() - since > TRAIN_MS) {
            p.edit().remove(TRAIN_SINCE)
                    .putString(LAST_STATUS, "Не увидел нажатие Voice за 30 секунд. Вернись в Bridge для диагностики.")
                    .apply();
            return;
        }
        AccessibilityNodeInfo source = event.getSource();
        if (source == null) {
            p.edit().putString(LAST_DEBUG, "Приложение прислало нажатие, но без доступных координат").apply();
            return;
        }
        try {
            Rect r = new Rect();
            source.getBoundsInScreen(r);
            int width = getResources().getDisplayMetrics().widthPixels;
            int height = getResources().getDisplayMetrics().heightPixels;
            if (r.isEmpty() || width <= 0 || height <= 0) return;
            float x = r.exactCenterX() / width;
            float y = r.exactCenterY() / height;
            // This is intentionally restricted to lower-right composer area.
            if (x < .53f || y < .52f || x > 1f || y > 1f) return;
            String label = nodeLabel(source).toLowerCase(Locale.ROOT);
            if (has(label, "dictat", "диктов", "голосовой ввод", "voice input", "send", "отправ")) {
                p.edit().putString(LAST_DEBUG, "Нажата кнопка диктовки или отправки, обучение пропущено").apply();
                return;
            }
            p.edit().remove(TRAIN_SINCE)
                    .putFloat(CX, x).putFloat(CY, y)
                    .putInt(CW, width).putInt(CH, height)
                    .putString(LAST_STATUS, "✅ Положение кнопки сохранено. Теперь проверь запуск с часов.")
                    .putString(LAST_DEBUG, "Обучена точка: " + Math.round(x * 100) + "% ширины, " + Math.round(y * 100) + "% высоты")
                    .apply();
        } finally { source.recycle(); }
    }

    private AccessibilityNodeInfo findVoiceButton(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 42) return null;
        if (isVoiceControl(node)) {
            AccessibilityNodeInfo cur = node;
            for (int i = 0; i < 4 && cur != null; ++i) {
                if (cur.isEnabled() && cur.isClickable() && cur.isVisibleToUser()) return cur;
                cur = cur.getParent();
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            AccessibilityNodeInfo result = findVoiceButton(child, depth + 1);
            if (result != null) return result;
            child.recycle();
        }
        return null;
    }

    private boolean isVoiceControl(AccessibilityNodeInfo node) {
        if (!node.isVisibleToUser() || !node.isEnabled()) return false;
        String s = nodeLabel(node).toLowerCase(Locale.ROOT);
        if (s.length() == 0) return false;
        if (has(s, "диктов", "dictat", "speech-to-text", "transcrib", "voice input",
                "голосовой ввод", "записать аудио", "record audio", "microphone", "микрофон")) return false;
        boolean phrase = has(s, "voice mode", "voice conversation", "voice chat", "start voice",
                "start live", "start speaking", "start conversation", "talk with chatgpt",
                "talk to chatgpt", "голосовой режим", "голосовой разговор", "голосовой чат",
                "голосовой диалог", "начать голос", "начать разговор", "говорить с chatgpt",
                "общаться голосом", "начать общение");
        boolean shortLabel = s.equals("voice") || s.equals("голос") || s.equals("live")
                || s.equals("voice button") || s.equals("голосовая беседа");
        if (!phrase && !shortLabel) return false;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        if (bounds.isEmpty()) return false;
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        return bounds.centerY() > h * .51f && bounds.centerX() > w * .43f;
    }

    // Only controls at bottom right; never log full ChatGPT text or user messages.
    private String bottomRightControls(AccessibilityNodeInfo root) {
        List<String> labels = new ArrayList<>();
        collectControlLabels(root, 0, labels);
        if (labels.isEmpty()) return "ChatGPT виден, но метки кнопок в нижнем правом углу Android не показывает";
        return "Кнопки справа внизу: " + android.text.TextUtils.join(" | ", labels);
    }

    private void collectControlLabels(AccessibilityNodeInfo node, int depth, List<String> labels) {
        if (node == null || depth > 35 || labels.size() >= 8) return;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        if (node.isVisibleToUser() && node.isClickable() && !r.isEmpty()
                && r.centerX() > w * .55 && r.centerY() > h * .55) {
            String label = nodeLabel(node).replaceAll("[\\r\\n]", " ");
            String clazz = node.getClassName() == null ? "" : node.getClassName().toString();
            if (!clazz.contains("EditText") && !label.isEmpty() && label.length() < 58) {
                labels.add(label);
            }
        }
        for (int i = 0; i < node.getChildCount() && labels.size() < 8; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            collectControlLabels(child, depth+1, labels);
            child.recycle();
        }
    }

    private String nodeLabel(AccessibilityNodeInfo node) {
        CharSequence desc = node.getContentDescription();
        CharSequence text = node.getText();
        return ((desc == null ? "" : desc.toString()) + " "
                + (text == null ? "" : text.toString())).trim();
    }
    private boolean has(String s, String... keys) {
        for (String k : keys) if (s.contains(k)) return true;
        return false;
    }
}
