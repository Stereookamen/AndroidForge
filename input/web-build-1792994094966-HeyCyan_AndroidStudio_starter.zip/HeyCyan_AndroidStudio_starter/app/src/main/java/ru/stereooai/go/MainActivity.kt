package ru.stereooai.go

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** Temporary launcher shell. HeyCyan features are NOT ported into this scaffold yet. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 19, 34)
        window.navigationBarColor = Color.rgb(16, 19, 34)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(16, 19, 34))
        }
        val title = TextView(this).apply {
            text = "AI Stereoo"
            textSize = 30f
            setTextColor(Color.rgb(0, 215, 255))
            gravity = Gravity.CENTER
        }
        val body = TextView(this).apply {
            text = "Стартовый проект создан.\nФункции HeyCyan ещё не перенесены.\nСледующий этап: декомпиляция и перенос Bluetooth, камеры и AI."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(body)
        setContentView(root)
    }
}
