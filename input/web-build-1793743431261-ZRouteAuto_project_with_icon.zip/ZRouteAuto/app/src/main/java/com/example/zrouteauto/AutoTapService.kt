package com.example.zrouteauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class AutoTapService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private val loop = object : Runnable {
        override fun run() {
            if (!running || !requestRun || busy) return
            val p = getSharedPreferences("macro", MODE_PRIVATE)
            val x1 = p.getInt("x1", 360).toFloat()
            val y1 = p.getInt("y1", 760).toFloat()
            val x2 = p.getInt("x2", 360).toFloat()
            val y2 = p.getInt("y2", 1400).toFloat()
            val pause = p.getLong("pause", 20_000L)
            busy = true
            tap(x1, y1) {
                handler.postDelayed({
                    if (!running || !requestRun) { busy = false; return@postDelayed }
                    tap(x2, y2) {
                        busy = false
                        if (running && requestRun) handler.postDelayed(this, pause)
                    }
                }, 1200)
            }
        }
    }

    private fun tap(x: Float, y: Float, done: () -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) = done()
            override fun onCancelled(gestureDescription: GestureDescription?) = done()
        }, null)
    }

    override fun onServiceConnected() { super.onServiceConnected(); handler.post(loop) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (running && requestRun && !busy) handler.post(loop)
    }
    override fun onInterrupt() { running = false; requestRun = false }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    companion object {
        @Volatile var running = false
        @Volatile var requestRun = false
    }
}
