#!/usr/bin/env python3
import argparse, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path
import xml.etree.ElementTree as ET

ANDROID = "{http://schemas.android.com/apk/res/android}"
ET.register_namespace("android", "http://schemas.android.com/apk/res/android")

def run(cmd, cwd=None):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), cwd=cwd, check=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--helper", required=True)
    ap.add_argument("--apktool", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--sdk", required=True)
    args = ap.parse_args()
    base, helper, apktool, out, sdk = map(Path, (args.base, args.helper, args.apktool, args.out, args.sdk))
    if not base.is_file() or base.stat().st_size < 10_000_000: raise SystemExit("Original base.apk missing or unexpectedly small.")
    if not helper.is_file(): raise SystemExit("Compiled helper APK missing.")
    work = out.parent / "heycyan_patch_work"
    if work.exists(): shutil.rmtree(work)
    work.mkdir(parents=True)
    decoded = work / "original"
    helper_decoded = work / "helper"
    run(["java", "-jar", apktool, "d", "-f", base, "-o", decoded])
    run(["java", "-jar", apktool, "d", "-f", helper, "-o", helper_decoded])

    # Patch the one original voice GPT call, preserving its register layout.
    targets = list(decoded.glob("smali*/T1/F.smali"))
    if len(targets) != 1: raise SystemExit(f"Expected one T1/F.smali, found {len(targets)}")
    smali = targets[0]
    source = smali.read_text(encoding="utf-8")
    pattern = re.compile(r"(?m)^(\s*)invoke-virtual/range (\{[^}]+\}), LD2/J;->r\(JLjava/lang/String;Ljava/lang/String;ZI\)V\s*$")
    source, count = pattern.subn(
        r"\1invoke-static/range \2, Lcom/stereoo/ai/OpenAIResponsesBridge;->ask(Ljava/lang/Object;JLjava/lang/String;Ljava/lang/String;ZI)V",
        source
    )
    if count != 1:
        raise SystemExit(f"Expected exactly one original voice-chat call to redirect, patched {count}; no APK emitted.")
    smali.write_text(source, encoding="utf-8")

    # Keep the ORIGINAL MMKV Java classes from HeyCyan. The original class has
    # app-specific API methods (notably p(Application)) and a six-argument
    # jniInitialize signature. Replacing it with helper's MMKV 2.4.2 Java classes
    # caused NoSuchMethodError at GlassApplication.onCreate(). Only the matching
    # native library is supplied by the helper APK below.
    original_mmkv_classes = []
    for original_smali in decoded.glob("smali*"):
        candidate = original_smali / "com" / "tencent" / "mmkv" / "MMKV.smali"
        if candidate.is_file():
            original_mmkv_classes.append(candidate)
    if len(original_mmkv_classes) != 1:
        raise SystemExit(f"Expected exactly one original MMKV.smali, found {len(original_mmkv_classes)}")
    original_mmkv_text = original_mmkv_classes[0].read_text(encoding="utf-8", errors="replace")
    if not re.search(r"(?m)^\.method\s+public static p\(Landroid/app/Application;\)Ljava/lang/String;", original_mmkv_text):
        raise SystemExit("Original MMKV.smali is missing p(Application); refusing to replace/patch APK.")
    # Smali descriptors may contain no spaces; assert the six-argument native method.
    if not re.search(r"(?m)^\.method\s+private static native jniInitialize\(Ljava/lang/String;Ljava/lang/String;IZ ZJ\)V", original_mmkv_text) and \
       not re.search(r"(?m)^\.method\s+private static native jniInitialize\(Ljava/lang/String;Ljava/lang/String;IZZJ\)V", original_mmkv_text):
        raise SystemExit("Original MMKV.smali does not contain expected six-argument jniInitialize; check native-library compatibility.")
    print(f"Preserving original HeyCyan MMKV Java API: {original_mmkv_classes[0]}", flush=True)

    # JNI_OnLoad registers a native-method table for the exact MMKV Java API
    # version shipped beside the helper's libmmkv.so. The original HeyCyan
    # class has the same six-argument jniInitialize but is missing several
    # native declarations introduced by that native version. RegisterNatives
    # fails (JNI_ERR / -4) if any table entry is absent. Add only the missing
    # declarations; retain all original app-facing methods and p(Application).
    helper_mmkv_smali = helper_decoded / "smali" / "com" / "tencent" / "mmkv" / "MMKV.smali"
    if not helper_mmkv_smali.is_file():
        raise SystemExit(f"Helper MMKV.smali not found: {helper_mmkv_smali}")
    helper_mmkv_text = helper_mmkv_smali.read_text(encoding="utf-8", errors="replace")

    def native_method_keys(text):
        keys = set()
        for line in text.splitlines():
            line = line.strip()
            if not line.startswith(".method") or " native " not in line:
                continue
            m = re.search(r"\s([^\s(]+\([^)]*\).+)$", line)
            if m:
                keys.add(m.group(1))
        return keys

    original_keys = native_method_keys(original_mmkv_text)
    helper_keys = native_method_keys(helper_mmkv_text)
    missing_keys = helper_keys - original_keys
    if missing_keys:
        blocks = []
        for line in helper_mmkv_text.splitlines():
            stripped = line.strip()
            if not stripped.startswith(".method") or " native " not in stripped:
                continue
            m = re.search(r"\s([^\s(]+\([^)]*\).+)$", stripped)
            if m and m.group(1) in missing_keys:
                blocks.append(line + "\n.end method")
        if len(blocks) != len(missing_keys):
            raise SystemExit(f"Could not construct all missing MMKV native declarations: expected {len(missing_keys)}, got {len(blocks)}")
        original_mmkv_text = original_mmkv_text.rstrip() + "\n\n    # MMKV native declarations required by the bundled libmmkv.so\n" + "\n\n".join(blocks) + "\n"
        original_mmkv_classes[0].write_text(original_mmkv_text, encoding="utf-8")
    if helper_keys - native_method_keys(original_mmkv_text):
        raise SystemExit("Original MMKV class still lacks native methods required by bundled libmmkv.so.")
    print(f"Added {len(missing_keys)} native registration declarations for helper MMKV: {sorted(missing_keys)}", flush=True)

    # Use the native MMKV 2.4.2 libraries from the SAME helper APK whose
    # Java API we previously tested. The restored original HeyCyan native
    # binaries are older and register jniInitialize(String,String,int,boolean),
    # while this original HeyCyan Java class calls the six-argument method.
    # Mixing those versions makes JNI_OnLoad return JNI_ERR (-4) at startup.
    helper_native_root = helper_decoded / "lib"
    copied_native = []
    for abi_dir in helper_native_root.iterdir() if helper_native_root.exists() else []:
        if not abi_dir.is_dir():
            continue
        native_lib = abi_dir / "libmmkv.so"
        if native_lib.is_file():
            target_abi = decoded / "lib" / abi_dir.name
            target_abi.mkdir(parents=True, exist_ok=True)
            shutil.copy2(native_lib, target_abi / "libmmkv.so")
            copied_native.append(f"{abi_dir.name}/libmmkv.so")
    if not copied_native:
        raise SystemExit("MMKV native libraries were not found inside the helper APK; refusing to build.")
    print(f"Using MMKV native binaries from matching helper dependency: {copied_native}", flush=True)

    # Inject helper classes into a new dex tree; original APK currently has one classes.dex.
    helper_smali_dirs = sorted(helper_decoded.glob("smali*"))
    if not helper_smali_dirs: raise SystemExit("Could not find helper smali output.")
    destination = decoded / "smali_classes2"
    destination.mkdir(exist_ok=True)
    copied_ai = 0
    # Gradle/apktool can distribute one Java package across multiple dex/smali
    # directories. Merge files by filename; never delete a package while iterating
    # because that silently drops classes from earlier dex directories.
    target_ai_dir = destination / "com" / "stereoo" / "ai"
    target_ai_dir.mkdir(parents=True, exist_ok=True)
    for helper_smali in helper_smali_dirs:
        package_dir = helper_smali / "com" / "stereoo" / "ai"
        if package_dir.exists():
            for class_file in package_dir.rglob("*.smali"):
                relative = class_file.relative_to(package_dir)
                target_file = target_ai_dir / relative
                target_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(class_file, target_file)
                copied_ai += 1
    if copied_ai < 2: raise SystemExit(f"Expected bridge/settings classes; copied {copied_ai}")
    print(f"Injected helper classes: AI={copied_ai}; preserved original MMKV Java classes", flush=True)

    # Merge activity and internet permission into the original manifest.
    # Set the requested standalone package/version on the rebuilt HeyCyan app.
    manifest_path = decoded / "AndroidManifest.xml"
    tree = ET.parse(manifest_path)
    root = tree.getroot()
    root.set("package", "com.stereoo.ai")
    root.set(ANDROID + "versionCode", "1")

    # The original HeyCyan APK declares a package-scoped dynamic receiver
    # permission using its old application ID. When installing the patched app
    # alongside the original, Android rejects the APK with
    # INSTALL_FAILED_DUPLICATE_PERMISSION because the original package owns it.
    # Rename the declaration AND every manifest reference to our new app ID.
    old_dynamic_permission = (
        "com.glasssutdio.wear.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION"
    )
    new_dynamic_permission = (
        "com.stereoo.ai.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION"
    )
    renamed_permission_refs = 0
    for element in root.iter():
        if element.get(ANDROID + "name") == old_dynamic_permission:
            element.set(ANDROID + "name", new_dynamic_permission)
            renamed_permission_refs += 1
    if renamed_permission_refs == 0:
        print(
            "WARNING: original dynamic receiver permission not found in manifest; "
            "checking rebuilt manifest for stale reference",
            flush=True,
        )
    if any(
        element.get(ANDROID + "name") == old_dynamic_permission
        for element in root.iter()
    ):
        raise SystemExit("Stale HeyCyan dynamic receiver permission remains in manifest")
    print(
        f"Renamed dynamic receiver permission references: {renamed_permission_refs}",
        flush=True,
    )
    root.set(ANDROID + "versionName", "1.0")
    # The supplied HeyCyan base.apk was extracted from a split APK set.
    # Remove split-only attributes so the rebuilt APK can be installed as one file.
    root.attrib.pop(ANDROID + "requiredSplitTypes", None)
    root.attrib.pop(ANDROID + "splitTypes", None)
    # Apktool rebuilds native .so files compressed by default. The original manifest
    # has extractNativeLibs=false, which requires native libraries to be uncompressed
    # and correctly aligned in the APK. Set true so Android extracts the bundled MMKV
    # library during installation instead of rejecting the APK.
    application = root.find("application")
    if application is None: raise SystemExit("Decoded manifest has no <application>.")
    application.set(ANDROID + "extractNativeLibs", "true")
    has_internet = any(el.get(ANDROID + "name") == "android.permission.INTERNET" for el in root.findall("uses-permission"))
    if not has_internet:
        perm = ET.Element("uses-permission")
        perm.set(ANDROID + "name", "android.permission.INTERNET")
        root.insert(list(root).index(application), perm)
    activity_name = "com.stereoo.ai.OpenAISettingsActivity"
    if not any(el.get(ANDROID + "name") == activity_name for el in application.findall("activity")):
        activity = ET.SubElement(application, "activity")
        activity.set(ANDROID + "name", activity_name)
        activity.set(ANDROID + "exported", "false")
        activity.set(ANDROID + "label", "Stereoo AI · OpenAI")
        activity.set(ANDROID + "theme", "@android:style/Theme.Material.Light.NoActionBar")
    application.set(ANDROID + "label", "Stereoo AI")
    tree.write(manifest_path, encoding="utf-8", xml_declaration=True)

    unsigned = work / "patched-unsigned.apk"
    run(["java", "-jar", apktool, "b", decoded, "-o", unsigned])

    # Validate the rebuilt APK before signing: preserve original MMKV API in any DEX,
    # and package the matching native library. Do not assume MMKV must be in classes2.dex.
    import zipfile
    with zipfile.ZipFile(unsigned, "r") as built_apk:
        names = set(built_apk.namelist())
        dex_names = sorted(n for n in names if re.fullmatch(r"classes(?:[2-9][0-9]*)?\.dex", n))
        if not dex_names:
            raise SystemExit("Rebuilt APK has no DEX files.")
        all_dex = b"\n".join(built_apk.read(n) for n in dex_names)
        if b"com/tencent/mmkv/MMKV" not in all_dex:
            raise SystemExit("Rebuilt APK lost original MMKV class; refusing to sign APK.")
        # p(Application) must remain present in original smali and not be replaced by helper MMKV.
        native_entries = [n for n in names if re.fullmatch(r"lib/[^/]+/libmmkv\.so", n)]
        if not native_entries:
            raise SystemExit("Rebuilt APK contains no lib/<abi>/libmmkv.so; refusing to emit APK.")
        expected_native = {f"lib/{entry}" for entry in copied_native}
        if not expected_native.issubset(names):
            raise SystemExit(f"Rebuilt APK is missing helper MMKV native entries: {sorted(expected_native - names)}")
        print(f"Pre-sign validation passed: DEX={dex_names}; original MMKV Java preserved; helper MMKV native libs={native_entries}", flush=True)

    build_tools = sdk / "build-tools"
    versions = sorted([p for p in build_tools.iterdir() if p.is_dir()], key=lambda p: tuple(int(x) if x.isdigit() else 0 for x in p.name.split(".")))
    if not versions: raise SystemExit(f"No Android build-tools found under {build_tools}")
    bt = versions[-1]
    zipalign = bt / "zipalign"
    apksigner = bt / "apksigner"
    if not zipalign.is_file() or not apksigner.is_file(): raise SystemExit("zipalign/apksigner not found in Android build-tools.")
    aligned = work / "patched-aligned.apk"
    run([zipalign, "-f", "-p", "4", unsigned, aligned])
    keystore = work / "androidforge-debug.keystore"
    run(["keytool", "-genkeypair", "-keystore", keystore, "-storepass", "android", "-keypass", "android",
         "-alias", "androiddebugkey", "-dname", "CN=Android Debug,O=Android,C=US",
         "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000"])
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists(): out.unlink()
    run([apksigner, "sign", "--ks", keystore, "--ks-pass", "pass:android", "--key-pass", "pass:android",
         "--out", out, aligned])
    run([apksigner, "verify", "--verbose", out])
    print(f"PATCHED APK: {out} ({out.stat().st_size} bytes)", flush=True)

if __name__ == "__main__":
    main()
