#!/usr/bin/env python3
import argparse, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path
import xml.etree.ElementTree as ET

ANDROID = "{http://schemas.android.com/apk/res/android}"
ET.register_namespace("android", "http://schemas.android.com/apk/res/android")

def run(cmd, cwd=None):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), cwd=cwd, check=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--helper", required=True)
    ap.add_argument("--apktool", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--sdk", required=True)
    args = ap.parse_args()
    base, helper, apktool, out, sdk = map(Path, (args.base, args.helper, args.apktool, args.out, args.sdk))
    if not base.is_file() or base.stat().st_size < 10_000_000: raise SystemExit("Original base.apk missing or unexpectedly small.")
    if not helper.is_file(): raise SystemExit("Compiled helper APK missing.")
    work = out.parent / "heycyan_patch_work"
    if work.exists(): shutil.rmtree(work)
    work.mkdir(parents=True)
    decoded = work / "original"
    helper_decoded = work / "helper"
    run(["java", "-jar", apktool, "d", "-f", base, "-o", decoded])
    run(["java", "-jar", apktool, "d", "-f", helper, "-o", helper_decoded])

    # Patch the one original voice GPT call, preserving its register layout.
    targets = list(decoded.glob("smali*/T1/F.smali"))
    if len(targets) != 1: raise SystemExit(f"Expected one T1/F.smali, found {len(targets)}")
    smali = targets[0]
    source = smali.read_text(encoding="utf-8")
    pattern = re.compile(r"(?m)^(\s*)invoke-virtual/range (\{[^}]+\}), LD2/J;->r\(JLjava/lang/String;Ljava/lang/String;ZI\)V\s*$")
    source, count = pattern.subn(
        r"\1invoke-static/range \2, Lcom/stereoo/ai/OpenAIResponsesBridge;->ask(Ljava/lang/Object;JLjava/lang/String;Ljava/lang/String;ZI)V",
        source
    )
    if count != 1:
        raise SystemExit(f"Expected exactly one original voice-chat call to redirect, patched {count}; no APK emitted.")
    smali.write_text(source, encoding="utf-8")

    # Merge native libraries from the helper APK into the patched original APK.
    # The supplied base.apk is a split-derived APK and contains no lib/ entries,
    # while the original Application crashes trying to load libmmkv.so.
    helper_lib_root = helper_decoded / "lib"
    if helper_lib_root.exists():
        for abi_dir in helper_lib_root.iterdir():
            if not abi_dir.is_dir():
                continue
            target_abi = decoded / "lib" / abi_dir.name
            target_abi.mkdir(parents=True, exist_ok=True)
            for native_lib in abi_dir.glob("*.so"):
                shutil.copy2(native_lib, target_abi / native_lib.name)
    native_mmkv = list((decoded / "lib").glob("*/libmmkv.so")) if (decoded / "lib").exists() else []
    if not native_mmkv:
        raise SystemExit("MMKV native library was not merged from helper APK; refusing to emit an APK that will crash at startup.")

    # Inject helper classes into a new dex tree; original APK currently has one classes.dex.
    helper_smali_dirs = sorted(helper_decoded.glob("smali*"))
    if not helper_smali_dirs: raise SystemExit("Could not find helper smali output.")
    destination = decoded / "smali_classes2"
    destination.mkdir(exist_ok=True)
    copied = 0
    for helper_smali in helper_smali_dirs:
        package_dir = helper_smali / "com" / "stereoo" / "ai"
        if package_dir.exists():
            target_dir = destination / "com" / "stereoo" / "ai"
            target_dir.parent.mkdir(parents=True, exist_ok=True)
            if target_dir.exists(): shutil.rmtree(target_dir)
            shutil.copytree(package_dir, target_dir)
            copied += len(list(target_dir.glob("*.smali")))
    if copied < 2: raise SystemExit(f"Expected bridge and settings activity classes; copied {copied}")

    # Merge activity and internet permission into the original manifest.
    manifest_path = decoded / "AndroidManifest.xml"
    tree = ET.parse(manifest_path)
    root = tree.getroot()
    # The supplied HeyCyan base.apk was extracted from a split APK set.
    # Android refuses to install it standalone while these split requirements remain.
    # Remove the split-only manifest attributes so the rebuilt APK can be installed as one file.
    root.attrib.pop(ANDROID + "requiredSplitTypes", None)
    root.attrib.pop(ANDROID + "splitTypes", None)
    application = root.find("application")
    if application is None: raise SystemExit("Decoded manifest has no <application>.")
    has_internet = any(el.get(ANDROID + "name") == "android.permission.INTERNET" for el in root.findall("uses-permission"))
    if not has_internet:
        perm = ET.Element("uses-permission")
        perm.set(ANDROID + "name", "android.permission.INTERNET")
        root.insert(list(root).index(application), perm)
    activity_name = "com.stereoo.ai.OpenAISettingsActivity"
    if not any(el.get(ANDROID + "name") == activity_name for el in application.findall("activity")):
        activity = ET.SubElement(application, "activity")
        activity.set(ANDROID + "name", activity_name)
        activity.set(ANDROID + "exported", "false")
        activity.set(ANDROID + "label", "AI Stereoo · OpenAI")
        activity.set(ANDROID + "theme", "@android:style/Theme.Material.Light.NoActionBar")
    application.set(ANDROID + "label", "AI Stereoo")
    tree.write(manifest_path, encoding="utf-8", xml_declaration=True)

    unsigned = work / "patched-unsigned.apk"
    run(["java", "-jar", apktool, "b", decoded, "-o", unsigned])

    build_tools = sdk / "build-tools"
    versions = sorted([p for p in build_tools.iterdir() if p.is_dir()], key=lambda p: tuple(int(x) if x.isdigit() else 0 for x in p.name.split(".")))
    if not versions: raise SystemExit(f"No Android build-tools found under {build_tools}")
    bt = versions[-1]
    zipalign = bt / "zipalign"
    apksigner = bt / "apksigner"
    if not zipalign.is_file() or not apksigner.is_file(): raise SystemExit("zipalign/apksigner not found in Android build-tools.")
    aligned = work / "patched-aligned.apk"
    run([zipalign, "-f", "-p", "4", unsigned, aligned])
    keystore = work / "androidforge-debug.keystore"
    run(["keytool", "-genkeypair", "-keystore", keystore, "-storepass", "android", "-keypass", "android",
         "-alias", "androiddebugkey", "-dname", "CN=Android Debug,O=Android,C=US",
         "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000"])
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists(): out.unlink()
    run([apksigner, "sign", "--ks", keystore, "--ks-pass", "pass:android", "--key-pass", "pass:android",
         "--out", out, aligned])
    run([apksigner, "verify", "--verbose", out])
    print(f"PATCHED APK: {out} ({out.stat().st_size} bytes)", flush=True)

if __name__ == "__main__":
    main()
