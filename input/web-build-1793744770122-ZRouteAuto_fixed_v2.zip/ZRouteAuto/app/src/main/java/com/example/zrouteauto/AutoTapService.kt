package com.example.zrouteauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/** Simple coordinate macro. It does not detect squad state or game UI. */
class AutoTapService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false

    private val poll = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("macro", MODE_PRIVATE)
            if (prefs.getBoolean("enabled", false) && !busy) {
                val x1 = prefs.getInt("x1", 360).toFloat()
                val y1 = prefs.getInt("y1", 760).toFloat()
                val x2 = prefs.getInt("x2", 360).toFloat()
                val y2 = prefs.getInt("y2", 1400).toFloat()
                val pause = prefs.getLong("pause", 20_000L)
                busy = true
                tap(x1, y1) {
                    handler.postDelayed({
                        if (!prefs.getBoolean("enabled", false)) {
                            busy = false
                        } else {
                            tap(x2, y2) {
                                busy = false
                                handler.postDelayed(this, pause)
                            }
                        }
                    }, 1200L)
                }
            }
            handler.postDelayed(this, 1000L)
        }
    }

    private fun tap(x: Float, y: Float, done: () -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90))
            .build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) = done()
            override fun onCancelled(gestureDescription: GestureDescription?) = done()
        }, null)
        if (!accepted) done()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(poll)
        handler.post(poll)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* polling is intentional */ }
    override fun onInterrupt() {
        getSharedPreferences("macro", MODE_PRIVATE).edit().putBoolean("enabled", false).apply()
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
