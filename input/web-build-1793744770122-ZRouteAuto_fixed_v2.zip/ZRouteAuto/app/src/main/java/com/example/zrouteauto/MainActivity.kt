package com.example.zrouteauto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.view.ViewGroup
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
            setBackgroundColor(Color.rgb(20, 25, 35))
        }
        fun label(s: String) = TextView(this).apply {
            text = s; textSize = 16f; setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(8))
        }
        fun field(hint: String, value: String) = EditText(this).apply {
            this.hint = hint; setText(value); textSize = 16f
            setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        box.addView(label("Z ROUTE AUTO  •  прототип"))
        box.addView(label("Сначала включи службу специальных возможностей."))
        val access = Button(this).apply {
            text = "Открыть настройки доступности"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        box.addView(access)
        box.addView(label("Координаты нажатия (экран 720 × 1608 из твоего видео)"))
        val x1 = field("X босса", "360"); val y1 = field("Y босса", "760")
        val x2 = field("X кнопки атаки", "360"); val y2 = field("Y кнопки атаки", "1400")
        val pause = field("Пауза между циклами, секунд", "20")
        listOf(x1,y1,x2,y2,pause).forEach { box.addView(it) }
        box.addView(label("Важно: координаты пока примерные. Проверь их вручную, чтобы не нажимать случайные кнопки."))
        val start = Button(this).apply {
            text = "СТАРТ"
            setOnClickListener {
                val prefs = getSharedPreferences("macro", MODE_PRIVATE)
                prefs.edit().putInt("x1", x1.text.toString().toIntOrNull() ?: 360)
                    .putInt("y1", y1.text.toString().toIntOrNull() ?: 760)
                    .putInt("x2", x2.text.toString().toIntOrNull() ?: 360)
                    .putInt("y2", y2.text.toString().toIntOrNull() ?: 1400)
                    .putLong("pause", (pause.text.toString().toLongOrNull() ?: 20L).coerceIn(5, 3600) * 1000L)
                    .apply()
                prefs.edit().putBoolean("enabled", true).apply()
            }
        }
        val stop = Button(this).apply {
            text = "СТОП"
            setOnClickListener { getSharedPreferences("macro", MODE_PRIVATE).edit().putBoolean("enabled", false).apply() }
        }
        box.addView(start); box.addView(stop)
        box.addView(label("Оставь игру открытой и экран включённым. Приложение не читает аккаунт и не обходит защиту игры."))
        setContentView(box)
    }
}
