package ru.stereoo.paywatch;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Stereoo Pay Watch: an opt-in accessibility remote for the ORIGINAL Mir Pay.
 * It does not change density or orientation, hook payment APIs, extract card
 * numbers, or fill payment data. Manual gestures are initiated by the user.
 */
public final class MirPayAssistService extends AccessibilityService {
    private static final String MIRPAY = "ru.nspk.mirpay";
    private static final String PREFS = "stereoo_pay_settings";
    private static final String CAMERA_GUARD = "deny_camera_dialogs";
    private static final int BG = 0xFF071322;
    private static final int PANEL = 0xFF122E43;
    private static final int MINT = 0xFF40E8DA;
    private static final int WHITE = Color.WHITE;

    private WindowManager windowManager;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private View bubble;
    private View menu;
    private boolean mirPayVisible;
    private boolean gestureRunning;
    private boolean destroyed;
    private boolean updateQueued;
    private long lastCameraAction;
    private int cursorX, cursorY, cursorStep = 36;
    private int screenW, screenH;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        Point p = new Point();
        windowManager.getDefaultDisplay().getRealSize(p);
        screenW = p.x;
        screenH = p.y;
        cursorX = screenW / 2;
        cursorY = screenH / 2;
        // A new event from Mir Pay activates the panel even when the app's
        // accessibility tree is unavailable (UiAutomator "null root").
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (destroyed || event == null) return;
        String pkg = event.getPackageName() == null ? "" : event.getPackageName().toString();
        if (isPermissionController(pkg) && cameraGuardEnabled()) denyMirPayCamera(event);

        int type = event.getEventType();
        if (MIRPAY.equals(pkg)) {
            mirPayVisible = true;
        } else if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                !getPackageName().equals(pkg) && !isPermissionController(pkg) &&
                !"android".equals(pkg)) {
            mirPayVisible = false;
        }
        if (!updateQueued) {
            updateQueued = true;
            handler.postDelayed(() -> {
                updateQueued = false;
                refreshOverlay();
            }, 250);
        }
    }

    @Override public void onInterrupt() { hideAll(); }
    @Override public void onDestroy() {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        hideAll();
        super.onDestroy();
    }

    private void refreshOverlay() {
        if (windowManager == null || destroyed || gestureRunning) return;
        if (!mirPayVisible) {
            hideAll();
        } else if (bubble == null && menu == null) {
            showBubble();
        }
    }

    private void hideAll() {
        remove(menu);
        remove(bubble);
        menu = null;
        bubble = null;
    }

    private void remove(View view) {
        if (view == null || windowManager == null) return;
        try { windowManager.removeView(view); } catch (RuntimeException ignored) { }
    }

    private int dp(float value) {
        return (int) (getResources().getDisplayMetrics().density * value + 0.5f);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable result = new GradientDrawable();
        result.setColor(color);
        result.setCornerRadius(dp(radius));
        return result;
    }

    private WindowManager.LayoutParams overlayParams(int width, int height, int gravity, int y) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(width, height,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = gravity;
        lp.y = y;
        return lp;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private void showBubble() {
        if (windowManager == null || destroyed || gestureRunning || bubble != null) return;
        TextView button = label("⌁", 23, BG, true);
        button.setBackground(shape(MINT, 25));
        button.setContentDescription("Открыть пульт Mir Pay");
        button.setOnClickListener(v -> showMainMenu());
        button.setOnLongClickListener(v -> {
            // Temporarily hide to let the user touch the original application.
            hideAll();
            toast("Пульт скрыт до следующего изменения экрана Mir Pay");
            return true;
        });
        try {
            bubble = button;
            windowManager.addView(button, overlayParams(dp(42), dp(42),
                    Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, dp(10)));
        } catch (RuntimeException ignored) { bubble = null; }
    }

    private LinearLayout newPanel(String heading, String subheading) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(9), dp(10), dp(10));
        panel.setBackground(shape(BG, 23));
        TextView title = label(heading, 13, MINT, true);
        panel.addView(title, new LinearLayout.LayoutParams(-1, dp(30)));
        TextView subtitle = label(subheading, 10, 0xFFBBD3DF, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.bottomMargin = dp(7);
        panel.addView(subtitle, sp);
        return panel;
    }

    private void addButton(LinearLayout layout, String name, boolean primary, Runnable onTap) {
        TextView b = label(name, 12, primary ? BG : WHITE, primary);
        b.setMinHeight(dp(39));
        b.setPadding(dp(5), dp(5), dp(5), dp(5));
        b.setBackground(shape(primary ? MINT : PANEL, 14));
        b.setContentDescription(name);
        b.setOnClickListener(v -> onTap.run());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.bottomMargin = dp(6);
        layout.addView(b, bp);
    }

    private void addRow(LinearLayout layout, String left, Runnable leftAction,
                        String right, Runnable rightAction) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        twoWay(row, left, leftAction);
        twoWay(row, right, rightAction);
        layout.addView(row);
    }

    private void twoWay(LinearLayout row, String name, Runnable action) {
        TextView b = label(name, 16, WHITE, true);
        b.setBackground(shape(PANEL, 13));
        b.setContentDescription(name);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(39), 1);
        lp.setMargins(dp(2), 0, dp(2), dp(5));
        row.addView(b, lp);
    }

    private void displayPanel(LinearLayout content) {
        if (windowManager == null || destroyed) return;
        remove(menu);
        remove(bubble);
        menu = null;
        bubble = null;
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(false);
        scroller.setVerticalScrollBarEnabled(false);
        scroller.addView(content);
        // Keep controls inside the inscribed central portion of the round watch.
        int width = Math.min((int) (screenW * 0.71f), dp(245));
        int height = Math.min((int) (screenH * 0.71f), dp(265));
        try {
            menu = scroller;
            windowManager.addView(scroller, overlayParams(width, height, Gravity.CENTER, 0));
        } catch (RuntimeException ignored) {
            menu = null;
            showBubble();
        }
    }

    private void closeMenu() {
        remove(menu);
        menu = null;
        if (!gestureRunning) refreshOverlay();
    }

    private void showMainMenu() {
        LinearLayout panel = newPanel("STEREOO • ПУЛЬТ", "Без DPI и поворота экрана");
        addButton(panel, "＋ ДОБАВИТЬ КАРТУ", true, this::findAddCard);
        addButton(panel, "СПИСОК КНОПОК", false, this::showButtonsMenu);
        addButton(panel, "РУЧНОЙ КУРСОР", false, this::showCursorMenu);
        addRow(panel, "↑ ЛИСТАТЬ", () -> performSwipe(false),
                "↓ ЛИСТАТЬ", () -> performSwipe(true));
        addButton(panel, "НАЗАД", false, () -> {
            closeMenu();
            performGlobalAction(GLOBAL_ACTION_BACK);
        });
        addButton(panel, "ЗАКРЫТЬ ПУЛЬТ", false, this::closeMenu);
        displayPanel(panel);
    }

    private AccessibilityNodeInfo mirPayRoot() {
        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows != null) for (AccessibilityWindowInfo window : windows) {
                if (window.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                AccessibilityNodeInfo root = window.getRoot();
                if (root != null && root.getPackageName() != null &&
                        MIRPAY.contentEquals(root.getPackageName())) return root;
            }
            AccessibilityNodeInfo active = getRootInActiveWindow();
            if (active != null && active.getPackageName() != null &&
                    MIRPAY.contentEquals(active.getPackageName())) return active;
        } catch (RuntimeException ignored) { }
        return null;
    }

    private boolean safeUiNode(AccessibilityNodeInfo node) {
        if (node == null || node.isPassword()) return false;
        CharSequence clazz = node.getClassName();
        return clazz == null || !clazz.toString().contains("EditText");
    }

    private boolean isAddCardLabel(String label) {
        String s = label.toLowerCase(Locale.ROOT);
        return (s.contains("добав") && s.contains("карт")) ||
                s.equals("добавить") || s.equals("новая карта") ||
                s.equals("добавить карту") || s.equals("add card");
    }

    private String nodeLabel(AccessibilityNodeInfo node) {
        if (!safeUiNode(node)) return "";
        CharSequence clazz = node.getClassName();
        String cls = clazz == null ? "" : clazz.toString();
        // NEVER inspect text on card-entry fields. Read only button-like labels.
        if (!cls.endsWith("Button") && !cls.endsWith("TextView") &&
                !cls.endsWith("ImageButton")) return "";
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        String value = text != null ? text.toString() : (desc == null ? "" : desc.toString());
        value = value.replace('\n', ' ').trim();
        if (value.length() > 55 || value.matches(".*[0-9]{4,}.*")) return "";
        return value;
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo node) {
        for (int i = 0; i < 3 && node != null; i++, node = node.getParent()) {
            if (node.isEnabled() && node.isClickable() && safeUiNode(node) &&
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        }
        return false;
    }

    private boolean findAndClick(AccessibilityNodeInfo node, String target, int depth) {
        if (node == null || depth > 25 || !safeUiNode(node)) return false;
        String label = nodeLabel(node);
        if ((!target.isEmpty() && target.equals(label)) ||
                (target.isEmpty() && isAddCardLabel(label))) {
            if (clickNodeOrParent(node)) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++)
            if (findAndClick(node.getChild(i), target, depth + 1)) return true;
        return false;
    }

    private void findAddCard() {
        AccessibilityNodeInfo root = mirPayRoot();
        closeMenu();
        if (root == null) {
            toast("Mir Pay скрывает кнопки. Попробуй ручной курсор.");
            return;
        }
        if (!findAndClick(root, "", 0))
            toast("Кнопка не найдена. Используй список или курсор.");
    }

    private void collectActionLabels(AccessibilityNodeInfo node, ArrayList<String> out, int depth) {
        if (node == null || depth > 24 || out.size() >= 8 || !safeUiNode(node)) return;
        String title = nodeLabel(node);
        if (!title.isEmpty() && node.isEnabled() && (node.isClickable() ||
                node.getParent() != null && node.getParent().isClickable()) &&
                !out.contains(title)) {
            out.add(title);
        }
        for (int i = 0; i < node.getChildCount(); i++)
            collectActionLabels(node.getChild(i), out, depth + 1);
    }

    private void showButtonsMenu() {
        LinearLayout panel = newPanel("КНОПКИ MIR PAY", "Выбери действие вручную");
        AccessibilityNodeInfo root = mirPayRoot();
        if (root == null) {
            TextView hint = label("Дерево интерфейса недоступно. Это бывает у Mir Pay. " +
                    "Можно нажать точку курсором.", 11, WHITE, false);
            hint.setPadding(dp(5), dp(5), dp(5), dp(6));
            panel.addView(hint);
        } else {
            ArrayList<String> found = new ArrayList<>();
            collectActionLabels(root, found, 0);
            if (found.isEmpty()) {
                panel.addView(label("Доступных кнопок не найдено", 11, WHITE, false));
            } else for (String title : found) {
                addButton(panel, title, true, () -> {
                    closeMenu();
                    handler.postDelayed(() -> {
                        AccessibilityNodeInfo current = mirPayRoot();
                        if (current == null || !findAndClick(current, title, 0))
                            toast("Нажатие недоступно, попробуй курсор");
                    }, 180);
                });
            }
        }
        addButton(panel, "РУЧНОЙ КУРСОР", false, this::showCursorMenu);
        addButton(panel, "← К ПУЛЬТУ", false, this::showMainMenu);
        displayPanel(panel);
    }

    private void adjust(int dx, int dy) {
        cursorX = Math.max(0, Math.min(screenW - 1, cursorX + dx * cursorStep));
        cursorY = Math.max(0, Math.min(screenH - 1, cursorY + dy * cursorStep));
        showCursorMenu();
    }

    private void showCursorMenu() {
        LinearLayout panel = newPanel("РУЧНОЙ КУРСОР", "Для кнопок за краем круга");
        panel.addView(label("X: " + cursorX + "    Y: " + cursorY,
                12, MINT, true));
        addRow(panel, "◁ ВЛЕВО", () -> adjust(-1, 0),
                "ВПРАВО ▷", () -> adjust(1, 0));
        addRow(panel, "△ ВВЕРХ", () -> adjust(0, -1),
                "ВНИЗ ▽", () -> adjust(0, 1));
        addButton(panel, "● НАЖАТЬ В ТОЧКЕ", true, () -> dispatchTouch(cursorX, cursorY));
        addButton(panel, "ШАГ: " + cursorStep + "px", false, () -> {
            cursorStep = cursorStep == 36 ? 12 : 36;
            showCursorMenu();
        });
        addButton(panel, "СБРОСИТЬ КУРСОР В ЦЕНТР", false, () -> {
            cursorX = screenW / 2;
            cursorY = screenH / 2;
            showCursorMenu();
        });
        addButton(panel, "← К ПУЛЬТУ", false, this::showMainMenu);
        displayPanel(panel);
    }

    private void dispatchTouch(int x, int y) {
        // Unlike AccessibilityNodeInfo, gesture injection works without the UI
        // hierarchy; it still cannot activate a button that is not there.
        if (gestureRunning) return;
        gestureRunning = true;
        hideAll();
        handler.postDelayed(() -> {
            Path path = new Path();
            path.moveTo(x, y);
            GestureDescription gesture = new GestureDescription.Builder().addStroke(
                    new GestureDescription.StrokeDescription(path, 0, 75)).build();
            boolean sent = dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription description) {
                    gestureRunning = false;
                    handler.postDelayed(() -> refreshOverlay(), 250);
                }
                @Override public void onCancelled(GestureDescription description) {
                    gestureRunning = false;
                    toast("Жест прерван системой");
                    handler.postDelayed(() -> refreshOverlay(), 250);
                }
            }, handler);
            if (!sent) {
                gestureRunning = false;
                toast("Служба не может отправлять жесты");
                refreshOverlay();
            }
        }, 230);
    }

    private void performSwipe(boolean down) {
        if (gestureRunning) return;
        gestureRunning = true;
        hideAll();
        handler.postDelayed(() -> {
            Path path = new Path();
            float middle = screenW / 2f;
            float startY = down ? screenH * 0.78f : screenH * 0.22f;
            float endY = down ? screenH * 0.22f : screenH * 0.78f;
            path.moveTo(middle, startY);
            path.lineTo(middle, endY);
            GestureDescription gesture = new GestureDescription.Builder().addStroke(
                    new GestureDescription.StrokeDescription(path, 0, 440)).build();
            boolean sent = dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription description) {
                    gestureRunning = false;
                    handler.postDelayed(() -> refreshOverlay(), 250);
                }
                @Override public void onCancelled(GestureDescription description) {
                    gestureRunning = false;
                    toast("Прокрутка прервана");
                    handler.postDelayed(() -> refreshOverlay(), 250);
                }
            }, handler);
            if (!sent) {
                gestureRunning = false;
                toast("Прокрутка недоступна");
                refreshOverlay();
            }
        }, 230);
    }

    private boolean cameraGuardEnabled() {
        return getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(CAMERA_GUARD, true);
    }

    private boolean isPermissionController(String name) {
        return name.equals("com.google.android.packageinstaller") ||
                name.equals("com.android.packageinstaller") ||
                name.equals("com.android.permissioncontroller") ||
                name.equals("com.google.android.permissioncontroller");
    }

    private void denyMirPayCamera(AccessibilityEvent event) {
        if (SystemClock.elapsedRealtime() - lastCameraAction < 1200) return;
        AccessibilityNodeInfo root;
        try { root = getRootInActiveWindow(); } catch (RuntimeException e) { return; }
        if (root == null || root.getPackageName() == null ||
                !isPermissionController(root.getPackageName().toString())) return;
        StringBuilder dialog = new StringBuilder();
        collectPermissionText(root, dialog, 0);
        String combined = dialog.toString().toLowerCase(Locale.ROOT);
        if (!(combined.contains("mir pay") || combined.contains("mirpay") ||
                combined.contains("мир пэй") || combined.contains("ru.nspk.mirpay"))) return;
        if (!(combined.contains("камер") || combined.contains("camera") ||
                combined.contains("фото и видео"))) return;
        if (denyPermission(root, 0)) {
            lastCameraAction = SystemClock.elapsedRealtime();
            toast("Mir Pay: запрос камеры отклонён");
        }
    }

    // Only a SYSTEM permission dialog is inspected. No Mir Pay card fields.
    private void collectPermissionText(AccessibilityNodeInfo node, StringBuilder out, int level) {
        if (node == null || level > 16 || out.length() > 2000) return;
        CharSequence txt = node.getText();
        CharSequence desc = node.getContentDescription();
        if (txt != null) out.append(' ').append(txt);
        if (desc != null) out.append(' ').append(desc);
        for (int i = 0; i < node.getChildCount(); i++)
            collectPermissionText(node.getChild(i), out, level + 1);
    }

    private boolean denyPermission(AccessibilityNodeInfo node, int level) {
        if (node == null || level > 16) return false;
        String title = node.getText() == null ? "" :
                node.getText().toString().trim().toLowerCase(Locale.ROOT);
        String id = node.getViewIdResourceName() == null ? "" :
                node.getViewIdResourceName().toLowerCase(Locale.ROOT);
        boolean deny = title.equals("запретить") || title.equals("не разрешать") ||
                title.equals("не разрешить") || title.equals("deny") ||
                title.equals("don't allow") || title.equals("don’t allow") ||
                id.endsWith(":id/permission_deny_button");
        if (deny && node.isEnabled() && node.isClickable() &&
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        for (int i = 0; i < node.getChildCount(); i++)
            if (denyPermission(node.getChild(i), level + 1)) return true;
        return false;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
