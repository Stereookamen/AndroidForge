# CyanBridge 2.3.0 + Stereoo AI Glasses (HeyCyan) — инструкция

Этот архив содержит исходники CyanBridge 2.3.0 с интеграцией Stereoo для очков, использующих протокол HeyCyan.

## Изменения

- Голосовая кнопка HeyCyan при маршруте `PHONE_ASSISTANT` запускает `ru.stereoo.aiglasses.MainActivity` с действием `com.fersaiyan.cyanbridge.ACTION_START_EXTERNAL_ASSISTANT`. Это обходит системный выбор помощника.
- После получения фотографии CyanBridge передаёт изображение в Stereoo через `ACTION_SEND` (`image/jpeg`) и текст задания на русском. Если Stereoo не установлено или передача не удалась, CyanBridge возвращается к своему обычному сценарию.
- Интеграция не заменяет и не удаляет драйверы других очков.

## Что нужно для полной сборки

1. Java 17 и Android SDK, API 36.
2. Репозиторий использует Git submodule `android/CyanBridge/app/src/main/myvu-upstream` (Meizu Myvu). ZIP-архивы GitHub не включают содержимое submodule. Если сборка идёт из Git-клона, выполните `git submodule update --init --recursive`. Если сборка идёт из ZIP, источник Myvu должен быть получен отдельно и распакован в указанный каталог.
3. Чтобы сохранить поддержку очков Meta Ray-Ban, Gradle-проект по-прежнему использует Meta Wearables DAT SDK. Для его загрузки нужен `META_GITHUB_TOKEN` с доступом `read:packages` к GitHub Packages. Это не означает, что очки HeyCyan зависят от Meta: их события обрабатываются отдельным HeyCyan/Bluetooth-путём.

## Сборка

Из каталога `android/CyanBridge`:

```bash
chmod +x gradlew
./gradlew assembleDebug
```

APK при успешной сборке: `app/build/outputs/apk/debug/app-debug.apk`.

## Проверка

- Установите CyanBridge и Stereoo на один Android-телефон.
- Подключите HeyCyan-очки в CyanBridge.
- В настройках маршрута AI выберите `PHONE_ASSISTANT` и включите перехват AI-кнопки.
- Нажмите голосовую кнопку: Stereoo должна открыться и начать слушать.
- Нажмите кнопку фото: после получения снимка CyanBridge отправит его в Stereoo с просьбой описать изображение по-русски.

Архив содержит исходный код, а не заранее собранный APK. Сборка должна быть выполнена в среде с указанными зависимостями и секретами.
