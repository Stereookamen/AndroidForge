package ru.stereoo.morkovsk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import kotlin.math.abs

/**
 * Only local, small UI fragments from the owner's screenshots are compared.
 * No network requests, OCR, screenshots storage or image uploads.
 * Coordinates refer to the provided 691 x 1536 reference screenshots.
 */
class VisualMatcher(private val context: Context) {
    data class Hit(val rect: Rect, val score: Double) {
        val x: Int get() = rect.centerX()
        val y: Int get() = rect.centerY()
    }
    private val templates = mutableMapOf<String, Bitmap>()
    private val templatePixels = mutableMapOf<String, IntArray>()
    private var cachedImage: Bitmap? = null
    private var cachedPixels: IntArray? = null
    private val W = 691
    private val H = 1536

    fun normalized(raw: Bitmap): Bitmap? {
        if (abs(raw.width.toDouble() / raw.height - W.toDouble() / H) > 0.05) return null
        return if (raw.width == W && raw.height == H) raw
        else Bitmap.createScaledBitmap(raw, W, H, true)
    }

    private fun template(name: String): Bitmap? {
        if (name in templates) return templates[name]
        return try {
            val bmp = context.assets.open("matcher/$name.png").use { BitmapFactory.decodeStream(it) }
            if (bmp != null) templates[name] = bmp
            bmp
        } catch (_: Exception) { null }
    }

    /** X/Y are restricted search centers in the reference screenshot. */
    fun locate(image: Bitmap, name: String, x1: Int, x2: Int, y1: Int, y2: Int,
               tolerance: Double = 0.145): Hit? {
        val t = template(name) ?: return null
        if (image !== cachedImage) {
            cachedImage = image
            cachedPixels = IntArray(W * H).also { image.getPixels(it, 0, W, 0, 0, W, H) }
        }
        val source = cachedPixels ?: return null
        val ref = templatePixels.getOrPut(name) {
            IntArray(t.width * t.height).also { t.getPixels(it, 0, t.width, 0, 0, t.width, t.height) }
        }
        val w = t.width; val h = t.height
        val sx = maxOf(0, x1); val ex = minOf(W - w, x2)
        val sy = maxOf(0, y1); val ey = minOf(H - h, y2)
        if (ex < sx || ey < sy) return null
        // For every placement sample a grid with 3-pixel stride. Full-resolution
        // RGB comparison avoids treating blue product buttons as yellow prize buttons.
        var best = Double.MAX_VALUE
        var bx = -1; var by = -1
        val stepX = maxOf(3, w / 65)
        val stepY = maxOf(3, h / 11)
        for (y in sy..ey step 2) for (x in sx..ex step 2) {
            var total = 0L
            var samples = 0
            for (ty in 1 until h step stepY) {
                for (tx in 1 until w step stepX) {
                    val a = source[(y + ty) * W + (x + tx)]
                    val b = ref[ty * w + tx]
                    total += abs((a shr 16 and 255) - (b shr 16 and 255))
                    total += abs((a shr 8 and 255) - (b shr 8 and 255))
                    total += abs((a and 255) - (b and 255))
                    samples++
                }
                // early abandon clearly worse placements
                if (best < 0.06 && samples > 25 && total.toDouble() / (samples * 765) > best * 1.3) break
            }
            if (samples == 0) continue
            val score = total.toDouble() / (samples * 765)
            if (score < best) { best = score; bx = x; by = y }
            if (score < 0.012) return Hit(Rect(bx, by, bx+w, by+h), score)
        }
        return if (bx >= 0 && best <= tolerance) Hit(Rect(bx, by, bx+w, by+h), best) else null
    }

    fun screen(image: Bitmap, name: String): Hit? = when (name) {
        "daily" -> locate(image, name, 120, 170, 270, 380, 0.16)
        "claim" -> locate(image, name, 220, 320, 910, 1030, 0.14)
        "basketOffer" -> locate(image, name, 185, 285, 1040, 1140, 0.09)
        "basketTitle" -> locate(image, name, 60, 130, 175, 255, 0.16)
        "home" -> locate(image, name, 45, 125, 175, 300, 0.14)
        "taskNav" -> locate(image, name, 200, 250, 1000, 1055, 0.09)
        "tasksHeader" -> locate(image, name, 0, 45, 280, 365, 0.16)
        "visitTask" -> locate(image, name, 87, 128, 170, 1350, 0.10)
        "cartTask" -> locate(image, name, 86, 133, 170, 1350, 0.10)
        "paidTask" -> locate(image, name, 85, 133, 170, 1350, 0.10)
        "visitCta" -> locate(image, name, 194, 265, 1325, 1430, 0.09)
        "cartCta" -> locate(image, name, 215, 295, 1325, 1430, 0.09)
        else -> null
    }

    fun taskIdentity(image: Bitmap, hit: Hit): String {
        val y = hit.y
        // Title text, not row position or timer: a stable per-task fingerprint.
        val area = Rect(111, maxOf(0, y - 12), 575, minOf(H, y + 15))
        val values = StringBuilder()
        for (dy in 0..11) for (dx in 0..80) {
            val px = area.left + dx * (area.width() - 1) / 80
            val py = area.top + dy * (area.height() - 1) / 11
            val c = image.getPixel(px, py)
            // Compare text brightness against the dark violet task-card background.
            val bright = ((c shr 16 and 255) + (c shr 8 and 255) + (c and 255)) / 3
            values.append(if (bright > 145) '1' else '0')
        }
        return values.toString().hashCode().toString()
    }

    private fun blue(c: Int): Boolean {
        val r = c shr 16 and 255
        val g = c shr 8 and 255
        val b = c and 255
        return r < 38 && g in 65..135 && b > 222 && b > g * 1.8
    }

    private fun pale(c: Int): Boolean {
        val r = c shr 16 and 255
        val g = c shr 8 and 255
        val b = c and 255
        return r >= 210 && g >= 225 && b >= 236
    }

    /**
     * Recognize Ozon's blue PRODUCT-CARD cart button (with delivery date).
     * It is not labelled «В корзину»: the text often is «5 ноября».
     * We require a long solid blue strip across one of two product columns,
     * bordered by light card background both above and below. This filters out
     * large blue product images and navigation elements.
     * We never inspect/click the paid task list or checkout in this function.
     */
    fun blueProductButton(image: Bitmap): Pair<Int, Int>? {
        val columns = listOf(intArrayOf(23, 76, 246, 312, 174),
            intArrayOf(372, 427, 599, 659, 521))
        for (y in 360..1308 step 3) {
            for (col in columns) {
                val points = col.take(4)
                // Only a genuine ~300px wide blue CTA has identical fill at
                // multiple separated locations, with white above AND below.
                val blueInside = points.count { x -> blue(image.getPixel(x, y)) }
                if (blueInside < 3) continue
                val upper = points.count { x -> pale(image.getPixel(x, y - 36)) }
                val lower = points.count { x -> pale(image.getPixel(x, y + 36)) }
                if (upper < 3 || lower < 3) continue
                // Find vertical midpoint of the current button, not its top.
                // On 691x1536 screenshots the typical CTA height is 50-56px.
                var upperEdge = y
                while (upperEdge > y - 27 && blue(image.getPixel(points[1], upperEdge))) upperEdge--
                var lowerEdge = y
                while (lowerEdge < y + 27 && blue(image.getPixel(points[1], lowerEdge))) lowerEdge++
                val midpoint = (upperEdge + lowerEdge) / 2
                if (midpoint <= 340 || midpoint >= 1350) continue
                return col[4] to midpoint
            }
        }
        return null
    }

    /**
     * After the click, Ozon replaces that button with [-] [1] [+].
     * Check the LIGHT-BLUE stepper background in the same product column and
     * same row, plus its blue - and + controls. Do not click them.
     */
    fun quantityStepperAt(image: Bitmap, buttonX: Int, buttonY: Int): Boolean {
        if (buttonY !in 340..1320) return false
        val left = if (buttonX < W / 2) 13 else 358
        val rowY = buttonY
        val probes = listOf(left + 48, left + 94, left + 155, left + 210, left + 246)
        val light = probes.count { x -> pale(image.getPixel(x, rowY)) }
        val lightAbove = probes.count { x -> pale(image.getPixel(x, rowY - 11)) }
        if (light < 3 || lightAbove < 3) return false
        fun bluePixelNearby(cx: Int): Boolean {
            for (yy in rowY - 12..rowY + 12 step 3)
                for (xx in cx - 12..cx + 12 step 3)
                    if (blue(image.getPixel(xx, yy))) return true
            return false
        }
        // '−' left and '+' right contain the same Ozon blue as cart CTA.
        return bluePixelNearby(left + 27) && bluePixelNearby(left + 295)
    }
}
