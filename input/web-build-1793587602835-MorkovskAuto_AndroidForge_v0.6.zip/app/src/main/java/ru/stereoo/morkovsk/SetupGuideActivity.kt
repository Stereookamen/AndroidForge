package ru.stereoo.morkovsk

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

/** Guided setup for sideloaded APKs on Android 13-15.
 * Android owns the restricted-settings decision; there is no app API to enable it.
 */
class SetupGuideActivity : Activity() {
    private lateinit var state: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup_guide)
        title = "Настройка доступа"
        state = findViewById(R.id.guideStatus)

        findViewById<Button>(R.id.openAccessibilityGuide).setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            catch (_: Exception) { toast("Открой Настройки → Специальные возможности вручную") }
        }
        findViewById<Button>(R.id.openInfoGuide).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                })
            } catch (_: Exception) { toast("Открой Настройки → Приложения → Морковск Авто вручную") }
        }
        findViewById<Button>(R.id.copyPackage).setOnClickListener {
            copy("Имя пакета", packageName)
            toast("Имя пакета скопировано")
        }
        findViewById<Button>(R.id.copyAdb).setOnClickListener {
            copy("Команда ADB", "adb install -r app-debug.apk")
            toast("Команда скопирована. APK должен находиться рядом с adb.")
        }
        findViewById<Button>(R.id.recheckGuide).setOnClickListener { refresh() }
        findViewById<Button>(R.id.backToApp).setOnClickListener { finish() }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val enabled = try {
            val manager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
                it.resolveInfo?.serviceInfo?.let { info ->
                    info.packageName == packageName && info.name == MorkovService::class.java.name
                } == true
            }
        } catch (_: Exception) { MorkovService.current != null }
        state.text = if (enabled) "✅  ДОСТУП ВКЛЮЧЁН! Возвращайся в Морковск Авто и начинай сбор." 
                     else "🔒  ДОСТУП ПОКА ВЫКЛЮЧЕН. Выполни шаги ниже."
        state.setBackgroundResource(if (enabled) R.drawable.bg_green_info else R.drawable.bg_info)
    }

    private fun copy(label: String, value: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, value))
    }
    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
}
