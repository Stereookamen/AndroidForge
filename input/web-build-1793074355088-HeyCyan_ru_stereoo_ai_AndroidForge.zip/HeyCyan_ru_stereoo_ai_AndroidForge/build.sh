#!/usr/bin/env bash
set -euo pipefail

APK_IN="original/HeyCyan.apk"
DECODED="work/decoded"
OUT="output"
APKTOOL="java -jar apktool.jar"

test -f "$APK_IN" || { echo "Missing original APK: $APK_IN"; exit 2; }
mkdir -p "$OUT" work

$APKTOOL d -f "$APK_IN" -o "$DECODED"

# Change app ID and display version while keeping the original component classes
# explicitly qualified so changing the manifest package does not redirect them.
python3 - <<'PY'
import xml.etree.ElementTree as ET
from pathlib import Path

manifest = Path("work/decoded/AndroidManifest.xml")
old_pkg = "com.glasssutdio.wear"
new_pkg = "ru.stereoo.ai"
android = "{http://schemas.android.com/apk/res/android}"

tree = ET.parse(manifest)
root = tree.getroot()
if root.tag != "manifest":
    raise SystemExit("Unexpected manifest root")

root.set("package", new_pkg)
root.set(android + "versionName", "1.0")

# Fully qualify relative component/application names against the original package
# before changing package resolution.
for elem in root.iter():
    name = elem.get(android + "name")
    if name:
        if name.startswith("."):
            elem.set(android + "name", old_pkg + name)
        elif "." not in name:
            elem.set(android + "name", old_pkg + "." + name)

    # Update provider authorities that are conventionally derived from app ID.
    auth = elem.get(android + "authorities")
    if auth:
        elem.set(android + "authorities", auth.replace(old_pkg, new_pkg))

tree.write(manifest, encoding="utf-8", xml_declaration=True)
print(f"Manifest package set to {new_pkg}; versionName set to 1.0")
PY

# Keep versionCode as in the original, unless Apktool's decoded manifest omitted it.
$APKTOOL b "$DECODED" -o work/unsigned.apk

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ]; then
  echo "ANDROID_HOME/ANDROID_SDK_ROOT is not set"
  exit 3
fi

BUILD_TOOLS="$(find "$SDK/build-tools" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -1)"
ZIPALIGN="$BUILD_TOOLS/zipalign"
APKSIGNER="$BUILD_TOOLS/apksigner"

"$ZIPALIGN" -f 4 work/unsigned.apk work/aligned.apk

mkdir -p work/keystore
keytool -genkeypair -v \
  -keystore work/keystore/stereoo-debug.keystore \
  -alias stereoo \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass android -keypass android \
  -dname "CN=Stereoo AI, OU=Development, O=Stereoo, L=Unknown, S=Unknown, C=RU" \
  >/dev/null 2>&1

"$APKSIGNER" sign \
  --ks work/keystore/stereoo-debug.keystore \
  --ks-key-alias stereoo \
  --ks-pass pass:android \
  --key-pass pass:android \
  --out "$OUT/Stereoo_AI_1.0.apk" \
  work/aligned.apk

"$APKSIGNER" verify --verbose "$OUT/Stereoo_AI_1.0.apk"
echo "Built: $OUT/Stereoo_AI_1.0.apk"
