# Stereoo AI / HeyCyan APK rebuild project

This is a Gradle-recognizable project intended for AndroidForge / GitHub Actions.

## What this build does

- Uses the provided original `original/HeyCyan.apk` as the baseline.
- Decodes and rebuilds it with Apktool, preserving the original app payload as far as Apktool permits.
- Changes the manifest application ID to `ru.stereoo.ai` and `versionName` to `1.0`.
- Re-aligns and signs the resulting APK for testing.
- Produces `output/Stereoo_AI_1.0.apk` (the installable APK, not a tiny payload/release metadata file).

**Important:** this is an APK repackaging baseline, not a full source-level Gradle recompilation. The supplied decompiled Java is not a complete original Android Studio project with its dependency graph. This baseline is meant to verify that the app still installs and launches after identity changes before adding code modifications.

## Build

The build runner needs Java 17+, Android SDK build-tools, Python 3, and `apktool.jar` at the project root.

```bash
gradle assembleDebug
```

The GitHub Actions workflow downloads Apktool, runs Gradle, and uploads the actual APK as an artifact.

## App identity

- Application ID: `ru.stereoo.ai`
- Display version: `1.0`
- Version code: retained from the original APK
- Signing: generated test key; this APK cannot update the official HeyCyan app signed with its original certificate. Uninstall the original first if Android reports a signature/package conflict.
