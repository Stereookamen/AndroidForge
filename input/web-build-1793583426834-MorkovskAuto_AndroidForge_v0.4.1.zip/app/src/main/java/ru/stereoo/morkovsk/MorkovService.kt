package ru.stereoo.morkovsk

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * No external API. Screen interaction stays inside the Ozon package.
 * Never clicks paid order / checkout / roulette / ticket controls.
 * Exact visual templates are user-provided and used only as a fallback.
 */
class MorkovService : AccessibilityService() {
    companion object {
        const val OZON = "ru.ozon.app.android"
        @Volatile var current: MorkovService? = null
            private set
    }

    private enum class Step {
        ENTRY, AFTER_CLAIM, BASKET_EXIT, OPEN_TASKS, FIND_TASK,
        TASK_DIALOG, VISIT_PAGE, CART_PAGE, RETURN_TASKS, RETURN_HOME,
        CART_MANUAL, FINISHED, STOPPED
    }
    private enum class Kind { VISIT, CART }
    private data class Labeled(val node: AccessibilityNodeInfo, val text: String)
    private data class Candidate(val kind: Kind, val id: String, val y: Int,
                                 val node: AccessibilityNodeInfo? = null, val x: Int = 0)

    private val ui = Handler(Looper.getMainLooper())
    private val store by lazy { getSharedPreferences("morkovsk", MODE_PRIVATE) }
    private val matcher by lazy { VisualMatcher(this) }
    private val wm by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }
    private val attempted = mutableSetOf<String>()
    private var step = Step.STOPPED
    private var taskKind: Kind? = null
    private var passes = 0
    private var returns = 0
    private var stepsTaken = 0
    private var startedAt = 0L
    private var stateSince = 0L
    private var nextAllowed = 0L
    private var tickInProgress = false
    private var screenWidth = 691
    private var screenHeight = 1536
    private var overlay: LinearLayout? = null
    private var title: TextView? = null
    private var resume: Button? = null
    private var logs = mutableListOf<String>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        current = this
        step = Step.STOPPED
        store.edit().putBoolean("running", false).apply() // no spontaneous restart
    }

    override fun onInterrupt() { stopRun("Сервис специальных возможностей остановлен") }
    override fun onDestroy() {
        stopRun("Сервис отключён")
        current = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (step == Step.STOPPED || step == Step.FINISHED || step == Step.CART_MANUAL) return
        if (event?.packageName?.toString() != OZON) return
        schedule(450)
    }

    fun startRun() {
        if (current == null) return
        attempted.clear()
        logs.clear()
        passes = 0
        returns = 0
        stepsTaken = 0
        taskKind = null
        startedAt = SystemClock.elapsedRealtime()
        nextAllowed = 0
        store.edit().putBoolean("running", true)
            .putInt("visits", 0).putInt("cart", 0)
            .putString("diagnostic", "").apply()
        change(Step.ENTRY, "Запустил. Ожидаю главный экран Морковска или ежедневную награду.")
        showOverlay()
        schedule(1800)
    }

    fun stopRun(message: String = "Остановлено вручную") {
        step = Step.STOPPED
        store.edit().putBoolean("running", false).putString("phase", "Остановлено")
            .putString("status", message).apply()
        removeOverlay()
        ui.removeCallbacksAndMessages(null)
        tickInProgress = false
    }

    fun manualCartDone() {
        if (step != Step.CART_MANUAL) return
        change(Step.RETURN_TASKS, "Товар добавлен вручную. Возвращаюсь к заданиям.")
        returns = 0
        schedule(800)
    }

    fun scanNow() { schedule(0) }

    private fun schedule(delay: Long) {
        ui.postDelayed({ tick() }, delay)
    }

    private fun tick() {
        if (!store.getBoolean("running", false) || tickInProgress) return
        if (step == Step.CART_MANUAL || step == Step.FINISHED || step == Step.STOPPED) return
        if (SystemClock.elapsedRealtime() < nextAllowed) return
        if (SystemClock.elapsedRealtime() - startedAt > 15 * 60_000L) {
            stopRun("Лимит времени 15 минут. Завершено для безопасности.")
            return
        }
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != OZON) return
        val labels = flatten(root)
        tickInProgress = true
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                        var software: Bitmap? = null
                        var image: Bitmap? = null
                        try {
                            val hb = screenshot.hardwareBuffer
                            try {
                                val hw = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                                software = hw?.copy(Bitmap.Config.ARGB_8888, false)
                                hw?.recycle()
                            } finally { hb.close() }
                            screenWidth = software?.width ?: 691
                            screenHeight = software?.height ?: 1536
                            image = software?.let { matcher.normalized(it) }
                            process(labels, image)
                        } catch (_: Exception) {
                            process(labels, null)
                        } finally {
                            if (image !== software) image?.recycle()
                            software?.recycle()
                            tickInProgress = false
                        }
                    }
                    override fun onFailure(errorCode: Int) {
                        try { process(labels, null) }
                        finally { tickInProgress = false }
                    }
                })
            } catch (_: Exception) {
                try { process(labels, null) } finally { tickInProgress = false }
            }
        } else {
            try { process(labels, null) } finally { tickInProgress = false }
        }
    }

    private fun process(labels: List<Labeled>, image: Bitmap?) {
        if (!store.getBoolean("running", false)) return
        val age = SystemClock.elapsedRealtime() - stateSince
        val isHome = isHome(labels, image)
        val isTasks = isTasks(labels, image)
        val claim = has(labels, "забрать") && has(labels, "ежеднев") ||
            (image?.let { matcher.screen(it, "daily") != null && matcher.screen(it, "claim") != null } == true)
        val basketOffer = has(labels, "в лукошко") || image?.let { matcher.screen(it, "basketOffer") != null } == true
        val basket = has(labels, "лукошко с призами") || image?.let { matcher.screen(it, "basketTitle") != null } == true
        val visitCta = labels.any { it.text.trim().equals("посетить раздел", true) } || image?.let { matcher.screen(it, "visitCta") != null } == true
        val cartCta = labels.any { it.text.trim().equals("к товарам", true) } || image?.let { matcher.screen(it, "cartCta") != null } == true

        when (step) {
            Step.ENTRY -> when {
                claim -> {
                    if (clickButton(labels, image, "забрать", "claim")) {
                        change(Step.AFTER_CLAIM, "Забрал ежедневные морковки")
                        delayAction(1900)
                    } else stopRun("Не удалось нажать «ЗАБРАТЬ». Получи награду вручную.")
                }
                basketOffer -> {
                    change(Step.AFTER_CLAIM, "Ежедневная награда уже получена")
                    schedule(350)
                }
                basket -> {
                    change(Step.BASKET_EXIT, "Уходим из Лукошка, колесо не трогаем")
                    schedule(350)
                }
                isHome -> {
                    change(Step.OPEN_TASKS, "На главном экране, перехожу к бесплатным заданиям")
                    schedule(350)
                }
                isTasks -> { change(Step.FIND_TASK, "Открыт список заданий"); schedule(350) }
                age > 24000 -> stopRun("Не распознал Морковск. Открой его вручную и запусти заново.")
                else -> schedule(1800)
            }
            Step.AFTER_CLAIM -> when {
                basketOffer -> {
                    if (clickButton(labels, image, "в лукошко", "basketOffer")) {
                        change(Step.BASKET_EXIT, "Перешёл в Лукошко. Сразу выйду назад")
                        delayAction(1800)
                    } else stopRun("Не нашёл кнопку «В ЛУКОШКО». Продолжи вручную.")
                }
                isHome -> { change(Step.OPEN_TASKS, "Награда получена, перехожу к заданиям"); schedule(450) }
                basket -> { change(Step.BASKET_EXIT, "Открыто Лукошко, закрываю"); schedule(350) }
                age > 18000 -> stopRun("Не увидел переход после ежедневной награды")
                else -> schedule(1200)
            }
            Step.BASKET_EXIT -> when {
                basket -> {
                    if (back()) { change(Step.OPEN_TASKS, "Вышел из Лукошка. Рулетку оставил тебе."); delayAction(1700) }
                }
                isHome -> { change(Step.OPEN_TASKS, "Главный экран, открываю задания"); schedule(400) }
                age > 18000 -> stopRun("Не удалось безопасно выйти из Лукошка")
                else -> schedule(1200)
            }
            Step.OPEN_TASKS -> when {
                isTasks -> { change(Step.FIND_TASK, "Ищу только бесплатные задания"); schedule(650) }
                isHome -> {
                    if (clickButton(labels, image, "задания", "taskNav")) {
                        change(Step.FIND_TASK, "Нажал «Задания»")
                        delayAction(2200)
                    } else stopRun("Кнопка «Задания» недоступна. Открой раздел вручную.")
                }
                age > 18000 -> stopRun("Не могу найти главный экран или задания")
                else -> schedule(900)
            }
            Step.FIND_TASK -> {
                if (visitCta || cartCta) {
                    change(Step.TASK_DIALOG, "Открыто описание задания")
                    schedule(350)
                } else if (!isTasks) {
                    if (age > 16000) stopRun("Список заданий не распознан, не нажимаю наугад")
                    else schedule(1000)
                } else if (stepsTaken >= 12) {
                    change(Step.RETURN_HOME, "Достигнут лимит бесплатных заданий")
                    schedule(500)
                } else {
                    val available = candidates(labels, image).filter { it.id !in attempted }
                    if (available.isEmpty()) {
                        change(Step.RETURN_HOME, "Бесплатные задания закончились. Платные проигнорированы.")
                        schedule(600)
                    } else {
                        val candidate = available.minByOrNull { it.y }!!
                        attempted.add(candidate.id)
                        taskKind = candidate.kind
                        if (candidate.node?.let { safeClick(it) } == true ||
                            candidate.node == null && tap(candidate.x, candidate.y)) {
                            stepsTaken++
                            change(Step.TASK_DIALOG, "Открыл бесплатное задание ${stepsTaken}: ${if (candidate.kind == Kind.VISIT) "посещение" else "корзина"}")
                            delayAction(1500)
                        } else stopRun("Не получилось открыть безопасное задание")
                    }
                }
            }
            Step.TASK_DIALOG -> {
                if (taskKind == Kind.VISIT && visitCta) {
                    if (clickButton(labels, image, "посетить раздел", "visitCta")) {
                        change(Step.VISIT_PAGE, "Перешёл в раздел. Дождусь загрузки и вернусь.")
                        delayAction(3300)
                    } else stopRun("Не удалось нажать «ПОСЕТИТЬ РАЗДЕЛ»")
                } else if (taskKind == Kind.CART && cartCta) {
                    if (clickButton(labels, image, "к товарам", "cartCta")) {
                        change(Step.CART_PAGE, "Открываю товары для добавления в корзину")
                        delayAction(2600)
                    } else stopRun("Не удалось нажать «К ТОВАРАМ»")
                } else if (age > 10000) {
                    stopRun("Карточка задания не совпала с ожидаемой. Безопасная остановка.")
                } else schedule(1000)
            }
            Step.VISIT_PAGE -> {
                if (age < 2400) schedule(850)
                else if (visitCta) {
                    if (age > 12000) stopRun("Не смог открыть раздел после нажатия")
                    else schedule(1000)
                } else if (back()) {
                    store.edit().putInt("visits", store.getInt("visits", 0) + 1).apply()
                    change(Step.RETURN_TASKS, "Вернулся из раздела. Начисление может занять 24 часа.")
                    returns = 0
                    delayAction(1500)
                }
            }
            Step.CART_PAGE -> {
                if (age < 1500) schedule(800)
                else if (cartCta) {
                    if (age > 13000) stopRun("После «К ТОВАРАМ» каталог не открылся")
                    else schedule(900)
                } else {
                    // Only click a clearly identified blue 'add to basket' control on a product-list page.
                    val fromTree = labels.firstOrNull {
                        Regex("^(в корзину|добавить в корзину)$", RegexOption.IGNORE_CASE)
                            .matches(it.text.trim())
                    }
                    val fromImage = image?.let { matcher.blueProductButton(it) }
                    val clicked = if (fromTree != null) safeClick(fromTree.node)
                        else if (fromImage != null && image != null) tap(fromImage.first, fromImage.second)
                        else false
                    if (clicked) {
                        store.edit().putInt("cart", 1).apply()
                        change(Step.RETURN_TASKS, "Нажал добавление в корзину. Проверяю возврат к заданиям.")
                        returns = 0
                        delayAction(1800)
                    } else if (age > 10000) {
                        change(Step.CART_MANUAL, "Кнопка корзины не распознана. Добавь товар сам и нажми «Продолжить».")
                    } else schedule(1000)
                }
            }
            Step.RETURN_TASKS -> when {
                isTasks && !visitCta && !cartCta -> {
                    returns = 0
                    change(Step.FIND_TASK, "Проверяю следующие бесплатные задания")
                    delayAction(1000)
                }
                returns >= 4 -> stopRun("Не смог вернуться к списку заданий. Остановлено.")
                age > 1000 && back() -> {
                    returns++
                    change(Step.RETURN_TASKS, "Возвращаюсь к списку заданий ($returns/4)")
                    delayAction(1300)
                }
                else -> schedule(700)
            }
            Step.RETURN_HOME -> when {
                isHome -> finish()
                returns >= 5 -> stopRun("Не удалось найти главный экран Морковска. Проверь вручную.")
                age > 650 && back() -> {
                    returns++
                    change(Step.RETURN_HOME, "Назад к главному Морковску ($returns/5)")
                    delayAction(1400)
                }
                else -> schedule(750)
            }
            else -> Unit
        }
        // Normal polling must continue even if Ozon doesn't emit accessibility events.
        if (step != Step.STOPPED && step != Step.FINISHED && step != Step.CART_MANUAL) schedule(1800)
    }

    private fun finish() {
        step = Step.FINISHED
        val visits = store.getInt("visits", 0)
        val cart = store.getInt("cart", 0)
        val message = "Готово. Главный экран Морковска открыт. Переходов: $visits, " +
            "добавление в корзину: ${if (cart == 1) "нажато" else "нет"}. " +
            "Рулетка, билеты, платные задания не тронуты. Награды могут начисляться до 24 часов."
        store.edit().putBoolean("running", false).putString("phase", "Готово")
            .putString("status", message).apply()
        removeOverlay()
    }

    private fun has(labels: List<Labeled>, needle: String): Boolean =
        labels.any { it.text.contains(needle, true) }

    private fun isHome(labels: List<Labeled>, image: Bitmap?): Boolean =
        has(labels, "купить билет за") || image?.let { matcher.screen(it, "home") != null } == true

    private fun isTasks(labels: List<Labeled>, image: Bitmap?): Boolean =
        (has(labels, "активные") && has(labels, "выполненные")) ||
            image?.let { matcher.screen(it, "tasksHeader") != null ||
                matcher.screen(it, "visitTask") != null ||
                matcher.screen(it, "cartTask") != null ||
                matcher.screen(it, "paidTask") != null } == true

    private fun candidates(labels: List<Labeled>, image: Bitmap?): List<Candidate> {
        val out = mutableListOf<Candidate>()
        for (l in labels) {
            val text = l.text.trim()
            val kind = when {
                text.startsWith("Посетите раздел", true) -> Kind.VISIT
                text.startsWith("Добавьте любой товар в корзину", true) -> Kind.CART
                else -> continue
            }
            // Never accept a suspicious task or a card containing payment instructions.
            if (Regex("купит|оплат|закаж|оформ|₽|рубл|подпис", RegexOption.IGNORE_CASE).containsMatchIn(text)) continue
            val rect = android.graphics.Rect().also { l.node.getBoundsInScreen(it) }
            if (!l.node.isVisibleToUser || rect.centerY() < 160 || rect.centerY() > screenHeight - 80) continue
            out.add(Candidate(kind, "tree:${text.lowercase()}", rect.centerY(), l.node))
        }
        if (out.isNotEmpty()) return out
        if (image == null) return out
        for ((kind, name) in listOf(Kind.VISIT to "visitTask", Kind.CART to "cartTask")) {
            // Find first unattempted visual task. After a task is completed it
            // should disappear. The fingerprint prevents repeated clicking if it doesn't.
            val hits = mutableListOf<VisualMatcher.Hit>()
            val found = matcher.screen(image, name)
            if (found != null) hits.add(found)
            for (hit in hits) {
                val id = "visual:${kind}:${matcher.taskIdentity(image, hit)}"
                out.add(Candidate(kind, id, hit.y, null, hit.x + 16))
            }
        }
        return out
    }

    private fun clickButton(labels: List<Labeled>, image: Bitmap?, text: String, template: String): Boolean {
        // Click only the expected text, preferably through Accessibility's semantic node.
        val matching = labels.firstOrNull { it.text.trim().equals(text, true) }
        if (matching != null && safeClick(matching.node)) return true
        val hit = image?.let { matcher.screen(it, template) } ?: return false
        return tap(hit.x, hit.y)
    }

    private fun safeClick(target: AccessibilityNodeInfo): Boolean {
        var node: AccessibilityNodeInfo? = target
        repeat(5) {
            val n = node ?: return false
            if (n.isVisibleToUser && n.isEnabled && n.isClickable &&
                n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            node = n.parent
        }
        return false
    }

    private fun tap(x: Int, y: Int): Boolean {
        val path = Path().apply {
            moveTo(x * screenWidth / 691f, y * screenHeight / 1536f)
        }
        val gesture = GestureDescription.Builder().addStroke(
            GestureDescription.StrokeDescription(path, 0, 115)
        ).build()
        return dispatchGesture(gesture, null, null)
    }

    private fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    private fun flatten(root: AccessibilityNodeInfo): List<Labeled> {
        val list = mutableListOf<Labeled>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        while (stack.isNotEmpty() && ++visited <= 550) {
            val node = stack.removeLast()
            val s = (node.text?.toString() ?: node.contentDescription?.toString() ?: "").trim()
            if (s.isNotEmpty()) list.add(Labeled(node, s))
            for (i in node.childCount - 1 downTo 0) node.getChild(i)?.let { stack.add(it) }
        }
        store.edit().putString("diagnostic", "Распознано ${list.size} элементов:\n" +
            list.asSequence().map { it.text }
                .filter { Regex("посет|добав|корзин|ежеднев|забрать|задан|купит|активн|лукош|к товарам|назад", RegexOption.IGNORE_CASE).containsMatchIn(it) }
                .take(30).map { it.take(110).replace(Regex("\\d{7,}"), "*******") }
                .joinToString("\n")).apply()
        return list
    }

    private fun change(newStep: Step, message: String) {
        step = newStep
        stateSince = SystemClock.elapsedRealtime()
        logs.add("${newStep.name}: $message")
        if (logs.size > 40) logs.removeAt(0)
        store.edit().putString("phase", newStep.name).putString("status", message).apply()
        title?.text = "🥕 $message"
        resume?.visibility = if (newStep == Step.CART_MANUAL) View.VISIBLE else View.GONE
    }
    private fun delayAction(ms: Long) {
        nextAllowed = SystemClock.elapsedRealtime() + ms
        schedule(ms + 80)
    }

    private fun showOverlay() {
        removeOverlay()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(30, 15, 80))
            setPadding(7, 1, 7, 1)
        }
        val t = TextView(this).apply {
            text = "🥕 Морковск Авто работает"
            setTextColor(Color.WHITE); textSize = 11f; maxLines = 2
        }
        val next = Button(this).apply {
            text = "Продолжить"; textSize = 9f; visibility = View.GONE
            setOnClickListener { manualCartDone() }
        }
        val stop = Button(this).apply {
            text = "СТОП"; textSize = 10f
            setOnClickListener { stopRun() }
        }
        val dp = resources.displayMetrics.density
        bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(next, LinearLayout.LayoutParams((106 * dp).toInt(), -2))
        bar.addView(stop, LinearLayout.LayoutParams((70 * dp).toInt(), -2))
        val lp = WindowManager.LayoutParams(-1, -2,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP; y = (22 * dp).toInt() }
        try {
            wm.addView(bar, lp)
            overlay = bar; title = t; resume = next
        } catch (_: Exception) { /* overlay optional */ }
    }
    private fun removeOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        overlay = null; title = null; resume = null
    }
}
