package ru.stereoo.morkovsk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import kotlin.math.abs

/**
 * Only local, small UI fragments from the owner's screenshots are compared.
 * No network requests, OCR, screenshots storage or image uploads.
 * Coordinates refer to the provided 691 x 1536 reference screenshots.
 */
class VisualMatcher(private val context: Context) {
    data class Hit(val rect: Rect, val score: Double) {
        val x: Int get() = rect.centerX()
        val y: Int get() = rect.centerY()
    }
    private val templates = mutableMapOf<String, Bitmap>()
    private val templatePixels = mutableMapOf<String, IntArray>()
    private var cachedImage: Bitmap? = null
    private var cachedPixels: IntArray? = null
    private val W = 691
    private val H = 1536

    fun normalized(raw: Bitmap): Bitmap? {
        if (abs(raw.width.toDouble() / raw.height - W.toDouble() / H) > 0.05) return null
        return if (raw.width == W && raw.height == H) raw
        else Bitmap.createScaledBitmap(raw, W, H, true)
    }

    private fun template(name: String): Bitmap? {
        if (name in templates) return templates[name]
        return try {
            val bmp = context.assets.open("matcher/$name.png").use { BitmapFactory.decodeStream(it) }
            if (bmp != null) templates[name] = bmp
            bmp
        } catch (_: Exception) { null }
    }

    /** X/Y are restricted search centers in the reference screenshot. */
    fun locate(image: Bitmap, name: String, x1: Int, x2: Int, y1: Int, y2: Int,
               tolerance: Double = 0.145): Hit? {
        val t = template(name) ?: return null
        if (image !== cachedImage) {
            cachedImage = image
            cachedPixels = IntArray(W * H).also { image.getPixels(it, 0, W, 0, 0, W, H) }
        }
        val source = cachedPixels ?: return null
        val ref = templatePixels.getOrPut(name) {
            IntArray(t.width * t.height).also { t.getPixels(it, 0, t.width, 0, 0, t.width, t.height) }
        }
        val w = t.width; val h = t.height
        val sx = maxOf(0, x1); val ex = minOf(W - w, x2)
        val sy = maxOf(0, y1); val ey = minOf(H - h, y2)
        if (ex < sx || ey < sy) return null
        // For every placement sample a grid with 3-pixel stride. Full-resolution
        // RGB comparison avoids treating blue product buttons as yellow prize buttons.
        var best = Double.MAX_VALUE
        var bx = -1; var by = -1
        val stepX = maxOf(3, w / 65)
        val stepY = maxOf(3, h / 11)
        for (y in sy..ey step 2) for (x in sx..ex step 2) {
            var total = 0L
            var samples = 0
            for (ty in 1 until h step stepY) {
                for (tx in 1 until w step stepX) {
                    val a = source[(y + ty) * W + (x + tx)]
                    val b = ref[ty * w + tx]
                    total += abs((a shr 16 and 255) - (b shr 16 and 255))
                    total += abs((a shr 8 and 255) - (b shr 8 and 255))
                    total += abs((a and 255) - (b and 255))
                    samples++
                }
                // early abandon clearly worse placements
                if (best < 0.06 && samples > 25 && total.toDouble() / (samples * 765) > best * 1.3) break
            }
            if (samples == 0) continue
            val score = total.toDouble() / (samples * 765)
            if (score < best) { best = score; bx = x; by = y }
            if (score < 0.012) return Hit(Rect(bx, by, bx+w, by+h), score)
        }
        return if (bx >= 0 && best <= tolerance) Hit(Rect(bx, by, bx+w, by+h), best) else null
    }

    fun screen(image: Bitmap, name: String): Hit? = when (name) {
        "daily" -> locate(image, name, 120, 170, 270, 380, 0.16)
        "claim" -> locate(image, name, 220, 320, 910, 1030, 0.14)
        "basketOffer" -> locate(image, name, 185, 285, 1040, 1140, 0.09)
        "basketTitle" -> locate(image, name, 60, 130, 175, 255, 0.16)
        "home" -> locate(image, name, 45, 125, 175, 300, 0.14)
        "taskNav" -> locate(image, name, 200, 250, 1000, 1055, 0.09)
        "tasksHeader" -> locate(image, name, 0, 45, 280, 365, 0.16)
        "visitTask" -> locate(image, name, 87, 128, 170, 1350, 0.10)
        "cartTask" -> locate(image, name, 86, 133, 170, 1350, 0.10)
        "paidTask" -> locate(image, name, 85, 133, 170, 1350, 0.10)
        "visitCta" -> locate(image, name, 194, 265, 1325, 1430, 0.09)
        "cartCta" -> locate(image, name, 215, 295, 1325, 1430, 0.09)
        else -> null
    }

    fun taskIdentity(image: Bitmap, hit: Hit): String {
        val y = hit.y
        // Title text, not row position or timer: a stable per-task fingerprint.
        val area = Rect(111, maxOf(0, y - 12), 575, minOf(H, y + 15))
        val values = StringBuilder()
        for (dy in 0..11) for (dx in 0..80) {
            val px = area.left + dx * (area.width() - 1) / 80
            val py = area.top + dy * (area.height() - 1) / 11
            val c = image.getPixel(px, py)
            // Compare text brightness against the dark violet task-card background.
            val bright = ((c shr 16 and 255) + (c shr 8 and 255) + (c and 255)) / 3
            values.append(if (bright > 145) '1' else '0')
        }
        return values.toString().hashCode().toString()
    }

    fun blueProductButton(image: Bitmap): Pair<Int, Int>? {
        // Product-list route only. Confirm visible large Ozon blue buttons
        // rather than guessing a coordinate based only on the previous page.
        for (y in 860..1180 step 12) {
            for (x in listOf(120, 160, 190)) {
                var good = 0
                for (dx in -35..35 step 10) for (dy in -10..10 step 10) {
                    val c = image.getPixel(x + dx, y + dy)
                    val r = c shr 16 and 255; val g = c shr 8 and 255; val b = c and 255
                    if (b > 205 && b > r * 2.2 && g > 65 && g < 175 && r < 75) good++
                }
                if (good >= 16 && (image.getPixel(20, 180) and 0xFFFFFF) > 0xB0B0B0) return x to y
            }
        }
        return null
    }
}
