plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.stereoo.morkovsk"
    compileSdk = 34

    defaultConfig {
        applicationId = "ru.stereoo.morkovsk"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "0.4.1-androidforge"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
