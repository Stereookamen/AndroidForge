AI Stereoo — минимальный безопасный патч темы CyanBridge

Что меняет:
- Название приложения в Android Launcher на AI Stereoo.
- Цветовые ресурсы существующего интерфейса: тёмный navy, бирюзовый и фиолетовый акценты.

Что намеренно НЕ меняет:
- MainActivity, Bluetooth/BLE, Wi‑Fi Direct и протокол передачи файлов.
- Поток отправки фотографии в ИИ и озвучивание ответа.
- Существующие экраны/идентификаторы View Binding.

Как применить:
1. Скачайте исходный репозиторий:
   https://github.com/FerSaiyan/Alternative-HeyCyan-App-and-SDK
2. Откройте android/CyanBridge/app/src/main/res/values/
3. Замените colors.xml файлом из архива.
4. В исходном strings.xml замените только существующую строку app_name:
   <string name="app_name">CyanBridge</string>
   на
   <string name="app_name">AI Stereoo</string>
   Не заменяйте весь strings.xml, там много нужных строк.
5. Собирайте из android/CyanBridge командой ./gradlew assembleDebug с Java 17+.

Важно:
Это именно небольшой патч темы/брендинга, а не полный исходный проект и не готовый APK.
Он не реализует заново все 10 экранов макета. Это первый низкорисковый шаг, который не должен затрагивать рабочую передачу фотографий.
