package ru.openiptv.finder

import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class Channel(val name: String, val url: String, val group: String = "Без категории")
data class Source(val name: String, val url: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { FinderApp() } }
    }
}

private val http = OkHttpClient.Builder()
    .connectTimeout(12, TimeUnit.SECONDS)
    .readTimeout(25, TimeUnit.SECONDS)
    .followRedirects(true)
    .build()

private val catalogs = listOf(
    "Весь мир" to "https://iptv-org.github.io/iptv/index.m3u",
    "Россия" to "https://iptv-org.github.io/iptv/countries/ru.m3u",
    "Германия" to "https://iptv-org.github.io/iptv/countries/de.m3u",
    "Русский язык" to "https://iptv-org.github.io/iptv/languages/rus.m3u",
    "Новости" to "https://iptv-org.github.io/iptv/categories/news.m3u",
    "Спорт" to "https://iptv-org.github.io/iptv/categories/sports.m3u",
    "Кино" to "https://iptv-org.github.io/iptv/categories/movies.m3u",
    "Детские" to "https://iptv-org.github.io/iptv/categories/kids.m3u"
)

@Composable
fun FinderApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("iptv", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var catalog by remember { mutableStateOf(catalogs.first().first) }
    var query by remember { mutableStateOf("") }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var favorites by remember { mutableStateOf(loadFavorites(prefs)) }
    var results by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var status by remember { mutableStateOf("Выберите каталог и нажмите «Загрузить»") }
    var loading by remember { mutableStateOf(false) }
    var playerChannel by remember { mutableStateOf<Channel?>(null) }
    var discovered by remember { mutableStateOf<List<Source>>(emptyList()) }
    var expanded by remember { mutableStateOf(false) }

    fun saveFavs() = saveFavorites(prefs, favorites)
    fun load(url: String, label: String) {
        scope.launch {
            loading = true; status = "Загружаю: $label"; results = emptyMap()
            try {
                val list = withContext(Dispatchers.IO) { parseM3u(fetch(url)) }
                channels = list
                status = "Загружено каналов: ${list.size}"
                tab = 0
            } catch (e: Exception) { status = "Ошибка загрузки: ${e.message}" }
            finally { loading = false }
        }
    }
    val current = if (tab == 2) favorites else channels
    val visible = current.filter { it.name.contains(query, true) || it.group.contains(query, true) }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("Open IPTV Finder 2", style = MaterialTheme.typography.headlineMedium)
        Text("Открытые IPTV-каталоги • поиск • проверка • избранное • плеер")
        Spacer(Modifier.height(8.dp))
        TabRow(selectedTabIndex = tab) {
            listOf("Каналы", "Источники", "Избранное").forEachIndexed { i, s ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(s) })
            }
        }
        Spacer(Modifier.height(8.dp))
        if (tab == 0) {
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(catalog) }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    catalogs.forEach { item -> DropdownMenuItem(text = { Text(item.first) }, onClick = {
                        catalog = item.first; expanded = false
                    }) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { load(catalogs.first { it.first == catalog }.second, catalog) }, enabled = !loading) {
                    Text("Загрузить каталог")
                }
                OutlinedButton(onClick = {
                    scope.launch {
                        loading = true; status = "Проверяю ${channels.size} потоков…"
                        val map = withContext(Dispatchers.IO) {
                            channels.associate { c -> c.url to probe(c.url) }
                        }
                        results = map
                        val good = map.values.count { it.startsWith("Доступен") }
                        status = "Проверка завершена: $good из ${map.size} отвечают"
                        loading = false
                    }
                }, enabled = channels.isNotEmpty() && !loading) { Text("Проверить все") }
            }
        } else if (tab == 1) {
            Text("Поиск публичных M3U-репозиториев GitHub")
            Button(onClick = {
                scope.launch {
                    loading = true; status = "Ищу репозитории…"
                    try {
                        discovered = withContext(Dispatchers.IO) { discoverSources() }
                        status = "Найдено M3U-источников: ${discovered.size}"
                    } catch (e: Exception) { status = "Ошибка поиска: ${e.message}" }
                    finally { loading = false }
                }
            }, enabled = !loading) { Text("Найти новые источники") }
            LazyColumn(Modifier.weight(1f)) {
                items(discovered) { src ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(src.name, style = MaterialTheme.typography.titleSmall)
                        Text(src.url, style = MaterialTheme.typography.labelSmall)
                        TextButton(onClick = { load(src.url, src.name) }) { Text("Загрузить плейлист") }
                        HorizontalDivider()
                    }
                }
            }
        } else {
            Text("Сохранённые каналы: ${favorites.size}")
        }
        if (tab != 1) {
            OutlinedTextField(query, { query = it }, label = { Text("Фильтр каналов") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text(status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            LazyColumn(Modifier.weight(1f)) {
                items(visible) { c ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Text(c.name, style = MaterialTheme.typography.titleSmall)
                        Text(c.group, style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { playerChannel = c }) { Text("▶ Смотреть") }
                            TextButton(onClick = {
                                favorites = if (favorites.any { it.url == c.url }) favorites.filterNot { it.url == c.url }
                                    else favorites + c
                                saveFavs()
                            }) { Text(if (favorites.any { it.url == c.url }) "★" else "☆") }
                            Text(results[c.url] ?: "")
                        }
                        HorizontalDivider()
                    }
                }
            }
            if (playerChannel != null) {
                Text("Сейчас: ${playerChannel!!.name}", style = MaterialTheme.typography.titleMedium)
                IptvPlayer(playerChannel!!.url, Modifier.fillMaxWidth().height(220.dp))
                TextButton(onClick = { playerChannel = null }) { Text("Закрыть плеер") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val text = buildString {
                        append("#EXTM3U\n")
                        visible.forEach { append("#EXTINF:-1 group-title=\"${it.group}\",${it.name}\n${it.url}\n") }
                    }
                    shareText(context, text)
                }, enabled = visible.isNotEmpty()) { Text("Экспорт M3U") }
                OutlinedButton(onClick = {
                    val bad = results.filterValues { !it.startsWith("Доступен") }.keys
                    channels = channels.filterNot { it.url in bad }
                    status = "Удалено неответивших ссылок: ${bad.size}"
                }, enabled = results.isNotEmpty()) { Text("Удалить нерабочие") }
            }
        } else {
            Text(status, style = MaterialTheme.typography.bodySmall)
        }
        Text("Только публичные источники. Проверка доступности ориентировочная; права на просмотр проверяйте самостоятельно.",
            style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun IptvPlayer(url: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val player = remember(url) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true } }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(modifier = modifier, factory = { ctx ->
        PlayerView(ctx).apply { this.player = player; layoutParams = ViewGroup.LayoutParams(-1, -1) }
    }, update = { it.player = player })
}

private fun fetch(url: String): String {
    val req = Request.Builder().url(url).header("User-Agent", "OpenIPTVFinder/2.0").build()
    http.newCall(req).execute().use { r ->
        if (!r.isSuccessful) error("HTTP ${r.code}")
        return r.body?.string() ?: error("Пустой ответ")
    }
}
private fun parseM3u(data: String): List<Channel> {
    val out = mutableListOf<Channel>(); var name = ""; var group = "Без категории"
    data.lineSequence().forEach { raw ->
        val s = raw.trim()
        if (s.startsWith("#EXTINF", true)) {
            name = s.substringAfterLast(',').trim().ifBlank { "Без названия" }
            group = Regex("""group-title="([^"]+)"""").find(s)?.groupValues?.get(1) ?: "Без категории"
        } else if (s.startsWith("http://") || s.startsWith("https://")) {
            if (name.isNotBlank()) out.add(Channel(name, s, group))
            name = ""
        }
    }
    return out.distinctBy { it.url }
}
private fun probe(url: String): String {
    val start = System.currentTimeMillis()
    return try {
        val req = Request.Builder().url(url).get().header("Range", "bytes=0-0")
            .header("User-Agent", "VLC/3.0 OpenIPTVFinder").build()
        http.newCall(req).execute().use { r ->
            val ms = System.currentTimeMillis() - start
            if (r.isSuccessful || r.code == 206) "Доступен • ${ms} мс" else "Ошибка HTTP ${r.code}"
        }
    } catch (e: Exception) { "Недоступен" }
}
private fun discoverSources(): List<Source> {
    val q = URLEncoder.encode("iptv m3u", "UTF-8")
    val req = Request.Builder().url("https://api.github.com/search/repositories?q=$q&sort=updated&per_page=30")
        .header("Accept", "application/vnd.github+json").header("User-Agent", "OpenIPTVFinder").build()
    val json = http.newCall(req).execute().use { r ->
        if (!r.isSuccessful) error("GitHub API HTTP ${r.code}")
        JSONObject(r.body?.string() ?: "{}")
    }
    val out = mutableListOf<Source>()
    val repos = json.optJSONArray("items") ?: return out
    for (i in 0 until repos.length()) {
        val repo = repos.getJSONObject(i)
        val full = repo.optString("full_name")
        val branch = repo.optString("default_branch", "master")
        val contentsReq = Request.Builder().url("https://api.github.com/repos/$full/contents")
            .header("User-Agent", "OpenIPTVFinder").build()
        try {
            val arr = http.newCall(contentsReq).execute().use { r ->
                if (!r.isSuccessful) return@use null
                org.json.JSONArray(r.body?.string() ?: "[]")
            } ?: continue
            for (j in 0 until arr.length()) {
                val f = arr.getJSONObject(j)
                val name = f.optString("name")
                if (name.endsWith(".m3u", true) || name.endsWith(".m3u8", true)) {
                    val raw = "https://raw.githubusercontent.com/$full/$branch/$name"
                    out.add(Source("$full / $name", raw))
                }
            }
        } catch (_: Exception) { }
        if (out.size >= 60) break
    }
    return out.distinctBy { it.url }
}
private fun loadFavorites(prefs: android.content.SharedPreferences): List<Channel> {
    val raw = prefs.getString("favorites", "") ?: ""
    if (raw.isBlank()) return emptyList()
    return raw.lines().mapNotNull {
        val p = it.split('\t')
        if (p.size == 3) Channel(p[0], p[1], p[2]) else null
    }
}
private fun saveFavorites(prefs: android.content.SharedPreferences, list: List<Channel>) {
    prefs.edit().putString("favorites", list.joinToString("\n") { "${it.name}\t${it.url}\t${it.group}" }).apply()
}
private fun shareText(context: Context, text: String) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, text)
    }
    context.startActivity(android.content.Intent.createChooser(intent, "Экспорт плейлиста"))
}
