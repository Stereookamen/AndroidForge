package ru.stereoo.vpnwatch;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parses the known server-side HTML templates of the user's Stereoo VPN Manager. */
final class StereooHtmlParser {
    static final class Result {
        final Map<String, String> values = new LinkedHashMap<>();
        int apiErrors;
        boolean dashboardFound;
        String source = "";
        String get(String key) { return values.getOrDefault(key, "—"); }
        void put(String key, String value) { if (value != null && !value.trim().isEmpty()) values.put(key,value.trim()); }
    }

    private static final Pattern KPI = Pattern.compile(
            "<div\\s+class=[\\\"']kpi(?:\\s+[^\\\"']*)?[\\\"'][^>]*>"
                    + ".*?<div\\s+class=[\\\"']kpi-label[\\\"'][^>]*>(.*?)</div>"
                    + ".*?<div\\s+class=[\\\"']kpi-value(?:\\s+[^\\\"']*)?[\\\"'][^>]*>(.*?)</div>",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern TRAFFIC = Pattern.compile(
            "<span\\s+class=[\\\"']traffic[\\\"'][^>]*>(.*?)</span>",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern SOON_THREE = Pattern.compile("Истекают\\s+за\\s+3\\s+дня\\s*:\\s*(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern CSRF = Pattern.compile(
            "<input\\b(?=[^>]*\\bname\\s*=\\s*[\\\"']csrf[\\\"'])(?=[^>]*\\bvalue\\s*=\\s*[\\\"']([^\\\"']+)[\\\"'])[^>]*>",
            Pattern.CASE_INSENSITIVE);

    static String csrf(String html) {
        Matcher m = CSRF.matcher(html);
        return m.find() ? unescape(m.group(1)) : null;
    }
    static boolean isLogin(String html) {
        return html.contains("name=\"password\"") && html.contains("name=\"csrf\"")
                && !html.contains("class=\"kpis");
    }
    static boolean isDashboard(String html) {
        return html.contains("kpi-label") && html.contains("kpi-value")
                && (html.contains("ВСЕ КЛИЕНТЫ") || html.contains("КЛИЕНТЫ VPN"));
    }

    static Result clients(String html) {
        Result r = new Result();
        r.source = "clients";
        Map<String,String> cards = readCards(html);
        r.put("clients", lookup(cards,"все клиенты"));
        r.put("active", lookup(cards,"активные"));
        r.put("expired", lookup(cards,"истёкшие / лимит","истекшие / лимит"));
        r.put("disabled", lookup(cards,"отключённые","отключенные"));
        Matcher soon = SOON_THREE.matcher(stripTags(html));
        if (soon.find()) r.put("soon3", soon.group(1));
        double totalUsedGb = 0.0;
        int count = 0;
        Matcher tr = TRAFFIC.matcher(html);
        while(tr.find()) {
            String raw = stripTags(tr.group(1));
            String used = raw.split("/",2)[0].replace(',', '.').trim();
            try { totalUsedGb += Double.parseDouble(used); count++; }
            catch(NumberFormatException ignored) { }
        }
        if (count > 0) r.put("traffic", String.format(Locale.US, "%.1f ГБ", totalUsedGb));
        r.apiErrors = countErrorAlerts(html);
        r.dashboardFound = r.values.containsKey("clients");
        return r;
    }

    static Result payments(String html) {
        Result r = new Result();
        r.source = "payments";
        Map<String,String> cards = readCards(html);
        r.put("revenue", lookup(cards,"получено за месяц"));
        r.put("paid", lookup(cards,"оплативших за месяц"));
        r.put("due7", lookup(cards,"к продлению за 7 дней"));
        r.put("allTime", lookup(cards,"все поступления"));
        r.apiErrors = countErrorAlerts(html);
        r.dashboardFound = r.values.containsKey("revenue");
        return r;
    }
    private static Map<String,String> readCards(String html) {
        Map<String,String> result = new LinkedHashMap<>();
        Matcher m = KPI.matcher(html);
        while(m.find()) {
            String label = stripTags(m.group(1)).replaceAll("\\s+", " ").toLowerCase(Locale.ROOT).trim();
            String val = stripTags(m.group(2)).trim();
            result.put(label,val);
        }
        return result;
    }
    private static String lookup(Map<String,String> cards, String... wanted) {
        for (Map.Entry<String,String> entry : cards.entrySet()) {
            for (String key : wanted) if (entry.getKey().contains(key)) return entry.getValue();
        }
        return null;
    }
    private static int countErrorAlerts(String html) {
        Matcher m = Pattern.compile("<div\\s+class=[\\\"'][^\\\"']*\\balert\\s+error\\b", Pattern.CASE_INSENSITIVE).matcher(html);
        int n=0;
        while(m.find()) n++;
        return n;
    }
    private static String stripTags(String html) {
        return unescape(html.replaceAll("(?s)<[^>]*>"," ")).replaceAll("\\s+", " ").trim();
    }
    private static String unescape(String value) {
        // Only HTML entities used by these templates need decoding.
        return value.replace("&nbsp;", " ").replace("&#160;", " ")
                .replace("&quot;", "\"").replace("&#39;", "'")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&");
    }
}
