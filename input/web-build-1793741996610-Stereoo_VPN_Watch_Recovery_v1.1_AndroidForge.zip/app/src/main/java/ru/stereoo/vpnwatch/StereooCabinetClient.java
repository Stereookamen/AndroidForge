package ru.stereoo.vpnwatch;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.Dns;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

/**
 * Read-only HTTPS client for Stereoo VPN Manager. Two independent authentication
 * stages are supported: optional Caddy HTTP Basic and the Flask panel login.
 *
 * Bluetooth DNS recovery is deliberately restricted to the cabinet hostname:
 * when system DNS fails, an optionally configured IPv4 address is used for the
 * TCP connection. OkHttp still uses cabinet.stereoo-vpn.ru for TLS SNI and
 * normal certificate/hostname validation. Never disable TLS verification.
 */
final class StereooCabinetClient {
    private static final String HOST = "cabinet.stereoo-vpn.ru";
    private static final String ROOT = "https://" + HOST;
    private final String basic;
    private final String panelPassword;
    private final String fallbackIp;
    private final OkHttpClient http;
    private volatile boolean fallbackWasUsed = false;

    StereooCabinetClient(String caddyUser, String caddyPass, String panelPassword, String fallbackIp) {
        this.basic = caddyUser != null && !caddyUser.isEmpty() && caddyPass != null && !caddyPass.isEmpty()
                ? okhttp3.Credentials.basic(caddyUser, caddyPass, StandardCharsets.UTF_8) : null;
        this.panelPassword = panelPassword;
        this.fallbackIp = fallbackIp == null ? "" : fallbackIp.trim();

        final byte[] fallbackBytes = validateIpv4(this.fallbackIp);
        final List<Cookie> cookies = new ArrayList<>();
        CookieJar cookieJar = new CookieJar() {
            @Override public synchronized void saveFromResponse(HttpUrl url, List<Cookie> received) {
                synchronized (cookies) {
                    long now = System.currentTimeMillis();
                    cookies.removeIf(c -> c.expiresAt() <= now);
                    for (Cookie c : received) {
                        cookies.removeIf(old -> old.name().equals(c.name())
                                && old.domain().equals(c.domain()) && old.path().equals(c.path()));
                        if (c.expiresAt() > now) cookies.add(c);
                    }
                }
            }
            @Override public List<Cookie> loadForRequest(HttpUrl url) {
                synchronized (cookies) {
                    List<Cookie> result = new ArrayList<>();
                    for (Cookie c : cookies) if (c.matches(url)) result.add(c);
                    return result;
                }
            }
        };

        Dns dns = hostname -> {
            try {
                return Dns.SYSTEM.lookup(hostname);
            } catch (UnknownHostException original) {
                if (HOST.equalsIgnoreCase(hostname) && fallbackBytes != null) {
                    fallbackWasUsed = true;
                    List<InetAddress> addresses = new ArrayList<>();
                    addresses.add(InetAddress.getByAddress(fallbackBytes));
                    return addresses;
                }
                throw original;
            }
        };
        http = new OkHttpClient.Builder()
                .dns(dns)
                .cookieJar(cookieJar)
                .followRedirects(false)
                .followSslRedirects(false)
                .connectTimeout(12, TimeUnit.SECONDS)
                .readTimeout(16, TimeUnit.SECONDS)
                .callTimeout(35, TimeUnit.SECONDS)
                .build();
    }

    private static byte[] validateIpv4(String value) {
        if (value == null || value.isEmpty()) return null;
        String[] parts = value.split("\\.", -1);
        if (parts.length != 4) throw new IllegalArgumentException("Резервный IP должен быть IPv4 (4 группы цифр).");
        byte[] out = new byte[4];
        for (int i = 0; i < 4; i++) {
            if (!parts[i].matches("[0-9]{1,3}")) throw new IllegalArgumentException("Неверный резервный IP.");
            int n = Integer.parseInt(parts[i]);
            if (n > 255) throw new IllegalArgumentException("Неверный резервный IP.");
            out[i] = (byte)n;
        }
        return out;
    }

    static final class Snapshot {
        StereooHtmlParser.Result clients;
        StereooHtmlParser.Result payments;
        boolean usedIpFallback;
    }

    Snapshot getSnapshot() throws Exception {
        Response first = get("/");
        if (first.code == 401) throw new IllegalArgumentException("Caddy требует логин и пароль HTTP Basic. Открой «Изменить вход» и введи данные Caddy.");
        if (first.code == 302 || first.code == 303 || StereooHtmlParser.isLogin(first.html)) {
            login();
            first = get("/");
        }
        if (first.code == 401) throw new IllegalArgumentException("HTTP 401: неверные данные Caddy.");
        if (first.code != 200) throw new IllegalStateException("Кабинет вернул HTTP " + first.code);
        if (!StereooHtmlParser.isDashboard(first.html)) {
            if (StereooHtmlParser.isLogin(first.html)) throw new IllegalArgumentException("Неверный пароль VPN Manager.");
            throw new IllegalStateException("Не обнаружена страница клиентов. Возможно, изменился шаблон.");
        }
        Snapshot result = new Snapshot();
        result.clients = StereooHtmlParser.clients(first.html);
        Response pay = get("/payments");
        if (pay.code == 401) throw new IllegalArgumentException("Caddy отверг HTTP Basic на /payments.");
        if (pay.code == 200 && pay.html.contains("ПОЛУЧЕНО ЗА МЕСЯЦ"))
            result.payments = StereooHtmlParser.payments(pay.html);
        else result.payments = new StereooHtmlParser.Result();
        result.usedIpFallback = fallbackWasUsed;
        return result;
    }

    private void login() throws Exception {
        Response loginPage = get("/login");
        if (loginPage.code == 401) throw new IllegalArgumentException("Caddy требует правильный логин и пароль.");
        if (loginPage.code != 200) throw new IllegalStateException("Ошибка страницы входа: HTTP " + loginPage.code);
        String csrf = StereooHtmlParser.csrf(loginPage.html);
        if (csrf == null) throw new IllegalStateException("Не найден CSRF формы входа.");
        String form = "csrf=" + java.net.URLEncoder.encode(csrf, "UTF-8")
                + "&password=" + java.net.URLEncoder.encode(panelPassword, "UTF-8");
        Response sent = request("/login", "POST", form);
        if (sent.code == 401) throw new IllegalArgumentException("Неверный логин или пароль Caddy.");
        if (sent.code == 403) throw new IllegalStateException("Ошибка проверки CSRF. Повтори вход.");
        if (sent.code == 429) throw new IllegalArgumentException("Слишком много попыток входа. Повтори позже.");
        if (sent.code == 200 && (sent.html.contains("Неверный пароль") || StereooHtmlParser.isLogin(sent.html)))
            throw new IllegalArgumentException("Неверный пароль VPN Manager.");
        if (sent.code != 302 && sent.code != 303 && sent.code != 200)
            throw new IllegalStateException("Ошибка входа: HTTP " + sent.code);
    }

    private Response get(String path) throws Exception { return request(path, "GET", null); }

    private Response request(String path, String method, String form) throws Exception {
        if (!path.equals("/") && !path.equals("/login") && !path.equals("/payments"))
            throw new IllegalArgumentException("Запрещённый путь: " + path);
        Request.Builder request = new Request.Builder()
                .url(ROOT + path)
                .header("Accept", "text/html")
                .header("User-Agent", "StereooVPNWatch/1.1 (Wear OS)");
        if (basic != null) request.header("Authorization", basic);
        if (form == null) request.get();
        else {
            RequestBody body = RequestBody.create(
                    MediaType.parse("application/x-www-form-urlencoded; charset=utf-8"), form);
            request.post(body);
        }
        try (okhttp3.Response resp = http.newCall(request.build()).execute()) {
            InputStream input = resp.body() == null ? null : resp.body().byteStream();
            byte[] bytes = readMax(input, 2 * 1024 * 1024);
            return new Response(resp.code(), new String(bytes, StandardCharsets.UTF_8));
        } catch (UnknownHostException e) {
            throw new IllegalStateException("Ошибка DNS по Bluetooth. Проверь интернет часов или укажи текущий IPv4 сервера в «Изменить вход».", e);
        }
    }

    private static byte[] readMax(InputStream in, int limit) throws Exception {
        if (in == null) return new byte[0];
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) {
            if (baos.size() + n > limit) throw new IllegalStateException("Слишком большой HTML-ответ сервера.");
            baos.write(buffer, 0, n);
        }
        return baos.toByteArray();
    }

    private static final class Response {
        final int code;
        final String html;
        Response(int code, String html) { this.code = code; this.html = html; }
    }
}
