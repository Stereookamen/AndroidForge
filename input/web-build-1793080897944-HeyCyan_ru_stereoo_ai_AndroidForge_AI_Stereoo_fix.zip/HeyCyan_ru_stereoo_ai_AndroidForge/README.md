# Stereoo AI / HeyCyan APK rebuild project

Gradle project for AndroidForge / GitHub Actions. It uses the provided original APK as the baseline and rebuilds it with Apktool; it is not a source-level Android Studio recompilation.

## Build output

`output/Stereoo_AI_1.0.apk` is the actual rebuilt and signed APK. The workflow uploads this file directly, not the original APK or a payload-only release artifact.

## Changes

- Manifest application ID: `ru.stereoo.ai`
- `versionName`: `1.0`
- Existing `versionCode` is retained.
- App components are kept fully qualified to avoid changing class resolution when the manifest package changes.
- Provider authorities containing the old package are updated.
- APK is zip-aligned and signed with a generated test key.

## Build prerequisites

Java 17+, Android SDK build-tools, Python 3, and `apktool.jar` at the project root.

```bash
gradle clean assembleDebug
```

## Important installation note

The rebuilt APK is signed with a new test key. It cannot update the official HeyCyan installation signed with the original certificate. If Android reports a signature conflict, uninstall the existing HeyCyan app first (which may remove its local app data), then install this APK.

This workflow must be tested on GitHub Actions before treating the APK as verified. Apktool can fail on app-specific resources or manifest constructs, and repackaging does not guarantee runtime behavior.


Compatibility note: the repackaging script sets targetSdkVersion to Android 15 (API 35) while retaining the original minSdkVersion. This avoids declaring an Android 16 target on Android 15 devices.
