#!/usr/bin/env bash
set -euo pipefail

APK_IN="original/HeyCyan.apk"
DECODED="work/decoded"
OUT="output"
APKTOOL_JAR="apktool.jar"
APKTOOL_VERSION="2.12.1"

# AndroidForge extracts the project ZIP into a clean workspace, so a downloaded
# Apktool JAR from a previous local run is not guaranteed to be present.
if [ ! -s "$APKTOOL_JAR" ]; then
  APKTOOL_URL="https://github.com/iBotPeaches/Apktool/releases/download/v${APKTOOL_VERSION}/apktool_${APKTOOL_VERSION}.jar"
  echo "Downloading Apktool ${APKTOOL_VERSION}..."
  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 --retry-delay 2 "$APKTOOL_URL" -o "$APKTOOL_JAR"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$APKTOOL_JAR" "$APKTOOL_URL"
  else
    echo "Neither curl nor wget is available to download Apktool"
    exit 5
  fi
fi

APKTOOL=(java -jar "$APKTOOL_JAR")

test -f "$APK_IN" || { echo "Missing original APK: $APK_IN"; exit 2; }
rm -rf "$DECODED" work/unsigned.apk work/aligned.apk
rm -f "$OUT/Stereoo_AI_1.0.apk"
mkdir -p "$OUT" work

"${APKTOOL[@]}" d -f "$APK_IN" -o "$DECODED"

# Change app ID and display version while keeping the original component classes
# explicitly qualified so changing the manifest package does not redirect them.
python3 - <<'PY'
import xml.etree.ElementTree as ET
from pathlib import Path

manifest = Path("work/decoded/AndroidManifest.xml")
old_pkg = "com.glasssutdio.wear"
new_pkg = "ru.stereoo.ai"
android = "{http://schemas.android.com/apk/res/android}"

tree = ET.parse(manifest)
root = tree.getroot()
if root.tag != "manifest":
    raise SystemExit("Unexpected manifest root")

root.set("package", new_pkg)
root.set(android + "versionName", "1.0")
root.set(android + "label", "AI Stereoo")

# The source APK declares targetSdkVersion 36 (Android 16). On Android 15
# devices this can be rejected by the package installer as incompatible.
# Keep minSdkVersion untouched, but target the current Android 15 API level.
uses_sdk = root.find("uses-sdk")
if uses_sdk is None:
    uses_sdk = ET.SubElement(root, "uses-sdk")
uses_sdk.set(android + "targetSdkVersion", "35")

# Rebuilding a single standalone APK from an app bundle/base split must not
# retain split-install metadata from the original package.
for attr in ("isSplitRequired", "requiredSplitTypes", "splitTypes"):
    root.attrib.pop(android + attr, None)

# Fully qualify relative component/application names against the original package
# before changing package resolution.
for elem in root.iter():
    name = elem.get(android + "name")
    if name:
        if name.startswith("."):
            elem.set(android + "name", old_pkg + name)
        elif "." not in name:
            elem.set(android + "name", old_pkg + "." + name)

    # Update provider authorities that are conventionally derived from app ID.
    auth = elem.get(android + "authorities")
    if auth:
        elem.set(android + "authorities", auth.replace(old_pkg, new_pkg))

tree.write(manifest, encoding="utf-8", xml_declaration=True)
print(f"Manifest package set to {new_pkg}; label set to AI Stereoo; versionName set to 1.0; targetSdkVersion set to 35; split metadata removed")
PY

# Keep versionCode as in the original, unless Apktool's decoded manifest omitted it.
"${APKTOOL[@]}" b "$DECODED" -o work/unsigned.apk

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ]; then
  echo "ANDROID_HOME/ANDROID_SDK_ROOT is not set"
  exit 3
fi

BUILD_TOOLS="$(find "$SDK/build-tools" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -1)"
test -x "$BUILD_TOOLS/zipalign" || { echo "zipalign not found in $BUILD_TOOLS"; exit 4; }
test -x "$BUILD_TOOLS/apksigner" || { echo "apksigner not found in $BUILD_TOOLS"; exit 4; }
ZIPALIGN="$BUILD_TOOLS/zipalign"
APKSIGNER="$BUILD_TOOLS/apksigner"

"$ZIPALIGN" -f 4 work/unsigned.apk work/aligned.apk

mkdir -p work/keystore
keytool -genkeypair -v \
  -keystore work/keystore/stereoo-debug.keystore \
  -alias stereoo \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass android -keypass android \
  -dname "CN=Stereoo AI, OU=Development, O=Stereoo, L=Unknown, S=Unknown, C=RU" \
  >/dev/null 2>&1

"$APKSIGNER" sign \
  --ks work/keystore/stereoo-debug.keystore \
  --ks-key-alias stereoo \
  --ks-pass pass:android \
  --key-pass pass:android \
  --out "$OUT/Stereoo_AI_1.0.apk" \
  work/aligned.apk

"$APKSIGNER" verify --verbose "$OUT/Stereoo_AI_1.0.apk"
echo "Built: $OUT/Stereoo_AI_1.0.apk"
