package com.stereoo.placeholder;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        TextView view = new TextView(this);
        view.setText("Build helper only. The final APK is patched from the supplied HeyCyan APK.");
        setContentView(view);
    }
}
