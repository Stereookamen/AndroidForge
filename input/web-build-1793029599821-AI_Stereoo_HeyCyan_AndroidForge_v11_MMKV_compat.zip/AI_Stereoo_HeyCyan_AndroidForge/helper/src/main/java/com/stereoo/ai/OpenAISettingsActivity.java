package com.stereoo.ai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public final class OpenAISettingsActivity extends Activity {
    private static final String PREFS = "stereoo_openai";
    private EditText keyField;
    private EditText modelField;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setBackgroundColor(Color.WHITE);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(20 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("AI Stereoo · ChatGPT");
        title.setTextSize(22);
        title.setTextColor(Color.BLACK);
        layout.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("Введите ключ OpenAI API. Подписка ChatGPT не включает API-баланс. Ключ хранится в настройках приложения на телефоне.");
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, pad / 2, 0, pad / 2);
        layout.addView(info, new LinearLayout.LayoutParams(-1, -2));

        keyField = new EditText(this);
        keyField.setSingleLine(true);
        keyField.setHint("sk-… (OpenAI API key)");
        keyField.setInputType(129);
        keyField.setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString("api_key", ""));
        layout.addView(keyField, new LinearLayout.LayoutParams(-1, -2));

        modelField = new EditText(this);
        modelField.setSingleLine(true);
        modelField.setHint("Модель (по умолчанию gpt-4.1-mini)");
        modelField.setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString("model", "gpt-4.1-mini"));
        layout.addView(modelField, new LinearLayout.LayoutParams(-1, -2));

        Button save = new Button(this);
        save.setText("Сохранить");
        save.setOnClickListener(v -> {
            String key = keyField.getText().toString().trim();
            String model = modelField.getText().toString().trim();
            if (key.isEmpty()) {
                Toast.makeText(this, "Введите API-ключ OpenAI", Toast.LENGTH_LONG).show();
                return;
            }
            if (model.isEmpty()) model = "gpt-4.1-mini";
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("api_key", key).putString("model", model).apply();
            Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show();
            finish();
        });
        layout.addView(save, new LinearLayout.LayoutParams(-1, -2));
        setContentView(layout);
    }
}
