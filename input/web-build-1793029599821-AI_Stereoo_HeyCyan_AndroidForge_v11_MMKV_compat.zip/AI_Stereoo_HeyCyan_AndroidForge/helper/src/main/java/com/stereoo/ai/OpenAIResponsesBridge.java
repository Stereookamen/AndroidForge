package com.stereoo.ai;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class OpenAIResponsesBridge {
    private static final String PREFS = "stereoo_openai";
    private static final String DEFAULT_MODEL = "gpt-4.1-mini";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();

    private OpenAIResponsesBridge() {}

    // Signature deliberately mirrors D2.J.r(long,String,String,boolean,int), so the
    // existing invocation can be redirected without changing register layout.
    public static void ask(Object oldChat, long timestamp, String prompt,
                           String oldImageBase64, boolean oldFlag, int oldMode) {
        final Context context = appContext();
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String key = prefs.getString("api_key", "").trim();
        if (key.isEmpty()) {
            try {
                Intent intent = new Intent(context, OpenAISettingsActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (Throwable t) {
                toast(context, "Откройте настройки AI Stereoo и укажите OpenAI API key");
            }
            return;
        }
        final String userPrompt = prompt == null ? "" : prompt.trim();
        IO.execute(() -> {
            try {
                String answer = send(context, key, userPrompt, findLatestPhoto(context));
                deliverToHeyCyan(answer);
            } catch (Throwable error) {
                String message = error.getMessage();
                if (message == null || message.trim().isEmpty()) message = error.getClass().getSimpleName();
                deliverToHeyCyan("Не удалось получить ответ ChatGPT: " + message);
                toast(context, "ChatGPT: " + message);
            }
        });
    }

    private static Context appContext() {
        try {
            Class<?> c = Class.forName("P1.C0641b");
            Object result = c.getMethod("a").invoke(null);
            return result instanceof Context ? (Context) result : null;
        } catch (Throwable ignored) { return null; }
    }

    private static void deliverToHeyCyan(String answer) {
        try {
            Class<?> companion = Class.forName("D2.C0203f");
            Object chat = companion.getMethod("a").invoke(null);
            try {
                Method history = chat.getClass().getMethod("R", String.class, long.class, Long.class);
                history.invoke(chat, answer, System.currentTimeMillis(), null);
            } catch (Throwable ignored) { }
            Object queue = chat.getClass().getMethod("E").invoke(chat);
            queue.getClass().getMethod("offer", Object.class).invoke(queue, answer);
            chat.getClass().getMethod("Y").invoke(chat);
        } catch (Throwable ignored) { }
    }

    private static void toast(Context c, String message) {
        try {
            android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
            h.post(() -> Toast.makeText(c, message, Toast.LENGTH_LONG).show());
        } catch (Throwable ignored) { }
    }

    private static String send(Context context, String apiKey, String prompt, Uri photoUri) throws Exception {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONObject user = new JSONObject();
        user.put("role", "user");
        JSONArray content = new JSONArray();
        JSONObject text = new JSONObject();
        text.put("type", "input_text");
        text.put("text", prompt.isEmpty() ? "Ответь кратко по-русски. Если приложено фото, опиши, что на нём." : prompt);
        content.put(text);
        if (photoUri != null) {
            byte[] bytes = readUri(context, photoUri);
            if (bytes.length > 0) {
                String mime = context.getContentResolver().getType(photoUri);
                if (mime == null || !mime.startsWith("image/")) mime = "image/jpeg";
                JSONObject image = new JSONObject();
                image.put("type", "input_image");
                image.put("image_url", "data:" + mime + ";base64," + Base64.encodeToString(bytes, Base64.NO_WRAP));
                image.put("detail", "auto");
                content.put(image);
            }
        }
        user.put("content", content);
        JSONObject body = new JSONObject();
        body.put("model", prefs.getString("model", DEFAULT_MODEL).trim().isEmpty()
                ? DEFAULT_MODEL : prefs.getString("model", DEFAULT_MODEL).trim());
        body.put("input", new JSONArray().put(user));

        HttpURLConnection conn = (HttpURLConnection) new URL("https://api.openai.com/v1/responses").openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(90000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setRequestProperty("Accept", "application/json");
        byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(payload.length);
        try (OutputStream out = conn.getOutputStream()) { out.write(payload); }
        int status = conn.getResponseCode();
        InputStream stream = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = new String(readAll(stream), StandardCharsets.UTF_8);
        conn.disconnect();
        JSONObject root = new JSONObject(response);
        if (status < 200 || status >= 300) {
            JSONObject err = root.optJSONObject("error");
            throw new IllegalStateException(err == null ? ("HTTP " + status) : err.optString("message", "HTTP " + status));
        }
        StringBuilder answer = new StringBuilder();
        JSONArray output = root.optJSONArray("output");
        if (output != null) {
            for (int i = 0; i < output.length(); i++) {
                JSONObject item = output.optJSONObject(i);
                if (item == null || !"message".equals(item.optString("type"))) continue;
                JSONArray parts = item.optJSONArray("content");
                if (parts == null) continue;
                for (int j = 0; j < parts.length(); j++) {
                    JSONObject part = parts.optJSONObject(j);
                    if (part != null && "output_text".equals(part.optString("type"))) {
                        if (answer.length() > 0) answer.append('\n');
                        answer.append(part.optString("text", ""));
                    }
                }
            }
        }
        if (answer.toString().trim().isEmpty()) throw new IllegalStateException("Пустой ответ OpenAI");
        return answer.toString().trim();
    }

    private static Uri findLatestPhoto(Context context) {
        Cursor cursor = null;
        try {
            long since = System.currentTimeMillis() / 1000L - 120L;
            String[] projection = new String[] {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATE_ADDED
            };
            String selection = MediaStore.Images.Media.DISPLAY_NAME + " LIKE ? AND "
                    + MediaStore.Images.Media.DATE_ADDED + " >= ?";
            String[] args = new String[] { "photo-%", Long.toString(since) };
            cursor = context.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args,
                MediaStore.Images.Media.DATE_ADDED + " DESC"
            );
            if (cursor != null && cursor.moveToFirst()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
                return Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Long.toString(id));
            }
        } catch (Throwable ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        // Fallback: look for the newest app-owned file named photo-*.jpg.
        try {
            File ext = context.getExternalFilesDir(null);
            if (ext != null) {
                File f = newestPhoto(ext, System.currentTimeMillis() - 120000L);
                if (f != null) return Uri.fromFile(f);
            }
        } catch (Throwable ignored) { }
        return null;
    }

    private static File newestPhoto(File dir, long cutoff) {
        File[] children = dir.listFiles();
        if (children == null) return null;
        File best = null;
        for (File f : children) {
            if (f.isDirectory()) {
                File nested = newestPhoto(f, cutoff);
                if (nested != null && (best == null || nested.lastModified() > best.lastModified())) best = nested;
            } else if (f.getName().matches("(?i)photo-.*\\.(jpg|jpeg|png|webp)") &&
                       f.lastModified() >= cutoff && (best == null || f.lastModified() > best.lastModified())) {
                best = f;
            }
        }
        return best;
    }

    private static byte[] readUri(Context context, Uri uri) throws Exception {
        InputStream in = null;
        try {
            if ("file".equals(uri.getScheme())) in = new FileInputStream(new File(uri.getPath()));
            else in = context.getContentResolver().openInputStream(uri);
            if (in == null) return new byte[0];
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            byte[] data = out.toByteArray();
            if (data.length > 20 * 1024 * 1024) throw new IllegalArgumentException("Фото больше 20 МБ");
            return data;
        } finally {
            if (in != null) try { in.close(); } catch (Throwable ignored) {}
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        if (in == null) return new byte[0];
        try (InputStream source = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            ByteArrayOutputStream outBytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int n;
            while ((n = source.read(buffer)) != -1) outBytes.write(buffer, 0, n);
            return outBytes.toByteArray();
        }
    }
}
