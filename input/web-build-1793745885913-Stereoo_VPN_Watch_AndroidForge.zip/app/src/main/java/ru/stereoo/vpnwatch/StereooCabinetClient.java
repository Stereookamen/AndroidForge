package ru.stereoo.vpnwatch;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;

/**
 * HTTPS-only GET for the existing / and /payments endpoints;
 * POST is used exclusively for /login (Flask login + CSRF).
 * Does not call any client-modifying routes, 3x-ui APIs or third-party servers.
 */
final class StereooCabinetClient {
    private static final String HOST = "cabinet.stereoo-vpn.ru";
    private static final String ROOT = "https://" + HOST;
    private final CookieManager cookieManager = new CookieManager(null, CookiePolicy.ACCEPT_ORIGINAL_SERVER);
    private final String basic;
    private final String panelPassword;

    StereooCabinetClient(String caddyUser, String caddyPass, String panelPassword) {
        String raw = caddyUser + ":" + caddyPass;
        basic = "Basic " + Base64.getEncoder().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
        this.panelPassword = panelPassword;
        CookieHandler.setDefault(cookieManager);
    }

    static final class Snapshot {
        StereooHtmlParser.Result clients;
        StereooHtmlParser.Result payments;
    }

    Snapshot getSnapshot() throws Exception {
        Response first = get("/");
        if (first.code == 401) throw new IllegalArgumentException("Неверный логин или пароль защиты Caddy.");
        if (first.code == 302 || first.code == 303 || StereooHtmlParser.isLogin(first.html)) {
            login();
            first = get("/");
        }
        if (first.code != 200) throw new IllegalStateException("Кабинет вернул HTTP " + first.code);
        if (!StereooHtmlParser.isDashboard(first.html)) {
            if (StereooHtmlParser.isLogin(first.html)) throw new IllegalArgumentException("Вход в панель не выполнен: проверь пароль панели.");
            throw new IllegalStateException("Не обнаружена страница клиентов. Возможно, изменился шаблон.");
        }
        Snapshot out = new Snapshot();
        out.clients = StereooHtmlParser.clients(first.html);
        Response pay = get("/payments");
        if (pay.code == 200 && pay.html.contains("ПОЛУЧЕНО ЗА МЕСЯЦ")) out.payments = StereooHtmlParser.payments(pay.html);
        else out.payments = new StereooHtmlParser.Result();
        return out;
    }

    private void login() throws Exception {
        Response loginPage = get("/login");
        if (loginPage.code == 401) throw new IllegalArgumentException("Пароль Caddy не подходит.");
        if (loginPage.code != 200) throw new IllegalStateException("Не удалось получить страницу входа, HTTP " + loginPage.code);
        String csrf = StereooHtmlParser.csrf(loginPage.html);
        if (csrf == null) throw new IllegalStateException("Не удалось найти CSRF формы входа.");
        String form = "csrf=" + URLEncoder.encode(csrf,"UTF-8")
                + "&password=" + URLEncoder.encode(panelPassword,"UTF-8");
        Response sent = request("/login", "POST", form);
        if (sent.code == 401) throw new IllegalArgumentException("Пароль Caddy не подошёл.");
        if (sent.code == 403) throw new IllegalStateException("Сессия входа не прошла CSRF-проверку.");
        if (sent.code == 429) throw new IllegalArgumentException("Слишком много попыток входа. Повтори позже.");
        if (sent.code == 200 && (sent.html.contains("Неверный пароль") || StereooHtmlParser.isLogin(sent.html))) {
            throw new IllegalArgumentException("Неверный пароль Stereoo VPN Manager.");
        }
        if (sent.code != 302 && sent.code != 303 && sent.code != 200) {
            throw new IllegalStateException("Неожиданный ответ на вход: HTTP " + sent.code);
        }
    }

    private Response get(String path) throws Exception { return request(path,"GET",null); }
    private Response request(String path, String method, String form) throws Exception {
        if (!path.equals("/") && !path.equals("/login") && !path.equals("/payments")) {
            throw new IllegalArgumentException("Запрещённый путь: " + path);
        }
        URL url = new URL(ROOT + path);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setInstanceFollowRedirects(false);  // Never leak Basic credentials to a redirect target.
        con.setConnectTimeout(12000);
        con.setReadTimeout(16000);
        con.setUseCaches(false);
        con.setRequestMethod(method);
        con.setRequestProperty("Authorization",basic);
        con.setRequestProperty("Accept","text/html");
        con.setRequestProperty("User-Agent","StereooVPNWatch/1.0 (Wear OS)");
        if (form != null) {
            byte[] bytes = form.getBytes(StandardCharsets.UTF_8);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
            con.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = con.getOutputStream()) { out.write(bytes); }
        }
        int code=con.getResponseCode();
        InputStream in=code>=400 ? con.getErrorStream() : con.getInputStream();
        byte[] body;
        try {
            body=readMax(in,2*1024*1024);
        } finally {
            if (in!=null) in.close();
            con.disconnect();
        }
        String html=new String(body,StandardCharsets.UTF_8);
        return new Response(code,html);
    }
    private static byte[] readMax(InputStream in, int limit) throws Exception {
        if(in==null) return new byte[0];
        ByteArrayOutputStream baos=new ByteArrayOutputStream();
        byte[] buffer=new byte[8192]; int n;
        while((n=in.read(buffer))!=-1) {
            if(baos.size()+n>limit) throw new IllegalStateException("Слишком большой HTML ответ сервера.");
            baos.write(buffer,0,n);
        }
        return baos.toByteArray();
    }
    private static final class Response {
        final int code; final String html;
        Response(int code,String html) {this.code=code;this.html=html;}
    }
}
