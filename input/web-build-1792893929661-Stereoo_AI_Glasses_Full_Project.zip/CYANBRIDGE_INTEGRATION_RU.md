# Контракт интеграции CyanBridge → Stereoo

## Голосовая кнопка
Открыть `ru.stereoo.aiglasses.MainActivity` явным Intent с действием:
`com.fersaiyan.cyanbridge.ACTION_START_EXTERNAL_ASSISTANT`

В приложении Stereoo этот action запускает распознавание речи на русском языке.

## Фото с очков
Когда CyanBridge завершил захват/получение фотографии и у него есть доступный `content://` URI:
- открыть `ru.stereoo.aiglasses.MainActivity`;
- установить action `com.fersaiyan.cyanbridge.ACTION_STEREOO_IMAGE_QUESTION`;
- положить URI в extra `ru.stereoo.aiglasses.EXTRA_IMAGE_URI`;
- при желании положить вопрос в extra `ru.stereoo.aiglasses.EXTRA_IMAGE_QUESTION`;
- добавить `FLAG_GRANT_READ_URI_PERMISSION` и выдать Stereoo разрешение чтения URI.

Если передавать файл через `ACTION_SEND`, используйте MIME `image/*` и `Intent.EXTRA_STREAM`.

Не передавайте файловый путь вида `/storage/...` как URI. Используйте content URI с разрешением чтения.
