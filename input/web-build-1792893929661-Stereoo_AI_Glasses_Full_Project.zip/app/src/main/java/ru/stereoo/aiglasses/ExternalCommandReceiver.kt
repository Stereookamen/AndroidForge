package ru.stereoo.aiglasses

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Receives an explicit Tasker/MacroDroid broadcast and opens Stereoo directly in listening mode. */
class ExternalCommandReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != MainActivity.ACTION_LISTEN) return
        val launch = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_START_LISTENING, true)
        }
        context.startActivity(launch)
    }
}
