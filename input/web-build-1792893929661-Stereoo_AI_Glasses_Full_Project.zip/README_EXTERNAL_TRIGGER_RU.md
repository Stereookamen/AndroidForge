# Запуск голосового ввода извне

В этой версии добавлен экспортируемый BroadcastReceiver для Tasker/MacroDroid.

- Action: `ru.stereoo.aiglasses.ACTION_LISTEN`
- Receiver: `ru.stereoo.aiglasses.ExternalCommandReceiver`
- При получении broadcast приложение открывается и запускает системное распознавание речи на русском языке. После распознавания вопрос отправляется в OpenAI, ответ озвучивается.

## Tasker
Создать задачу с действием **System → Send Intent**:
- Action: `ru.stereoo.aiglasses.ACTION_LISTEN`
- Target: `Broadcast Receiver`
- Package/Class (если поля доступны): `ru.stereoo.aiglasses` / `ru.stereoo.aiglasses.ExternalCommandReceiver`

Если CyanBridge не умеет отправлять этот broadcast напрямую, привяжите его событие в Tasker к указанному действию. Точный action события CyanBridge зависит от его версии и настроек, поэтому не следует считать, что само приложение уже напрямую перехватывает кнопку очков.
