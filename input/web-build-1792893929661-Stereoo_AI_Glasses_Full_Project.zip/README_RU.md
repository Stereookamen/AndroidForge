# Stereoo AI Glasses — полный Android-проект

Это полный исходный проект Android-приложения для сборки APK через GitHub Actions.

## Что умеет приложение
- распознавать русскую речь с помощью системного сервиса Android;
- отправлять вопрос в OpenAI API и озвучивать ответ по-русски;
- анализировать изображение через OpenAI Responses API;
- хранить API-ключ в приватных настройках приложения на телефоне;
- запускать голосовой ввод через внешний Intent;
- принимать изображение от другого Android-приложения через `ACTION_SEND` (`image/*`) либо через специальное действие `com.fersaiyan.cyanbridge.ACTION_STEREOO_IMAGE_QUESTION`.

## Сборка APK в GitHub
1. Распакуйте весь архив.
2. Загрузите содержимое архива в корень репозитория GitHub `Stereoo-AI-Glasses`.
3. Откройте **Actions** и запустите workflow **Build Stereoo AI Glasses APK**.
4. После успешной сборки скачайте artifact `Stereoo-AI-Glasses-debug`.
5. Установите `app-debug.apk` на телефон.
6. В приложении откройте **Настроить API-ключ** и введите свой ключ OpenAI.

## Интеграция с очками
- Голосовой запуск: CyanBridge должен отправить Activity action `com.fersaiyan.cyanbridge.ACTION_START_EXTERNAL_ASSISTANT` или `ru.stereoo.aiglasses.ACTION_LISTEN`. Приложение откроется и начнёт распознавать речь.
- Фото: после получения фото от очков приложение-компаньон должно передать URI изображения в Stereoo. Поддерживаются стандартный `ACTION_SEND` с `image/*` и custom action `com.fersaiyan.cyanbridge.ACTION_STEREOO_IMAGE_QUESTION` с extra `ru.stereoo.aiglasses.EXTRA_IMAGE_URI`; для передачи текста вопроса можно использовать `ru.stereoo.aiglasses.EXTRA_IMAGE_QUESTION`.
- Отправитель обязан передать URI, который доступен Stereoo, и предоставить разрешение чтения URI.

## Честное ограничение
В этом архиве находится полный проект **Stereoo AI Glasses**, а не исходный код CyanBridge. Само приложение умеет принимать голосовой запуск и фотографию через Android Intent, но чтобы физическая кнопка и камера конкретной модели очков автоматически передавали команды/фото, CyanBridge должен вызвать соответствующие Intent в момент нажатия кнопки/получения фотографии. Этот архив не содержит upstream исходники CyanBridge и не выдаёт это за уже проверенную интеграцию.

## Безопасность и расходы
Не храните API-ключ в GitHub и не вставляйте его в исходники. Вводите ключ только на своём телефоне. Использование OpenAI API оплачивается отдельно от подписки ChatGPT.
