package ru.musicstudio.ai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.io.*;
import java.net.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(15,18,29), PANEL=Color.rgb(27,32,48), ACCENT=Color.rgb(137,105,255);
    private EditText prompt, apiKey, title, duration;
    private Spinner genre;
    private TextView status, selectedFile;
    private LinearLayout library;
    private Button genBtn, remixBtn;
    private Uri remixUri=null;
    private MediaPlayer player;
    private static final int PICK_AUDIO=4101;
    private File libraryDir;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        libraryDir=new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC),"MusicStudioLibrary");
        if(!libraryDir.exists()) libraryDir.mkdirs();
        buildUi();
        apiKey.setText(getPreferences(0).getString("stability_key",""));
        refreshLibrary();
    }

    private void buildUi() {
        ScrollView sc=new ScrollView(this); sc.setBackgroundColor(BG);
        LinearLayout page=new LinearLayout(this); page.setOrientation(1); page.setPadding(dp(18),dp(20),dp(18),dp(28)); sc.addView(page); setContentView(sc);
        TextView brand=txt("MUSIC STUDIO AI  •  V2",13,ACCENT,true); page.addView(brand);
        TextView head=txt("Твоя музыкальная\\nмастерская",29,Color.WHITE,true); head.setPadding(0,dp(7),0,dp(4)); page.addView(head);
        page.addView(txt("Генерация • ремиксы • библиотека • MP3",13,0xFFADB5CC,false));

        section(page,"1. ПОДКЛЮЧЕНИЕ STABLE AUDIO");
        apiKey=edit("Stability AI API key"); apiKey.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); page.addView(apiKey);
        Button saveKey=button("Сохранить API-ключ на устройстве"); page.addView(saveKey);
        saveKey.setOnClickListener(v->{getPreferences(0).edit().putString("stability_key",apiKey.getText().toString().trim()).apply(); status.setText("API-ключ сохранён локально.");});
        TextView note=txt("Получить ключ: platform.stability.ai. Для тестирования можно начать с бесплатных кредитов. Не передавай ключ посторонним. Для публичного релиза перенеси ключ на свой сервер.",12,0xFF9AA4BC,false);
        note.setPadding(dp(2),dp(4),dp(2),dp(4)); page.addView(note);

        section(page,"2. СОЗДАТЬ МУЗЫКУ");
        title=edit("Название композиции"); page.addView(title);
        prompt=edit("Опиши звучание: например, мощный русский рок, электрогитары, живые барабаны, мелодичный бас..."); prompt.setMinLines(4); prompt.setGravity(Gravity.TOP|Gravity.START); page.addView(prompt);
        genre=spinner(new String[]{"Русский рок","Поп-рок","Шансон","Панк-рок","Металл","Поп","Электроника","Кинематографическая музыка","Акустика","Эмбиент","Хип-хоп","Другое"}); page.addView(genre);
        duration=edit("Длительность в секундах (например, 30)"); duration.setInputType(InputType.TYPE_CLASS_NUMBER); duration.setText("30"); page.addView(duration);
        genBtn=button("♫  СГЕНЕРИРОВАТЬ МУЗЫКУ"); page.addView(genBtn);
        genBtn.setOnClickListener(v->generate(false));

        section(page,"3. РЕМИКС / НОВАЯ ВЕРСИЯ");
        Button pick=button("Выбрать аудиофайл для ремикса"); page.addView(pick);
        selectedFile=txt("Файл не выбран",12,0xFF9AA4BC,false); page.addView(selectedFile);
        pick.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("audio/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_AUDIO);});
        TextView remixHint=txt("Опиши, как изменить исходник: например, сделать тяжёлый рок, добавить синтезаторы или превратить демо в оркестровую версию.",12,0xFF9AA4BC,false); remixHint.setPadding(0,dp(7),0,dp(7)); page.addView(remixHint);
        remixBtn=button("⟳  СОЗДАТЬ РЕМИКС"); page.addView(remixBtn);
        remixBtn.setOnClickListener(v->generate(true));

        section(page,"СТАТУС");
        status=txt("Готово. Добавь API-ключ Stability AI, чтобы начать.",13,0xFFD3D8E8,false);
        status.setPadding(dp(3),dp(8),dp(3),dp(12)); page.addView(status);

        section(page,"4. МОЯ БИБЛИОТЕКА");
        Button refresh=button("Обновить библиотеку"); page.addView(refresh); refresh.setOnClickListener(v->refreshLibrary());
        library=new LinearLayout(this); library.setOrientation(1); page.addView(library);
        TextView foot=txt("Music Studio AI v2 • SDK 35",11,0xFF737E99,false); foot.setGravity(Gravity.CENTER); foot.setPadding(0,dp(22),0,0); page.addView(foot);
    }

    private void generate(boolean remix) {
        final String key=apiKey.getText().toString().trim();
        final String p=prompt.getText().toString().trim();
        final String style=genre.getSelectedItem().toString();
        final String trackTitle=title.getText().toString();
        final Uri sourceUri=remixUri;
        if(key.isEmpty()){status.setText("Сначала добавь Stability AI API key.");return;}
        if(p.isEmpty()){status.setText("Напиши описание звучания или изменений.");return;}
        if(remix && sourceUri==null){status.setText("Сначала выбери аудиофайл для ремикса.");return;}
        int secs=30; try{secs=Integer.parseInt(duration.getText().toString().trim());}catch(Exception ignored){}
        final int seconds=Math.max(5,Math.min(180,secs));
        setBusy(true); status.setText(remix?"Загружаю исходник и создаю новую версию…":"Генерирую музыку через Stable Audio…");
        final boolean isRemix=remix;
        new Thread(()->{
            try {
                String endpoint=isRemix
                    ?"https://api.stability.ai/v2beta/audio/stable-audio/audio-to-audio"
                    :"https://api.stability.ai/v2beta/audio/stable-audio/text-to-audio";
                HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(30000); c.setReadTimeout(180000); c.setDoOutput(true);
                c.setRequestProperty("Authorization","Bearer "+key);
                String boundary="----MusicStudioBoundary"+System.currentTimeMillis();
                c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
                OutputStream out=c.getOutputStream();
                if(isRemix) {
                    writeFilePart(out,boundary,"audio",getDisplayName(sourceUri),getBytes(sourceUri),getMime(sourceUri));
                    writeField(out,boundary,"model","stable-audio-3");
                    writeField(out,boundary,"prompt",composePrompt(p,style));
                    writeField(out,boundary,"strength","0.6");
                } else {
                    writeField(out,boundary,"model","stable-audio-3");
                    writeField(out,boundary,"prompt",composePrompt(p,style));
                    writeField(out,boundary,"duration",String.valueOf(seconds));
                }
                out.write(("--"+boundary+"--\r\n").getBytes("UTF-8")); out.flush(); out.close();
                int code=c.getResponseCode();
                if(code>=200&&code<300) {
                    InputStream in=c.getInputStream();
                    File dest=new File(libraryDir,cleanName(trackTitle)+"_"+System.currentTimeMillis()+".mp3");
                    FileOutputStream fos=new FileOutputStream(dest); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1)fos.write(buf,0,n); fos.close(); in.close(); c.disconnect();
                    runOnUiThread(()->{setBusy(false); status.setText("Готово! Трек сохранён в библиотеку: "+dest.getName()); refreshLibrary();});
                } else {
                    InputStream err=c.getErrorStream(); String message=readAll(err); c.disconnect();
                    runOnUiThread(()->{setBusy(false); status.setText("Ошибка API ("+code+"): "+message);});
                }
            } catch(Exception e){runOnUiThread(()->{setBusy(false);status.setText("Не удалось выполнить запрос: "+e.getMessage());});}
        }).start();
    }

    private String composePrompt(String p, String style) {
        return p + ". Style: " + style + ". High quality, coherent musical arrangement.";
    }
    private void setBusy(boolean busy){genBtn.setEnabled(!busy);remixBtn.setEnabled(!busy);genBtn.setText(busy?"ВЫПОЛНЯЕТСЯ…":"♫  СГЕНЕРИРОВАТЬ МУЗЫКУ");remixBtn.setText(busy?"ВЫПОЛНЯЕТСЯ…":"⟳  СОЗДАТЬ РЕМИКС");}
    private void writeField(OutputStream o,String b,String name,String value)throws Exception {
        o.write(("--"+b+"\r\nContent-Disposition: form-data; name=\""+name+"\"\r\n\r\n"+value+"\r\n").getBytes("UTF-8"));
    }
    private void writeFilePart(OutputStream o,String b,String name,String filename,byte[] data,String mime)throws Exception {
        o.write(("--"+b+"\r\nContent-Disposition: form-data; name=\""+name+"\"; filename=\""+filename.replace("\"","")+"\"\r\nContent-Type: "+mime+"\r\n\r\n").getBytes("UTF-8"));
        o.write(data); o.write("\r\n".getBytes("UTF-8"));
    }
    private byte[] getBytes(Uri uri)throws Exception {
        InputStream in=getContentResolver().openInputStream(uri); ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] x=new byte[8192]; int n;
        while((n=in.read(x))!=-1)b.write(x,0,n); in.close(); return b.toByteArray();
    }
    private String getMime(Uri u){String m=getContentResolver().getType(u);return m==null?"audio/mpeg":m;}
    private String getDisplayName(Uri u){
        Cursor c=getContentResolver().query(u,null,null,null,null);
        if(c!=null){try{if(c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}finally{c.close();}}
        return "source_audio";
    }
    private String readAll(InputStream in)throws Exception{if(in==null)return "";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[2048];int n;while((n=in.read(x))!=-1)b.write(x,0,n);in.close();return new String(b.toByteArray(),"UTF-8");}
    private String cleanName(String s){if(s==null||s.trim().isEmpty())s="MusicStudio";return s.replaceAll("[^a-zA-Z0-9а-яА-Я_-]","_");}

    private void refreshLibrary() {
        if(library==null)return; library.removeAllViews();
        File[] fs=libraryDir.listFiles((d,n)->n.toLowerCase().endsWith(".mp3"));
        if(fs==null||fs.length==0){library.addView(txt("Пока нет готовых треков. Сгенерируй первую композицию.",13,0xFF9AA4BC,false));return;}
        Arrays.sort(fs,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        for(File f:fs){
            LinearLayout row=new LinearLayout(this); row.setOrientation(1); row.setPadding(dp(12),dp(9),dp(12),dp(8)); row.setBackground(round(PANEL,14));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(9);row.setLayoutParams(rp);
            row.addView(txt(f.getName(),13,Color.WHITE,true));
            row.addView(txt(android.text.format.Formatter.formatFileSize(this,f.length()),11,0xFF9AA4BC,false));
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(0);
            Button play=smallButton("▶ Слушать"), save=smallButton("↓ MP3");
            actions.addView(play,new LinearLayout.LayoutParams(0,dp(44),1)); actions.addView(save,new LinearLayout.LayoutParams(0,dp(44),1)); row.addView(actions);
            play.setOnClickListener(v->playFile(f));
            save.setOnClickListener(v->shareOrSave(f));
            library.addView(row);
        }
    }
    private void playFile(File f){
        try{if(player!=null){player.release();player=null;} player=new MediaPlayer();player.setDataSource(f.getAbsolutePath());player.setOnPreparedListener(mp->{mp.start();status.setText("Воспроизводится: "+f.getName());});player.setOnCompletionListener(mp->status.setText("Воспроизведение завершено."));player.prepareAsync();}
        catch(Exception e){status.setText("Ошибка воспроизведения: "+e.getMessage());}
    }
    private void shareOrSave(File f){
        try{
            android.content.ContentValues v=new android.content.ContentValues();v.put(android.provider.MediaStore.Audio.Media.DISPLAY_NAME,f.getName());v.put(android.provider.MediaStore.Audio.Media.MIME_TYPE,"audio/mpeg");v.put(android.provider.MediaStore.Audio.Media.RELATIVE_PATH,Environment.DIRECTORY_MUSIC+"/MusicStudioAI");
            Uri dest=getContentResolver().insert(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,v);
            if(dest!=null){OutputStream o=getContentResolver().openOutputStream(dest);FileInputStream in=new FileInputStream(f);byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)o.write(b,0,n);o.close();in.close();status.setText("MP3 сохранён в Музыка/MusicStudioAI.");}
        }catch(Exception e){status.setText("Не удалось сохранить MP3: "+e.getMessage());}
    }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK_AUDIO&&c==RESULT_OK&&d!=null){remixUri=d.getData();if(remixUri!=null){getContentResolver().takePersistableUriPermission(remixUri,d.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION);selectedFile.setText("Выбран файл: "+getDisplayName(remixUri));}}}
    @Override protected void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}

    private void section(LinearLayout p,String s){TextView t=txt(s,11,0xFF929DB8,true);t.setPadding(2,dp(20),2,dp(8));p.addView(t);}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private EditText edit(String h){EditText e=new EditText(this);e.setHint(h);e.setTextColor(Color.WHITE);e.setHintTextColor(0xFF77829D);e.setTextSize(14);e.setPadding(dp(13),dp(9),dp(13),dp(9));e.setBackground(round(PANEL,13));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(9);e.setLayoutParams(lp);return e;}
    private Spinner spinner(String[] data){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,data));s.setBackground(round(PANEL,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.bottomMargin=dp(9);s.setLayoutParams(lp);return s;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTextSize(13);b.setBackground(round(ACCENT,15));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(51));lp.bottomMargin=dp(8);b.setLayoutParams(lp);return b;}
    private Button smallButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTextSize(12);b.setBackground(round(ACCENT,12));return b;}
    private android.graphics.drawable.GradientDrawable round(int c,int r){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
}
