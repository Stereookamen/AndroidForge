# CyanBridge 2.3.0 + Stereoo AI Glasses (HeyCyan) — инструкция

Этот архив содержит исходники CyanBridge 2.3.0 с интеграцией Stereoo для очков, использующих протокол HeyCyan.

## Изменения

- Голосовая кнопка HeyCyan при маршруте `PHONE_ASSISTANT` запускает `ru.stereoo.aiglasses.MainActivity` с действием `com.fersaiyan.cyanbridge.ACTION_START_EXTERNAL_ASSISTANT`. Это обходит системный выбор помощника.
- После получения фотографии CyanBridge передаёт изображение в Stereoo через `ACTION_SEND` (`image/jpeg`) и текст задания на русском. Если Stereoo не установлено или передача не удалась, CyanBridge возвращается к своему обычному сценарию.
- Интеграция не заменяет и не удаляет драйверы других очков.

## Что нужно для полной сборки

1. Java 17 и Android SDK, API 36.
2. Репозиторий использует Git submodule `android/CyanBridge/app/src/main/myvu-upstream` (Meizu Myvu). ZIP-архивы GitHub не включают содержимое submodule. Если сборка идёт из Git-клона, выполните `git submodule update --init --recursive`. Если сборка идёт из ZIP, источник Myvu должен быть получен отдельно и распакован в указанный каталог.
3. Поддержка Meta Ray-Ban сохранена. Для сборки приложения с Meta-функциями обязательно передайте в AndroidForge секрет `META_GITHUB_TOKEN` (GitHub token с разрешением `read:packages` для `facebook/meta-wearables-dat-android`). Без токена Gradle намеренно не подключает Meta DAT SDK, но исходники Meta продолжают ссылаться на его классы, поэтому Kotlin-компиляция завершится ошибкой. HeyCyan использует отдельный протокол и от Meta не зависит, однако в текущем общем приложении для компиляции всех функций нужен этот токен.

## Перед сборкой в AndroidForge

1. В настройках репозитория/среды AndroidForge добавьте секрет `META_GITHUB_TOKEN` с правом `read:packages`. Не вставляйте токен в исходники или публичные файлы.
2. Убедитесь, что git submodule `android/CyanBridge/app/src/main/myvu-upstream` инициализирован совместимой версией репозитория MyVU.

## Сборка

Из каталога `android/CyanBridge`:

```bash
chmod +x gradlew
./gradlew assembleDebug
```

APK при успешной сборке: `app/build/outputs/apk/debug/app-debug.apk`.

## Проверка

- Установите CyanBridge и Stereoo на один Android-телефон.
- Подключите HeyCyan-очки в CyanBridge.
- В настройках маршрута AI выберите `PHONE_ASSISTANT` и включите перехват AI-кнопки.
- Нажмите голосовую кнопку: Stereoo должна открыться и начать слушать.
- Нажмите кнопку фото: после получения снимка CyanBridge отправит его в Stereoo с просьбой описать изображение по-русски.

Архив содержит исходный код, а не заранее собранный APK. Сборка должна быть выполнена в среде с указанными зависимостями и секретами.
