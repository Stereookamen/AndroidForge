# Диагностика обработки фотографии

В этом обновлении добавлены контрольные события непосредственно в `handleGlassesImageButtonPressed()` и `requestSelectedImageSourceForQuestion()`:
- `image_button_handler_enter`
- `handler_waiting_for_microphone_permission`
- `handler_route_meta` / `handler_route_eyevue` / `handler_route_tunebuds`
- `handler_exit_command_blocked`
- `handler_exit_disconnected`
- `using_existing_ready_photo`
- `request_selected_source_enter`

Это позволит увидеть, входит ли выполнение в обработчик после `photo_ready_route` и на каком условии прекращается. Голосовой обработчик не менялся. Это инструментированная диагностическая сборка исходников, её ещё нужно собрать и проверить на очках.
