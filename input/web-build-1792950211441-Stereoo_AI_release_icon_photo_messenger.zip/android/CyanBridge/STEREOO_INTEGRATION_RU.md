# Интеграция CyanBridge 2.3.0 + Stereoo AI Glasses

## Что изменено
- `app/src/main/java/com/fersaiyan/cyanbridge/MainActivity.kt`: метод `launchPhoneAssistant()` отправляет broadcast `ru.stereoo.aiglasses.ACTION_LISTEN` в компонент Stereoo `ru.stereoo.aiglasses.ExternalCommandReceiver`, чтобы голосовая кнопка не вызывала системный chooser.
- При неудаче остаётся fallback на системный голосовой помощник.

## Важно о фото
Текущая логика съёмки/анализа CyanBridge уже обрабатывает фотографию внутри CyanBridge. Передача файла в Stereoo должна быть привязана к конкретному событию завершения получения свежего снимка. Не следует отправлять URI до завершения загрузки фото: иначе возможен старый или пустой снимок. Проверьте этот поток на целевой модели очков.

## Требования
- Android Studio с JDK 17.
- Открывать проект из `android/CyanBridge`.
- Установить Stereoo с package name `ru.stereoo.aiglasses`.
- Разрешить Stereoo запись звука и уведомления, если Android их запросит.

## Ограничение проверки
Архив содержит исходный проект, но APK не был собран в этой среде и физические кнопки не проверялись на устройстве. Не считать интеграцию подтверждённой до сборки и реального теста.
