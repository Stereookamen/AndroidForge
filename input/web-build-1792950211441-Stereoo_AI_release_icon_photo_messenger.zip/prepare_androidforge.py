#!/usr/bin/env python3
"""Validate CyanBridge source prerequisites before an AndroidForge build."""
from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
APP = ROOT / "android/CyanBridge/app"
MYVU = APP / "src/main/myvu-upstream"


def main() -> int:
    gradle = ROOT / "android/CyanBridge/gradlew"
    main_activity = APP / "src/main/java/com/fersaiyan/cyanbridge/MainActivity.kt"
    if not gradle.is_file() or not main_activity.is_file():
        print("ERROR: run this script from the extracted CyanBridge project root.", file=sys.stderr)
        return 2
    if not os.access(gradle, os.X_OK):
        gradle.chmod(gradle.stat().st_mode | 0o111)
    # GitHub source ZIPs omit submodule contents. Fetch it when git/network access exists.
    expected = MYVU / "android/app/src/main/java"
    if not expected.exists():
        MYVU.parent.mkdir(parents=True, exist_ok=True)
        if MYVU.exists():
            import shutil
            shutil.rmtree(MYVU)
        print("Fetching required Meizu Myvu submodule source...")
        try:
            subprocess.run([
                "git", "clone", "--depth", "1",
                "https://github.com/FerSaiyan/Meizu-Myvu-Client.git", str(MYVU)
            ], check=True)
        except (OSError, subprocess.CalledProcessError) as exc:
            print("ERROR: Myvu source is missing and could not be fetched.", file=sys.stderr)
            print("In a Git checkout run: git submodule update --init --recursive", file=sys.stderr)
            print(f"Details: {exc}", file=sys.stderr)
            return 3
    if not (os.environ.get("META_GITHUB_TOKEN") or os.environ.get("GITHUB_TOKEN")):
        print("NOTE: META_GITHUB_TOKEN is not set. Meta Ray-Ban support remains in source, but Gradle will skip its private SDK and compilation may fail.")
    print("Source root checks passed. Next: cd android/CyanBridge && ./gradlew assembleDebug")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
