package com.fersaiyan.cyanbridge.stereoo

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import android.util.Base64

class StereooAssistantActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var lastAnswer = ""
    @Volatile private var ttsReady = false
    private var pendingSpeech: String? = null
    private var pendingSpeechIsAnswer = false
    @Volatile private var continuousDialogue = true
    private var dialogueButton: Button? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DiagnosticsTree.event(this, "APP", "assistant_activity_created", "action=${intent?.action.orEmpty()}")
        tts = TextToSpeech(this, this)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onError(utteranceId: String?) {
                if (utteranceId?.startsWith("dialogue-answer-") == true) {
                    DiagnosticsTree.event(this@StereooAssistantActivity, "AUDIO", "answer_tts_error", "utterance=$utteranceId")
                    scheduleNextDialogueTurn()
                }
            }
            override fun onDone(utteranceId: String?) {
                if (utteranceId?.startsWith("dialogue-answer-") == true) {
                    DiagnosticsTree.event(this@StereooAssistantActivity, "AUDIO", "answer_tts_done", "utterance=$utteranceId")
                    scheduleNextDialogueTurn()
                }
            }
        })
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Stereoo glasses AI"
            textSize = 25f
            gravity = Gravity.CENTER
        }, match(-1, -2))
        layout.addView(TextView(this).apply {
            text = "Голосовой помощник и анализ фотографий"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }, match(-1, -2))
        input = EditText(this).apply {
            hint = "Напиши вопрос..."
            minLines = 2
            gravity = Gravity.TOP
        }
        layout.addView(input, match(-1, -2))
        addButton(layout, "ОТПРАВИТЬ ВОПРОС") { sendText(input.text.toString()) }
        addButton(layout, "🎙 ГОВОРИТЬ") {
            continuousDialogue = true
            prefs.edit().putBoolean("continuous_dialogue", true).apply()
            updateDialogueButton()
            listen()
        }
        dialogueButton = Button(this).apply {
            setOnClickListener {
                continuousDialogue = !continuousDialogue
                prefs.edit().putBoolean("continuous_dialogue", continuousDialogue).apply()
                updateDialogueButton()
                status.text = if (continuousDialogue) "Непрерывный диалог включён: после ответа я снова буду слушать." else "Непрерывный диалог выключен. Для следующего вопроса нажми «ГОВОРИТЬ»."
                speak(if (continuousDialogue) "Непрерывный диалог включён" else "Непрерывный диалог выключен")
            }
        }
        layout.addView(dialogueButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        continuousDialogue = prefs.getBoolean("continuous_dialogue", true)
        updateDialogueButton()
        addButton(layout, "📷 ВЫБРАТЬ ФОТОГРАФИЮ") {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 22)
        }
        addButton(layout, "🔊 ПОВТОРИТЬ ОТВЕТ") {
            if (lastAnswer.isNotBlank()) tts.speak(lastAnswer, TextToSpeech.QUEUE_FLUSH, null, "answer")
        }
        addButton(layout, "🔑 НАСТРОИТЬ API-КЛЮЧ") { keyDialog() }
        addButton(layout, "🧰 ЖУРНАЛ ОШИБОК: ПОДЕЛИТЬСЯ") { exportDiagnostics() }
        addButton(layout, "🧹 ОЧИСТИТЬ ЖУРНАЛ") {
            DiagnosticsTree.clear(this)
            DiagnosticsTree.event(this, "DIAGNOSTICS", "log_cleared")
            Toast.makeText(this, "Журнал очищен", Toast.LENGTH_SHORT).show()
        }
        status = TextView(this).apply {
            text = "Готов к работе. Для ответов нужен API-ключ OpenAI."
            textSize = 15f
            setPadding(0, 16, 0, 0)
        }
        layout.addView(status, match(-1, -2))
        setContentView(ScrollView(this).apply { addView(layout) })
        handleExternalCommand(intent)
        handleIncomingPhoto(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleExternalCommand(intent)
        handleIncomingPhoto(intent)
    }

    private fun handleExternalCommand(intent: Intent?) {
        if (intent == null) return
        val action = intent.action.orEmpty()
        DiagnosticsTree.event(this, "INTENT", "external_command", "action=$action extras=${intent.extras?.keySet()?.joinToString() ?: "none"}")
        val shouldListen = intent.getBooleanExtra(EXTRA_START_LISTENING, false) ||
            action == ACTION_LISTEN || action == ACTION_CYANBRIDGE_LISTEN
        if (shouldListen) {
            continuousDialogue = prefs.getBoolean("continuous_dialogue", true)
            updateDialogueButton()
            window.decorView.postDelayed({
                if (!isFinishing) listen()
            }, 450)
        }
    }

    companion object {
        const val ACTION_LISTEN = "ru.stereoo.aiglasses.ACTION_LISTEN"
        const val ACTION_CYANBRIDGE_LISTEN = "com.fersaiyan.cyanbridge.ACTION_START_EXTERNAL_ASSISTANT"
        const val EXTRA_START_LISTENING = "ru.stereoo.aiglasses.EXTRA_START_LISTENING"
        const val ACTION_CYANBRIDGE_IMAGE_QUESTION = "com.fersaiyan.cyanbridge.ACTION_STEREOO_IMAGE_QUESTION"
        const val EXTRA_IMAGE_URI = "ru.stereoo.aiglasses.EXTRA_IMAGE_URI"
        const val EXTRA_IMAGE_QUESTION = "ru.stereoo.aiglasses.EXTRA_IMAGE_QUESTION"
    }

    /**
     * Accepts a photo URI from a glasses companion app using either a custom action
     * or Android's standard ACTION_SEND image intent. The URI must be readable by
     * this app (the sender should grant read permission).
     */
    private fun handleIncomingPhoto(intent: Intent?) {
        if (intent == null) return
        val action = intent.action.orEmpty()
        DiagnosticsTree.event(this, "PHOTO", "incoming_intent", "action=$action type=${intent.type.orEmpty()} extras=${intent.extras?.keySet()?.joinToString() ?: "none"}")
        val imageUri = when (action) {
            ACTION_CYANBRIDGE_IMAGE_QUESTION -> {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<android.net.Uri>(EXTRA_IMAGE_URI)
            }
            Intent.ACTION_SEND -> {
                if (intent.type?.startsWith("image/") == true) {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra<android.net.Uri>(Intent.EXTRA_STREAM)
                } else null
            }
            else -> null
        } ?: return

        val question = intent.getStringExtra(EXTRA_IMAGE_QUESTION)
            ?: intent.getStringExtra(Intent.EXTRA_TEXT)
            ?: "Опиши фотографию, сделанную умными очками. Расскажи, что на ней видно, по-русски."
        window.decorView.post {
            status.text = "Получена фотография от очков. Подготавливаю анализ…"
            speak("Фото получено. Анализирую")
            executor.execute {
                try {
                    contentResolver.openInputStream(imageUri).use { stream ->
                        val bitmap = BitmapFactory.decodeStream(stream)
                            ?: throw Exception("Не удалось прочитать изображение")
                        DiagnosticsTree.event(this, "PHOTO", "decoded", "width=${bitmap.width} height=${bitmap.height} questionLength=${question.length}")
                        runOnUiThread { sendImage(bitmap, question) }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        DiagnosticsTree.event(this, "PHOTO", "open_failed", "${e.javaClass.simpleName}: ${e.message}")
                        status.text = "Не удалось открыть фото от очков: ${e.message}"
                        speakAnswer("Не удалось открыть фотографию. Можешь попробовать ещё раз.")
                    }
                }
            }
        }
    }

    private fun updateDialogueButton() {
        dialogueButton?.text = if (continuousDialogue) "🔁 НЕПРЕРЫВНЫЙ ДИАЛОГ: ВКЛ" else "🔁 НЕПРЕРЫВНЫЙ ДИАЛОГ: ВЫКЛ"
    }

    private fun scheduleNextDialogueTurn() {
        if (!continuousDialogue || isFinishing || isDestroyed) return
        mainHandler.postDelayed({
            if (continuousDialogue && !isFinishing && !isDestroyed) listen(announce = false)
        }, 500)
    }

    private fun match(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
    }
    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val locale = Locale("ru", "RU")
            val result = tts.setLanguage(locale)
            ttsReady = result >= TextToSpeech.LANG_AVAILABLE
            if (ttsReady) {
                val selected = tts.voices.orEmpty()
                    .filter { it.locale.language == locale.language }
                    .maxByOrNull { voice ->
                        val name = voice.name.lowercase(Locale.ROOT)
                        val femaleBonus = if (listOf("female", "woman", "жен", "fem").any { name.contains(it) }) 1000 else 0
                        val networkBonus = if (voice.isNetworkConnectionRequired) 20 else 0
                        femaleBonus + voice.quality * 10 + networkBonus
                    }
                if (selected != null) {
                    val voiceResult = tts.setVoice(selected)
                    DiagnosticsTree.event(this, "AUDIO", "tts_voice_selected", "name=${selected.name} quality=${selected.quality} network=${selected.isNetworkConnectionRequired} result=$voiceResult")
                } else {
                    DiagnosticsTree.event(this, "AUDIO", "tts_voice_default", "no explicit Russian voice exposed by engine")
                }
                // Variant A: use the best Russian voice exposed by the installed TTS engine.
                // Slightly slower speech and a gentle pitch are intended to sound less robotic.
                tts.setSpeechRate(0.94f)
                tts.setPitch(1.06f)
                DiagnosticsTree.event(this, "AUDIO", "tts_style_applied", "locale=ru-RU rate=0.94 pitch=1.06 selected=${tts.voice?.name.orEmpty()}")
            }
            pendingSpeech?.let { queued ->
                pendingSpeech = null
                if (pendingSpeechIsAnswer) speakAnswer(queued) else speak(queued)
                pendingSpeechIsAnswer = false
            }
        }
    }

    private fun speak(message: String) {
        if (!ttsReady) {
            pendingSpeech = message
            return
        }
        tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "stereoo-${System.currentTimeMillis()}")
    }
    private fun speakAnswer(message: String) {
        if (!ttsReady) {
            pendingSpeech = message
            pendingSpeechIsAnswer = true
            return
        }
        pendingSpeechIsAnswer = false
        tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "dialogue-answer-${System.currentTimeMillis()}")
    }

    private fun listen(announce: Boolean = true) {
        DiagnosticsTree.event(this, "VOICE", "recognition_started", "locale=ru-RU continuous=$continuousDialogue announce=$announce")
        status.text = "Слушаю. Говори после появления окна распознавания."
        if (announce) speak("Слушаю")
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говори, я слушаю")
        }
        try { startActivityForResult(intent, 11) }
        catch (e: Exception) { DiagnosticsTree.event(this, "VOICE", "recognition_launch_failed", "${e.javaClass.simpleName}: ${e.message}"); status.text = "На телефоне не найден сервис распознавания речи: ${e.message}" }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 11) {
            if (resultCode != RESULT_OK || data == null) {
                DiagnosticsTree.event(this, "VOICE", "recognition_no_result", "resultCode=$resultCode dataNull=${data == null}")
                status.text = "Распознавание отменено или не удалось. Нажми «ГОВОРИТЬ» и попробуй ещё раз."
                // Use answer utterance ID so continuous mode resumes only after the prompt finishes.
                speakAnswer("Не удалось распознать речь. Я продолжу слушать через секунду.")
                return
            }
            val words = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val recognized = words?.firstOrNull()?.trim().orEmpty()
            if (recognized.isNotBlank()) {
                DiagnosticsTree.event(this, "VOICE", "recognized_text", "length=${recognized.length}")
                input.setText(recognized)
                status.text = "Распознано: $recognized\nОтправляю вопрос в OpenAI…"
                sendText(recognized)
            } else {
                status.text = "Речь не распознана. Попробуй говорить чуть громче и ближе к микрофону."
                speakAnswer("Речь не распознана. Я продолжу слушать.")
            }
        } else if (requestCode == 22) {
            if (resultCode != RESULT_OK || data == null) {
                DiagnosticsTree.event(this, "PHOTO", "picker_cancelled", "resultCode=$resultCode dataNull=${data == null}")
                status.text = "Выбор фотографии отменён."
                return
            }
            val uri = data.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream) ?: throw Exception("Не удалось прочитать изображение")
                    sendImage(bitmap)
                }
            } catch (e: Exception) { status.text = "Ошибка фото: ${e.message}" }
        }
    }
    private fun exportDiagnostics() {
        DiagnosticsTree.event(this, "DIAGNOSTICS", "export_requested")
        val text = DiagnosticsTree.exportText(this)
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Stereoo glasses AI diagnostic log")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(share, "Отправить журнал ошибок"))
    }

    private fun keyDialog() {
        val field = EditText(this).apply {
            hint = "sk-..."
            setText(prefs.getString("api_key", ""))
            inputType = 129
        }
        AlertDialog.Builder(this).setTitle("API-ключ OpenAI")
            .setMessage("Ключ хранится только в данных этого приложения на телефоне. Не публикуй его в GitHub.")
            .setView(field)
            .setPositiveButton("Сохранить") { _, _ ->
                prefs.edit().putString("api_key", field.text.toString().trim()).apply()
                status.text = "API-ключ сохранён на устройстве."
            }.setNegativeButton("Отмена", null).show()
    }
    private fun sendText(text: String) {
        if (text.isBlank()) { status.text = "Сначала введи вопрос или нажми «Говорить»."; speak("Сначала задай вопрос"); return }
        val body = JSONObject().put("model", "gpt-4.1-mini")
            .put("input", text)
        callApi(body)
    }
    private fun sendImage(
        bitmap: Bitmap,
        question: String = "Опиши фотографию по-русски."
    ) {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) {
            status.text = "Не найден API-ключ OpenAI. Нажми «Настроить API-ключ»."
            speak("Не найден ключ OpenAI. Открой настройку API ключа")
            keyDialog(); return
        }
        DiagnosticsTree.event(this, "PHOTO", "sending_to_api", "width=${bitmap.width} height=${bitmap.height} questionLength=${question.length}")
        status.text = "Отправляю фотографию на анализ…"
        val scaled = if (bitmap.width > 1200 || bitmap.height > 1200) {
            val ratio = minOf(1200f / bitmap.width, 1200f / bitmap.height)
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
        } else bitmap
        val bytes = ByteArrayOutputStream().also { scaled.compress(Bitmap.CompressFormat.JPEG, 82, it) }.toByteArray()
        val dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        val content = JSONArray()
            .put(JSONObject().put("type", "input_text").put("text", question))
            .put(JSONObject().put("type", "input_image").put("image_url", dataUrl))
        callApi(JSONObject().put("model", "gpt-4.1-mini")
            .put("input", JSONArray().put(JSONObject().put("role", "user").put("content", content))))
    }
    private fun callApi(body: JSONObject) {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) {
            status.text = "Не найден API-ключ OpenAI. Нажми «Настроить API-ключ»."
            speak("Не найден ключ OpenAI. Открой настройку API ключа")
            keyDialog(); return
        }
        DiagnosticsTree.event(this, "API", "request_started", "model=${body.optString("model")} inputType=${if (body.optJSONArray("input") != null) "messages_or_parts" else "text"}")
        status.text = "Запрос отправлен в OpenAI. Жду ответ…"
        executor.execute {
            try {
                val conn = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 60000
                conn.doOutput = true
                conn.setRequestProperty("Authorization", "Bearer $key")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                DiagnosticsTree.event(this, "API", "http_response", "code=${conn.responseCode}")
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) throw Exception(JSONObject(response).optJSONObject("error")?.optString("message") ?: response)
                val json = JSONObject(response)
                // Responses API may expose a convenient top-level output_text in addition
                // to the text parts nested inside output[].
                val result = StringBuilder()
                val topLevelText = json.optString("output_text", "")
                if (topLevelText.isNotBlank()) result.append(topLevelText)
                val output = if (topLevelText.isBlank()) json.optJSONArray("output") ?: JSONArray() else JSONArray()
                for (i in 0 until output.length()) {
                    val item = output.optJSONObject(i) ?: continue
                    val content = item.optJSONArray("content") ?: continue
                    for (j in 0 until content.length()) {
                        val part = content.optJSONObject(j) ?: continue
                        if (part.optString("type") == "output_text") result.append(part.optString("text"))
                    }
                }
                val answer = result.toString().trim().ifBlank {
                    val responseStatus = json.optString("status", "неизвестен")
                    val incomplete = json.optJSONObject("incomplete_details")?.optString("reason")
                    "OpenAI не вернул текстовый ответ (статус: $responseStatus${incomplete?.let { ", причина: $it"}.orEmpty()})."
                }
                DiagnosticsTree.event(this, "API", "answer_received", "status=${json.optString("status", "unknown")} answerLength=${answer.length}")
                runOnUiThread {
                    lastAnswer = answer
                    status.text = answer
                    speakAnswer(answer)
                }
                conn.disconnect()
            } catch (e: Exception) {
                val message = e.message ?: "не удалось связаться с API"
                DiagnosticsTree.event(this, "API", "request_failed", "${e.javaClass.simpleName}: $message")
                android.util.Log.e("StereooAssistant", "OpenAI request failed", e)
                runOnUiThread {
                    status.text = "Ошибка OpenAI: $message"
                    speakAnswer("Ошибка OpenAI. $message")
                }
            }
        }
    }
    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        tts.stop(); tts.shutdown(); executor.shutdownNow()
        super.onDestroy()
    }
}
