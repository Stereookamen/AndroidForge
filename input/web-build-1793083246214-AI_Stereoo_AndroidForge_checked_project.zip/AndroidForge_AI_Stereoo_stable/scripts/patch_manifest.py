#!/usr/bin/env python3
"""Apply deterministic package/name/version edits after Apktool decoding."""
from __future__ import annotations
import argparse
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

ANDROID_NS = "http://schemas.android.com/apk/res/android"
ANDROID = "{" + ANDROID_NS + "}"
ET.register_namespace("android", ANDROID_NS)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--decoded", type=Path, required=True)
    p.add_argument("--native", type=Path, required=True)
    p.add_argument("--report", type=Path, required=True)
    a = p.parse_args()
    manifest = a.decoded / "AndroidManifest.xml"
    if not manifest.is_file():
        raise SystemExit(f"ERROR: Apktool did not produce {manifest}")

    tree = ET.parse(manifest)
    root = tree.getroot()
    if root.tag != "manifest":
        raise SystemExit(f"ERROR: unexpected manifest root {root.tag!r}")

    old_pkg = "com.glasssutdio.wear"
    new_pkg = "ru.stereoo.ai"
    root.set("package", new_pkg)
    root.set(ANDROID + "versionName", "1.0")
    root.set(ANDROID + "versionCode", "173")
    # A label on <manifest> is not the Android launcher label. Set it on the
    # actual <application> element; this was the bug in the previous script.
    root.attrib.pop(ANDROID + "label", None)
    app = root.find("application")
    if app is None:
        raise SystemExit("ERROR: manifest has no <application> element")
    app.set(ANDROID + "label", "AI Stereoo")
    app.set(ANDROID + "extractNativeLibs", "true")

    # Fully qualify components to keep their original implementation package
    # after the manifest's application ID changes.
    for elem in root.iter():
        name = elem.get(ANDROID + "name")
        if name:
            if name.startswith("."):
                elem.set(ANDROID + "name", old_pkg + name)
            elif "." not in name:
                elem.set(ANDROID + "name", old_pkg + "." + name)
        authorities = elem.get(ANDROID + "authorities")
        if authorities:
            elem.set(ANDROID + "authorities", authorities.replace(old_pkg, new_pkg))

    # Only clear split-delivery markers after the complete arm64 native payload
    # passed validation and was copied into the decoded tree.
    for attr in ("isSplitRequired", "requiredSplitTypes", "splitTypes", "configForSplit", "isFeatureSplit"):
        root.attrib.pop(ANDROID + attr, None)
    root.attrib.pop("split", None)

    tree.write(manifest, encoding="utf-8", xml_declaration=True)

    # Resource labels may also appear in menus or app-specific surfaces. Update
    # only strings explicitly named app_name; do not replace arbitrary text.
    strings_changed = []
    for strings_file in (a.decoded / "res").glob("values*/strings.xml"):
        try:
            st = ET.parse(strings_file)
        except ET.ParseError:
            continue
        changed = False
        for node in st.getroot().findall("string"):
            if node.get("name") == "app_name":
                node.text = "AI Stereoo"
                changed = True
        if changed:
            st.write(strings_file, encoding="utf-8", xml_declaration=True)
            strings_changed.append(str(strings_file.relative_to(a.decoded)))

    # Merge all validated .so libraries into the decoded APK tree.
    copied = 0
    for lib in a.native.rglob("*.so"):
        rel = lib.relative_to(a.native)
        dest = a.decoded / "lib" / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(lib, dest)
        copied += 1
    if copied == 0:
        raise SystemExit("ERROR: native payload unexpectedly empty after validation")

    # Make the final manifest/resource state auditable before Apktool rebuilds.
    final_tree = ET.parse(manifest)
    final_root = final_tree.getroot()
    final_app = final_root.find("application")
    if final_root.get("package") != new_pkg:
        raise SystemExit("ERROR: package ID verification failed")
    if final_app is None or final_app.get(ANDROID + "label") != "AI Stereoo":
        raise SystemExit("ERROR: launcher label verification failed")
    if final_root.get(ANDROID + "versionName") != "1.0":
        raise SystemExit("ERROR: versionName verification failed")

    a.report.parent.mkdir(parents=True, exist_ok=True)
    a.report.write_text(
        "Package: ru.stereoo.ai\n"
        "Application label: AI Stereoo\n"
        "Version: 1.0 (code 173)\n"
        f"Native libraries copied: {copied}\n"
        f"Localized app_name resources updated: {len(strings_changed)}\n"
        "targetSdkVersion: preserved from original (not changed speculatively)\n",
        encoding="utf-8",
    )
    print(f"Verified manifest: package={new_pkg}; label=AI Stereoo; version=1.0/code 173")
    print(f"Merged {copied} native libraries into decoded APK")


if __name__ == "__main__":
    main()
