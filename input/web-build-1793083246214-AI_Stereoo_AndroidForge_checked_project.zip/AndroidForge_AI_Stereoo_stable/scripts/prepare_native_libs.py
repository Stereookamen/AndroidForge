#!/usr/bin/env python3
"""Validate and extract ABI libraries from a complete monolithic APK.

Split APK resource tables are not merged here. This script deliberately fails
closed instead of producing a known-broken APK from an incomplete base APK.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path, PurePosixPath

CORE_REQUIRED = {
    "arm64-v8a": {
        "libmmkv.so",
        "libaw-glass-img-sdk.so",
        "libaw-ai-image-utils.so",
        "libaw-license-native.so",
        "libglass_auth.so",
        "libaweis_jni.so",
        "libvlc.so",
        "libvlcjni.so",
        "libMicrosoft.CognitiveServices.Speech.core.so",
        "libMicrosoft.CognitiveServices.Speech.java.bindings.so",
        "libjl_opus.so",
        "libjl_speex.so",
    }
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True, type=Path)
    parser.add_argument("--splits", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()

    if not args.base.is_file():
        print(f"ERROR: source APK is missing: {args.base}", file=sys.stderr)
        return 2

    args.out.mkdir(parents=True, exist_ok=True)
    args.splits.mkdir(parents=True, exist_ok=True)

    # Only a self-contained, monolithic APK is accepted. This repacker does not
    # merge Android resource tables from split APKs; accepting a base + ABI split
    # could fix MMKV while leaving other split-delivered resources missing.
    split_inputs = sorted(list(args.splits.glob("*.splitapk")) + list(args.splits.glob("*.apk")))
    if split_inputs:
        print("ERROR: split APK files were found, but this builder cannot safely merge split resource tables.", file=sys.stderr)
        print("Use a complete monolithic HeyCyan APK instead. No output APK was produced.", file=sys.stderr)
        print("Split files detected:", file=sys.stderr)
        for item in split_inputs:
            print(f"  - {item.name}", file=sys.stderr)
        return 13

    source = args.base
    sources = [source]
    collected: dict[str, dict[str, bytes]] = {}
    source_entries: dict[str, int] = {}
    errors: list[str] = []

    try:
        with zipfile.ZipFile(source) as zf:
            count = 0
            for info in zf.infolist():
                name = info.filename
                if info.is_dir() or not name.endswith(".so"):
                    continue
                parts = PurePosixPath(name).parts
                if len(parts) != 3 or parts[0] != "lib":
                    continue
                abi, libname = parts[1], parts[2]
                if not libname.startswith("lib"):
                    continue
                payload = zf.read(info)
                collected.setdefault(abi, {})
                old = collected[abi].get(libname)
                if old is not None and sha256(old) != sha256(payload):
                    errors.append(f"Conflicting duplicate library in source APK: {abi}/{libname}")
                    continue
                collected[abi][libname] = payload
                count += 1
            source_entries[source.name] = count
    except (zipfile.BadZipFile, OSError) as exc:
        print(f"ERROR: cannot read source APK archive {source}: {exc}", file=sys.stderr)
        return 4

    if errors:
        print("ERROR: native library validation failed:", file=sys.stderr)
        for error in errors:
            print(f"  - {error}", file=sys.stderr)
        return 5

    if not collected:
        report = {
            "status": "blocked_missing_native_libraries",
            "base_apk": str(args.base),
            "native_library_count": 0,
            "sources_scanned": [str(p) for p in sources],
            "source_entries": source_entries,
        }
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("\nBUILD STOPPED: the supplied HeyCyan base APK contains zero native .so libraries.")
        print("The app calls System.loadLibrary('mmkv') during Application.onCreate().")
        print("The same DEX also loads vendor, VLC, Microsoft Speech, and audio JNI libraries.")
        print("Rebuilding the base APK without those libraries creates an APK that installs but crashes.")
        print("\nRequired input: a complete, monolithic HeyCyan APK containing lib/arm64-v8a/*.so.")
        print("Base APKs and split-only packages are not enough for this builder.")
        print("This build has intentionally stopped before producing any installable APK.")
        return 10

    abi = "arm64-v8a"
    if abi not in collected:
        report = {
            "status": "blocked_missing_arm64",
            "native_library_count": sum(len(v) for v in collected.values()),
            "abis_found": sorted(collected),
            "sources_scanned": [str(p) for p in sources],
            "source_entries": source_entries,
        }
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"ERROR: native libraries were found, but ABI {abi} is missing. Found: {', '.join(sorted(collected))}", file=sys.stderr)
        return 11

    missing = sorted(CORE_REQUIRED[abi] - set(collected[abi]))
    if missing:
        report = {
            "status": "blocked_incomplete_native_payload",
            "native_library_count_by_abi": {k: len(v) for k, v in collected.items()},
            "abis_found": sorted(collected),
            "missing_core_arm64_libraries": missing,
            "sources_scanned": [str(p) for p in sources],
            "source_entries": source_entries,
        }
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("ERROR: native payload is incomplete for arm64-v8a.", file=sys.stderr)
        print("Missing required libraries:", file=sys.stderr)
        for lib in missing:
            print(f"  - {lib}", file=sys.stderr)
        print("Use a complete monolithic APK from the same version/build.", file=sys.stderr)
        return 12

    # Clear stale output first, then save every recovered ABI library.
    for path in args.out.rglob("*.so"):
        path.unlink()
    for name, payload in collected[abi].items():
        dest = args.out / abi / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(payload)

    report = {
        "status": "native_payload_ready",
        "native_library_count_by_abi": {k: len(v) for k, v in collected.items()},
        "abis_found": sorted(collected),
        "core_required_arm64_libraries": sorted(CORE_REQUIRED[abi]),
        "sources_scanned": [str(p) for p in sources],
        "source_entries": source_entries,
        "output_directory": str(args.out),
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("Native payload validated:")
    for found_abi, libs in sorted(collected.items()):
        print(f"  {found_abi}: {len(libs)} shared libraries")
    print(f"  output: {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
