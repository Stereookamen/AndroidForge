This converter intentionally does not merge split APKs, because resource-table
merging needs a bundle-aware tool and the set may have required ABI and density
splits. Putting only config.arm64_v8a here will not be accepted.

Use a complete monolithic HeyCyan APK whose ZIP entries contain
lib/arm64-v8a/*.so. The supplied 42.9 MB APK is the base portion and has no
native shared libraries, so it cannot be the only build input.
