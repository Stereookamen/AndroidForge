#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
APK_IN="original/HeyCyan.source"
SPLITS="original/splits"
DECODED="work/decoded"
NATIVE="work/native_payload"
OUT="output/Stereoo_AI_1.0.apk"
APKTOOL_JAR="apktool.jar"
APKTOOL_VERSION="2.12.1"

mkdir -p output work audit "$SPLITS"
rm -rf "$DECODED" "$NATIVE"
rm -f "$OUT" work/unsigned.apk work/aligned.apk audit/native-payload.json audit/manifest-patch.txt

# Fail before doing a costly build if we only have the base APK without JNI libs.
python3 scripts/prepare_native_libs.py \
  --base "$APK_IN" --splits "$SPLITS" --out "$NATIVE" \
  --report audit/native-payload.json

if [ ! -s "$APKTOOL_JAR" ]; then
  APKTOOL_URL="https://github.com/iBotPeaches/Apktool/releases/download/v${APKTOOL_VERSION}/apktool_${APKTOOL_VERSION}.jar"
  echo "Downloading Apktool ${APKTOOL_VERSION}..."
  curl -fL --retry 3 --retry-delay 2 "$APKTOOL_URL" -o "$APKTOOL_JAR"
fi
APKTOOL=(java -jar "$APKTOOL_JAR")
test -s "$APK_IN" || { echo "ERROR: source APK missing: $APK_IN"; exit 2; }

"${APKTOOL[@]}" d -f "$APK_IN" -o "$DECODED"
python3 scripts/patch_manifest.py \
  --decoded "$DECODED" --native "$NATIVE" --report audit/manifest-patch.txt

"${APKTOOL[@]}" b "$DECODED" -o work/unsigned.apk
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ]; then
  echo "ERROR: ANDROID_HOME/ANDROID_SDK_ROOT is not set" >&2
  exit 3
fi
BUILD_TOOLS="$(find "$SDK/build-tools" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -1)"
test -n "$BUILD_TOOLS" || { echo "ERROR: Android SDK build-tools are missing" >&2; exit 4; }
test -x "$BUILD_TOOLS/zipalign" || { echo "ERROR: zipalign not found in $BUILD_TOOLS" >&2; exit 4; }
test -x "$BUILD_TOOLS/apksigner" || { echo "ERROR: apksigner not found in $BUILD_TOOLS" >&2; exit 4; }

"$BUILD_TOOLS/zipalign" -f 4 work/unsigned.apk work/aligned.apk
KEYSTORE="signing/stereoo-debug.keystore"
test -s "$KEYSTORE" || { echo "ERROR: stable signing keystore is missing: $KEYSTORE" >&2; exit 5; }
"$BUILD_TOOLS/apksigner" sign \
  --ks "$KEYSTORE" --ks-key-alias stereoo \
  --ks-pass pass:android --key-pass pass:android \
  --out "$OUT" work/aligned.apk
"$BUILD_TOOLS/apksigner" verify --verbose "$OUT"

# Post-build gates: one valid result, expected package metadata, native payload.
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
apk = Path('output/Stereoo_AI_1.0.apk')
if not apk.is_file() or apk.stat().st_size < 5 * 1024 * 1024:
    raise SystemExit('ERROR: output APK is missing or suspiciously small')
with ZipFile(apk) as z:
    bad = z.testzip()
    if bad:
        raise SystemExit(f'ERROR: APK ZIP integrity test failed at {bad}')
    names = z.namelist()
    native = [n for n in names if n.startswith('lib/arm64-v8a/') and n.endswith('.so')]
    if 'lib/arm64-v8a/libmmkv.so' not in names:
        raise SystemExit('ERROR: output APK does not contain lib/arm64-v8a/libmmkv.so')
    if len(native) < 12:
        raise SystemExit(f'ERROR: output APK contains only {len(native)} arm64 native libraries')
    if 'classes.dex' not in names or 'AndroidManifest.xml' not in names:
        raise SystemExit('ERROR: output APK is missing AndroidManifest.xml or classes.dex')
with open('audit/build-result.txt', 'w', encoding='utf-8') as f:
    f.write(f'APK: {apk}\nSize bytes: {apk.stat().st_size}\nArm64 native libraries: {len(native)}\n')
print(f'APK archive check passed: {apk.stat().st_size} bytes; {len(native)} arm64 .so files')
PY

# Critical for AndroidForge: only the final, signed APK must remain discoverable.
rm -f work/unsigned.apk work/aligned.apk
find . -type f -name '*.apk' -not -path "./$OUT" -print -delete
printf '\nSUCCESS: %s\n' "$OUT"
printf 'SHA-256: '
sha256sum "$OUT" | awk '{print $1}'
printf 'APK bytes: '
stat -c '%s' "$OUT"
