package ru.stereoo.morkovsk

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

/**
 * The app cannot grant itself restricted settings or Accessibility permissions.
 * Every settings page below is launched by a user gesture; user approves access in Android UI.
 */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var setupState: TextView
    private val store by lazy { getSharedPreferences("morkovsk", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        setupState = findViewById(R.id.setupState)

        findViewById<Button>(R.id.accessibility).setOnClickListener { openAccessibilitySettings() }
        findViewById<Button>(R.id.appInfo).setOnClickListener { openAppInfo() }
        findViewById<Button>(R.id.guide).setOnClickListener {
            startActivity(Intent(this, SetupGuideActivity::class.java))
        }
        findViewById<Button>(R.id.checkAccess).setOnClickListener {
            updateStatus()
            toast(if (accessibilityEnabled()) "Служба включена ✓" else "Служба ещё не включена. Открой инструкцию.")
        }
        findViewById<Button>(R.id.openOzon).setOnClickListener { openOzon() }
        findViewById<Button>(R.id.start).setOnClickListener {
            if (MorkovService.current == null) {
                toast("Спецвозможности не подключены. Открой инструкцию и включи службу вручную")
                startActivity(Intent(this, SetupGuideActivity::class.java))
            } else {
                MorkovService.current?.startRun()
                openOzon()
            }
            updateStatus()
        }
        findViewById<Button>(R.id.continueBtn).setOnClickListener {
            MorkovService.current?.manualCartDone()
                ?: toast("Сначала включи спецвозможности")
            updateStatus()
        }
        findViewById<Button>(R.id.scan).setOnClickListener {
            MorkovService.current?.scanNow()
            updateStatus()
        }
        findViewById<Button>(R.id.diagnostic).setOnClickListener {
            val report = store.getString("diagnostic", "") ?: ""
            if (report.isBlank()) toast("Нет показаний. Запусти программу и открой Морковск.")
            else {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Морковск: диагностика", report))
                toast("Диагностика скопирована. Проверь личные данные перед отправкой.")
            }
        }
        findViewById<Button>(R.id.stop).setOnClickListener {
            MorkovService.current?.stopRun()
            updateStatus()
        }
    }

    override fun onResume() { super.onResume(); updateStatus() }

    private fun accessibilityEnabled(): Boolean {
        return try {
            val manager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any { entry ->
                val service = entry.resolveInfo?.serviceInfo
                service?.packageName == packageName && service.name == MorkovService::class.java.name
            }
        } catch (_: Exception) { MorkovService.current != null }
    }

    private fun updateStatus() {
        val enabled = accessibilityEnabled()
        val connected = MorkovService.current != null
        val running = store.getBoolean("running", false)
        setupState.text = when {
            connected -> "✅ Специальные возможности подключены. Можно запускать."
            enabled -> "🟡 Служба разрешена в Android, но ещё не подключилась. Вернись сюда через пару секунд."
            else -> "🔒 Служба выключена. Сначала открой инструкцию ниже."
        }
        status.text = "Спецвозможности: ${if (enabled) "включены ✓" else "НЕ включены"}\n" +
            "Автоматика: ${if (running) "РАБОТАЕТ" else "не работает"}\n" +
            "Этап: ${store.getString("phase", "—")}\n" +
            "Посещено разделов: ${store.getInt("visits", 0)}\n" +
            "Добавление в корзину: ${if (store.getInt("cart", 0) == 1) "кнопка нажата" else "не выполнено"}\n\n" +
            (store.getString("status", "Нажми «Начать сбор», когда Ozon готов.") ?: "")
    }

    private fun openAccessibilitySettings() {
        try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        catch (_: Exception) { toast("Не удалось открыть настройки. Открой Настройки → Спецвозможности вручную.") }
    }

    private fun openAppInfo() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            })
        } catch (_: Exception) {
            toast("Не удалось открыть сведения. Открой Настройки → Приложения → Морковск Авто.")
        }
    }

    private fun openOzon() {
        val deepLink = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ozon.ru/gameapp/main?miniapp=regularDraw")).apply {
            setPackage(MorkovService.OZON)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(deepLink) }
        catch (_: Exception) {
            val launch = packageManager.getLaunchIntentForPackage(MorkovService.OZON)
            if (launch != null) {
                startActivity(launch)
                toast("Открой «Морковск» в Ozon вручную")
            } else toast("Ozon не найден. Установи официальный Ozon.")
        }
    }

    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
}
