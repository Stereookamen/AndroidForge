package ru.stereoo.chatgptwatch;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Phone-side companion. No OpenAI API, no credentials, no voice recording. */
public class PhoneActivity extends Activity {
    private TextView info;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        drawUi();
        if (isRequestFromWatch(getIntent())) {
            info.setText("Команда от часов получена. Запускаю ChatGPT…");
            openChatGpt();
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (isRequestFromWatch(intent)) {
            info.setText("Команда от часов получена. Запускаю ChatGPT…");
            openChatGpt();
        }
    }

    private boolean isRequestFromWatch(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        return intent != null && Intent.ACTION_VIEW.equals(intent.getAction())
            && uri != null && "stereoo".equals(uri.getScheme())
            && "chatgpt".equals(uri.getHost()) && "/open".equals(uri.getPath());
    }

    private void openChatGpt() {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
            if (intent == null) {
                info.setText("ChatGPT не установлен. Установи официальное приложение, войди в аккаунт и включи «Запускать с голосом» в настройках Voice, если этот пункт доступен.");
                return;
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(intent);
            // Do not call finish(); phone can return to this diagnostic screen.
        } catch (ActivityNotFoundException | SecurityException e) {
            info.setText("Не получилось открыть ChatGPT: " + e.getMessage());
        }
    }

    private void drawUi() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setPadding(dp(26), dp(55), dp(26), dp(28));
        layout.setBackgroundColor(Color.rgb(10, 14, 24));
        TextView title = label("Stereoo\nChatGPT Bridge", 28, 0xffe4ebff, true);
        layout.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = label("Связь часов с ChatGPT на смартфоне\nБез OpenAI API", 16, 0xff9cacc9, false);
        LinearLayout.LayoutParams st = new LinearLayout.LayoutParams(-1, -2);
        st.topMargin = dp(24);
        layout.addView(sub, st);
        info = label("Готово к приёму команды с TicWatch Pro 3. Открой приложение на часах и нажми кнопку запуска.", 16, 0xffdce3f4, false);
        LinearLayout.LayoutParams si = new LinearLayout.LayoutParams(-1, -2);
        si.topMargin = dp(30);
        layout.addView(info, si);
        Button button = new Button(this);
        button.setText("ПРОВЕРИТЬ CHATGPT");
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xff444edb);
        bg.setCornerRadius(dp(14));
        button.setBackground(bg);
        button.setOnClickListener(v -> openChatGpt());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.topMargin = dp(28);
        layout.addView(button, bp);
        TextView foot = label("Разработчик: Жданов Александр\nГолос работает на телефоне, не через микрофон часов.", 13, 0xff8491aa, false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(35);
        layout.addView(foot, fp);
        setContentView(layout);
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text.replace("\\n", "\n"));
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }
}
