package com.fersaiyan.cyanbridge.stereoo

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.content.res.ColorStateList
import android.media.MediaPlayer
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import android.util.Base64

class StereooAssistantActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var lastAnswer = ""
    @Volatile private var ttsReady = false
    private var pendingSpeech: String? = null
    @Volatile private var speechGeneration = 0
    private var speechPlayer: MediaPlayer? = null
    private var speechFile: File? = null
    private lateinit var continuousToggle: Switch
    private lateinit var interruptToggle: Switch
    private var toneGenerator: ToneGenerator? = null
    @Volatile private var resumeAfterSpeech = false
    @Volatile private var recognitionInProgress = false
    @Volatile private var conversationActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DiagnosticsTree.event(this, "APP", "assistant_activity_created", "action=${intent?.action.orEmpty()}")
        tts = TextToSpeech(this, this)
        val bg = Color.rgb(39, 8, 24)
        val primaryText = Color.rgb(255, 232, 241)
        val secondaryText = Color.rgb(255, 190, 215)
        val accent = Color.rgb(239, 35, 112)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(bg)
        }
        layout.addView(TextView(this).apply {
            text = "Stereoo AI"
            textSize = 25f
            setTextColor(primaryText)
            gravity = Gravity.CENTER
        }, match(-1, -2))
        layout.addView(TextView(this).apply {
            text = "Голосовой помощник и анализ фотографий"
            textSize = 15f
            setTextColor(secondaryText)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }, match(-1, -2))
        input = EditText(this).apply {
            hint = "Напиши вопрос..."
            minLines = 2
            gravity = Gravity.TOP
            setTextColor(primaryText)
            setHintTextColor(secondaryText)
            backgroundTintList = ColorStateList.valueOf(accent)
        }
        layout.addView(input, match(-1, -2))
        continuousToggle = Switch(this).apply {
            text = "Непрерывный диалог"
            textSize = 16f
            setTextColor(primaryText)
            isChecked = prefs.getBoolean("continuous_dialogue", true)
            thumbTintList = ColorStateList.valueOf(accent)
            trackTintList = ColorStateList.valueOf(Color.rgb(125, 49, 79))
            setPadding(4, 10, 4, 10)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("continuous_dialogue", checked).apply()
                status.text = if (checked) "Непрерывный диалог включён" else "Непрерывный диалог выключен"
            }
        }
        layout.addView(continuousToggle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8; bottomMargin = 4 })
        interruptToggle = Switch(this).apply {
            text = "Разрешить перебивать ассистента"
            textSize = 16f
            setTextColor(primaryText)
            isChecked = prefs.getBoolean("allow_interrupt", true)
            thumbTintList = ColorStateList.valueOf(accent)
            trackTintList = ColorStateList.valueOf(Color.rgb(125, 49, 79))
            setPadding(4, 8, 4, 8)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("allow_interrupt", checked).apply()
                status.text = if (checked) "Можно перебивать ответ кнопкой очков" else "Ассистент закончит ответ перед следующим вопросом"
            }
        }
        layout.addView(interruptToggle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 4; bottomMargin = 8 })
        addButton(layout, "⏹ ЗАВЕРШИТЬ РАЗГОВОР") { endConversation("Нажата кнопка завершения") }
        addButton(layout, "ОТПРАВИТЬ ВОПРОС") { sendText(input.text.toString()) }
        addButton(layout, "🎙 ГОВОРИТЬ") { listen() }
        addButton(layout, "📷 ВЫБРАТЬ ФОТОГРАФИЮ") {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 22)
        }
        addButton(layout, "🔊 ПОВТОРИТЬ ОТВЕТ") {
            if (lastAnswer.isNotBlank()) speak(lastAnswer)
        }
        addButton(layout, "🎛 ГОЛОС И ОБЩЕНИЕ") { preferencesDialog() }
        addButton(layout, "🔑 НАСТРОИТЬ API-КЛЮЧ") { keyDialog() }
        addButton(layout, "🧰 ЖУРНАЛ ОШИБОК: ПОДЕЛИТЬСЯ") { exportDiagnostics() }
        addButton(layout, "🧹 ОЧИСТИТЬ ЖУРНАЛ") {
            DiagnosticsTree.clear(this)
            DiagnosticsTree.event(this, "DIAGNOSTICS", "log_cleared")
            Toast.makeText(this, "Журнал очищен", Toast.LENGTH_SHORT).show()
        }
        status = TextView(this).apply {
            text = "Готов к работе. Для ответов нужен API-ключ OpenAI."
            textSize = 15f
            setTextColor(primaryText)
            setPadding(0, 16, 0, 0)
        }
        layout.addView(status, match(-1, -2))
        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(layout)
        })
        handleExternalCommand(intent)
        handleIncomingPhoto(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleExternalCommand(intent)
        handleIncomingPhoto(intent)
    }

    private fun handleExternalCommand(intent: Intent?) {
        if (intent == null) return
        val action = intent.action.orEmpty()
        DiagnosticsTree.event(this, "INTENT", "external_command", "action=$action extras=${intent.extras?.keySet()?.joinToString() ?: "none"}")
        val shouldListen = intent.getBooleanExtra(EXTRA_START_LISTENING, false) ||
            action == ACTION_LISTEN || action == ACTION_CYANBRIDGE_LISTEN
        if (shouldListen) {
            when {
                isSpeakingNow() && prefs.getBoolean("allow_interrupt", true) -> {
                    conversationActive = true
                    stopCurrentSpeech()
                    recognitionInProgress = false
                    DiagnosticsTree.event(this, "VOICE", "barge_in", "allowed=true source=glasses_button")
                    window.decorView.postDelayed({ if (!isFinishing && !isDestroyed) listen() }, 250)
                }
                isSpeakingNow() -> {
                    // Do not start a second recognizer while the current answer is playing.
                    // If continuous dialogue is enabled, onSpeechFinished() will resume later.
                    conversationActive = true
                    status.text = "Сначала закончу ответ. Затем можно будет говорить."
                    DiagnosticsTree.event(this, "VOICE", "barge_in_ignored", "allowed=false")
                }
                recognitionInProgress -> {
                    // A second glasses-button press while the recognizer is open is the
                    // hardware equivalent of hanging up; keep the user preference intact.
                    endConversation("glasses_button_during_listening")
                }
                else -> {
                    conversationActive = true
                    window.decorView.postDelayed({ if (!isFinishing && !isDestroyed) listen() }, 450)
                }
            }
        }
    }

    companion object {
        const val ACTION_LISTEN = "ru.stereoo.aiglasses.ACTION_LISTEN"
        const val ACTION_CYANBRIDGE_LISTEN = "com.fersaiyan.cyanbridge.ACTION_START_EXTERNAL_ASSISTANT"
        const val EXTRA_START_LISTENING = "ru.stereoo.aiglasses.EXTRA_START_LISTENING"
        const val ACTION_CYANBRIDGE_IMAGE_QUESTION = "com.fersaiyan.cyanbridge.ACTION_STEREOO_IMAGE_QUESTION"
        const val EXTRA_IMAGE_URI = "ru.stereoo.aiglasses.EXTRA_IMAGE_URI"
        const val EXTRA_IMAGE_QUESTION = "ru.stereoo.aiglasses.EXTRA_IMAGE_QUESTION"
        const val ACTION_START_VOICE_IMAGE_QUESTION = "ru.stereoo.aiglasses.ACTION_START_VOICE_IMAGE_QUESTION"
        const val EXTRA_VOICE_IMAGE_QUESTION = "ru.stereoo.aiglasses.EXTRA_VOICE_IMAGE_QUESTION"
    }

    /**
     * Accepts a photo URI from a glasses companion app using either a custom action
     * or Android's standard ACTION_SEND image intent. The URI must be readable by
     * this app (the sender should grant read permission).
     */
    private fun handleIncomingPhoto(intent: Intent?) {
        if (intent == null) return
        val action = intent.action.orEmpty()
        DiagnosticsTree.event(this, "PHOTO", "incoming_intent", "action=$action type=${intent.type.orEmpty()} extras=${intent.extras?.keySet()?.joinToString() ?: "none"}")
        val imageUri = when (action) {
            ACTION_CYANBRIDGE_IMAGE_QUESTION -> {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<android.net.Uri>(EXTRA_IMAGE_URI)
            }
            Intent.ACTION_SEND -> {
                if (intent.type?.startsWith("image/") == true) {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra<android.net.Uri>(Intent.EXTRA_STREAM)
                } else null
            }
            else -> null
        } ?: return

        val question = intent.getStringExtra(EXTRA_IMAGE_QUESTION)
            ?: intent.getStringExtra(Intent.EXTRA_TEXT)
            ?: "Опиши фотографию, сделанную умными очками. Расскажи, что на ней видно, по-русски."
        window.decorView.post {
            status.text = "Получена фотография от очков. Подготавливаю анализ…"
            executor.execute {
                try {
                    contentResolver.openInputStream(imageUri).use { stream ->
                        val bitmap = BitmapFactory.decodeStream(stream)
                            ?: throw Exception("Не удалось прочитать изображение")
                        DiagnosticsTree.event(this, "PHOTO", "decoded", "width=${bitmap.width} height=${bitmap.height} questionLength=${question.length}")
                        runOnUiThread { sendImage(bitmap, question) }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        DiagnosticsTree.event(this, "PHOTO", "open_failed", "${e.javaClass.simpleName}: ${e.message}")
                        status.text = "Не удалось открыть фото от очков: ${e.message}"
                        speak("Не удалось открыть фотографию")
                    }
                }
            }
        }
    }

    private fun match(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
    }
    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("ru", "RU"))
            ttsReady = result >= TextToSpeech.LANG_AVAILABLE
            // Slightly soften the Android fallback. The exact voice still depends on
            // the speech engine installed on the phone; this cannot reproduce ChatGPT's Maple voice.
            tts.setSpeechRate(0.94f)
            tts.setPitch(1.06f)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { runOnUiThread { onSpeechFinished() } }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { runOnUiThread { onSpeechFinished() } }
                override fun onError(utteranceId: String?, errorCode: Int) { runOnUiThread { onSpeechFinished() } }
            })
            pendingSpeech?.let { queued ->
                pendingSpeech = null
                speak(queued)
            }
        }
    }

    /**
     * Prefer OpenAI's neural speech output for a much more natural voice.
     * Android TextToSpeech remains the offline/failure fallback. This uses the
     * same API key already configured for text and image requests.
     */
    private fun speak(message: String, resumeAfter: Boolean = false) {
        if (message.isBlank()) return
        val generation = ++speechGeneration
        resumeAfterSpeech = resumeAfter
        val key = prefs.getString("api_key", "").orEmpty().trim()
        if (key.isBlank()) {
            speakWithAndroidTts(message)
            return
        }
        executor.execute {
            var audioFile: File? = null
            try {
                val conn = (URL("https://api.openai.com/v1/audio/speech").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 60000
                conn.doOutput = true
                conn.setRequestProperty("Authorization", "Bearer $key")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Accept", "audio/mpeg")
                val selectedVoice = prefs.getString("tts_voice", "marin").orEmpty().ifBlank { "marin" }
                val request = JSONObject()
                    .put("model", "gpt-4o-mini-tts")
                    .put("voice", selectedVoice)
                    .put("input", message.take(4000))
                    .put("instructions", "Speak in Russian with natural pronunciation, rhythm, and gentle pauses. Sound like a conversational assistant, not a robot or announcer. Follow the selected conversational manner: ${styleInstructions()}. Do not add words that are not in the input.")
                conn.outputStream.use { it.write(request.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                if (code !in 200..299) {
                    val error = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    throw Exception("OpenAI speech HTTP $code: ${error.take(300)}")
                }
                val createdFile = File.createTempFile("stereoo_voice_", ".mp3", cacheDir)
                audioFile = createdFile
                conn.inputStream.use { input -> FileOutputStream(createdFile).use { output -> input.copyTo(output) } }
                conn.disconnect()
                if (generation != speechGeneration || isFinishing || isDestroyed) {
                    createdFile.delete()
                    return@execute
                }
                runOnUiThread { playNeuralAudio(createdFile, generation, message) }
            } catch (e: Exception) {
                audioFile?.delete()
                DiagnosticsTree.event(this, "AUDIO", "openai_tts_failed", "${e.javaClass.simpleName}: ${e.message?.take(250)}; falling back to Android TTS")
                runOnUiThread {
                    if (generation == speechGeneration && !isFinishing && !isDestroyed) speakWithAndroidTts(message)
                }
            }
        }
    }

    private fun playNeuralAudio(file: File, generation: Int, originalText: String) {
        if (generation != speechGeneration || isFinishing || isDestroyed) {
            file.delete()
            return
        }
        releaseSpeechPlayer()
        try {
            speechFile = file
            speechPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener { player ->
                    if (generation != speechGeneration || isFinishing || isDestroyed) {
                        player.release()
                        file.delete()
                        return@setOnPreparedListener
                    }
                    DiagnosticsTree.event(this@StereooAssistantActivity, "AUDIO", "openai_tts_started", "voice=${prefs.getString("tts_voice", "marin")} bytes=${file.length()} textLength=${originalText.length}")
                    player.start()
                }
                setOnCompletionListener { player ->
                    player.release()
                    if (speechPlayer === player) speechPlayer = null
                    file.delete()
                    if (speechFile == file) speechFile = null
                    DiagnosticsTree.event(this@StereooAssistantActivity, "AUDIO", "answer_tts_done", "engine=openai voice=${prefs.getString("tts_voice", "marin")}")
                    if (generation == speechGeneration) onSpeechFinished()
                }
                setOnErrorListener { player, what, extra ->
                    player.release()
                    if (speechPlayer === player) speechPlayer = null
                    file.delete()
                    if (speechFile == file) speechFile = null
                    DiagnosticsTree.event(this@StereooAssistantActivity, "AUDIO", "openai_tts_playback_failed", "what=$what extra=$extra")
                    if (generation == speechGeneration) speakWithAndroidTts(originalText)
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            releaseSpeechPlayer()
            file.delete()
            DiagnosticsTree.event(this, "AUDIO", "openai_tts_prepare_failed", "${e.javaClass.simpleName}: ${e.message}")
            speakWithAndroidTts(originalText)
        }
    }

    private fun speakWithAndroidTts(message: String) {
        if (!ttsReady) {
            pendingSpeech = message
            return
        }
        tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "stereoo-${System.currentTimeMillis()}")
    }

    private fun releaseSpeechPlayer() {
        try { speechPlayer?.stop() } catch (_: Exception) {}
        try { speechPlayer?.release() } catch (_: Exception) {}
        speechPlayer = null
        speechFile?.delete()
        speechFile = null
    }
    private fun isSpeakingNow(): Boolean = (speechPlayer?.isPlaying == true) || tts.isSpeaking

    private fun stopCurrentSpeech() {
        speechGeneration++
        resumeAfterSpeech = false
        try { speechPlayer?.stop() } catch (_: Exception) {}
        releaseSpeechPlayer()
        try { tts.stop() } catch (_: Exception) {}
        DiagnosticsTree.event(this, "AUDIO", "speech_interrupted", "source=glasses_button")
    }

    private fun endConversation(reason: String) {
        conversationActive = false
        stopCurrentSpeech()
        recognitionInProgress = false
        resumeAfterSpeech = false
        // Ending this conversation must not change the user's continuous-dialogue setting.
        status.text = "Голосовой разговор завершён. Настройка непрерывного диалога сохранена. Нажми кнопку очков, чтобы начать снова."
        DiagnosticsTree.event(this, "VOICE", "conversation_ended", "reason=$reason continuousPreference=${prefs.getBoolean("continuous_dialogue", true)}")
    }

    private fun isStopCommand(text: String): Boolean {
        val q = text.lowercase(Locale.ROOT).replace('ё', 'е').trim().trim('.', '!', '?', ',', ' ')
        return q in setOf("хватит", "стоп", "отбой", "закончить разговор", "заверши разговор", "замолчи", "достаточно")
    }

    private fun playListeningCue() {
        try {
            if (toneGenerator == null) toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 160)
            DiagnosticsTree.event(this, "AUDIO", "listening_cue", "type=ack")
        } catch (e: Exception) {
            DiagnosticsTree.event(this, "AUDIO", "listening_cue_failed", e.message.orEmpty())
        }
    }

    private fun listen() {
        if (recognitionInProgress || isFinishing || isDestroyed || !conversationActive) return
        recognitionInProgress = true
        playListeningCue()
        DiagnosticsTree.event(this, "VOICE", "recognition_started", "locale=ru-RU continuous=${prefs.getBoolean("continuous_dialogue", true)}")
        status.text = "Слушаю. Говори после появления окна распознавания."
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говори, я слушаю")
        }
        try { startActivityForResult(intent, 11) }
        catch (e: Exception) { recognitionInProgress = false; DiagnosticsTree.event(this, "VOICE", "recognition_launch_failed", "${e.javaClass.simpleName}: ${e.message}"); status.text = "На телефоне не найден сервис распознавания речи: ${e.message}" }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 11) {
            recognitionInProgress = false
            if (resultCode != RESULT_OK || data == null) {
                DiagnosticsTree.event(this, "VOICE", "recognition_no_result", "resultCode=$resultCode dataNull=${data == null}")
                status.text = if (prefs.getBoolean("continuous_dialogue", true)) {
                    "Не удалось услышать фразу. Скажи её ещё раз или нажми «ГОВОРИТЬ»."
                } else {
                    "Распознавание завершено. Нажми «ГОВОРИТЬ», чтобы задать следующий вопрос."
                }
                // Keep the chat-like session alive through ordinary pauses, without
                // speaking an error that could create a feedback loop in the glasses.
                if (conversationActive && prefs.getBoolean("continuous_dialogue", true) && !isFinishing && !isDestroyed) {
                    window.decorView.postDelayed({ if (!recognitionInProgress && conversationActive) listen() }, 500)
                }
                return
            }
            val words = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val recognized = words?.firstOrNull()?.trim().orEmpty()
            if (recognized.isNotBlank()) {
                DiagnosticsTree.event(this, "VOICE", "recognized_text", "length=${recognized.length}")
                if (isStopCommand(recognized)) {
                    endConversation("voice_command:${recognized.take(40)}")
                    return
                }
                input.setText(recognized)
                status.text = "Распознано: $recognized\nОбрабатываю вопрос…"
                if (isVisualQuestion(recognized)) {
                    DiagnosticsTree.event(this, "VOICE", "visual_question_detected", "textLength=${recognized.length}")
                    status.text = "Запрашиваю свежую фотографию с очков…"
                    val route = Intent(this, com.fersaiyan.cyanbridge.MainActivity::class.java).apply {
                        action = ACTION_START_VOICE_IMAGE_QUESTION
                        putExtra(EXTRA_VOICE_IMAGE_QUESTION, recognized)
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                    startActivity(route)
                } else sendText(recognized)
            } else {
                status.text = "Речь не распознана. Попробуй ещё раз или нажми «ГОВОРИТЬ»."
                // Silent failure is intentional; spoken errors were restarting the
                // conversation with another TTS utterance immediately after listening.
            }
        } else if (requestCode == 22) {
            if (resultCode != RESULT_OK || data == null) {
                DiagnosticsTree.event(this, "PHOTO", "picker_cancelled", "resultCode=$resultCode dataNull=${data == null}")
                status.text = "Выбор фотографии отменён."
                return
            }
            val uri = data.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream) ?: throw Exception("Не удалось прочитать изображение")
                    sendImage(bitmap)
                }
            } catch (e: Exception) { status.text = "Ошибка фото: ${e.message}" }
        }
    }
    private fun onSpeechFinished() {
        if (!resumeAfterSpeech) return
        resumeAfterSpeech = false
        if (conversationActive && prefs.getBoolean("continuous_dialogue", true) && !isFinishing && !isDestroyed) {
            window.decorView.postDelayed({ if (!recognitionInProgress && conversationActive && !isFinishing && !isDestroyed) listen() }, 450)
        }
    }

    private fun isVisualQuestion(text: String): Boolean {
        val q = text.lowercase(Locale.ROOT).replace('ё', 'е').trim()
        val phrases = listOf(
            "что передо мной", "что передо мной сейчас", "что я вижу", "на что я смотрю",
            "что находится передо мной", "опиши что передо мной", "опиши, что передо мной",
            "посмотри передо мной", "что у меня перед глазами", "что изображено передо мной",
            "что это за предмет", "что за предмет передо мной", "эй стерео что я вижу",
            "эй стерео что передо мной", "эй стерео на что я смотрю"
        )
        return phrases.any { q.contains(it) }
    }

    private fun exportDiagnostics() {
        DiagnosticsTree.event(this, "DIAGNOSTICS", "export_requested")
        val text = DiagnosticsTree.exportText(this)
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Stereoo AI diagnostic log")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(share, "Отправить журнал ошибок"))
    }

    private fun keyDialog() {
        val field = EditText(this).apply {
            hint = "sk-..."
            setText(prefs.getString("api_key", ""))
            inputType = 129
        }
        AlertDialog.Builder(this).setTitle("API-ключ OpenAI")
            .setMessage("Ключ хранится только в данных этого приложения на телефоне. Не публикуй его в GitHub.")
            .setView(field)
            .setPositiveButton("Сохранить") { _, _ ->
                prefs.edit().putString("api_key", field.text.toString().trim()).apply()
                status.text = "API-ключ сохранён на устройстве."
            }.setNegativeButton("Отмена", null).show()
    }
    private fun sendText(text: String) {
        if (text.isBlank()) { status.text = "Сначала введи вопрос или нажми «Говорить»."; speak("Сначала задай вопрос"); return }
        val body = JSONObject().put("model", "gpt-4.1-mini")
            .put("input", "${conversationInstructions()}\n\nВопрос пользователя: $text")
        callApi(body)
    }

    private fun conversationInstructions(): String {
        val length = prefs.getString("answer_length", "normal") ?: "normal"
        val lengthRule = when (length) {
            "short" -> "Отвечай кратко: обычно 1–3 предложения, только главное."
            "detailed" -> "Отвечай подробно, объясняй ход рассуждения понятными словами и приводи полезные детали."
            else -> "Отвечай естественно и по существу, обычно 2–5 предложений."
        }
        return "${styleInstructions()} $lengthRule Отвечай на русском, если пользователь не попросил другой язык."
    }

    private fun styleInstructions(): String = when (prefs.getString("conversation_style", "friendly")) {
        "expert" -> "Стиль: экспертный, точный, спокойный, без лишних шуток и канцелярита."
        "casual" -> "Стиль: неформальный и естественный, как в разговоре с хорошим знакомым."
        "humor" -> "Стиль: дружелюбный, с уместным лёгким юмором; не шути на чувствительные темы."
        "business" -> "Стиль: деловой, чёткий, структурированный, без лишних отступлений."
        "caring" -> "Стиль: заботливый, терпеливый и внимательный, особенно в сложных ситуациях."
        else -> "Стиль: дружелюбный, тёплый и естественный."
    }

    private fun preferencesDialog() {
        val options = arrayOf(
            "🎙 Голос помощника: ${voiceLabel(prefs.getString("tts_voice", "marin") ?: "marin")}",
            "🎭 Стиль общения: ${styleLabel(prefs.getString("conversation_style", "friendly") ?: "friendly")}",
            "💬 Длина ответов: ${lengthLabel(prefs.getString("answer_length", "normal") ?: "normal")}",
            "🔊 Озвучивать ответы: ${if (prefs.getBoolean("speak_answers", true)) "включено" else "выключено"}",
            "▶ Прослушать выбранный голос"
        )
        AlertDialog.Builder(this).setTitle("Голос и общение")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> chooseVoice()
                    1 -> chooseStyle()
                    2 -> chooseAnswerLength()
                    3 -> {
                        val enabled = !prefs.getBoolean("speak_answers", true)
                        prefs.edit().putBoolean("speak_answers", enabled).apply()
                        status.text = if (enabled) "Озвучивание ответов включено" else "Озвучивание ответов выключено"
                        preferencesDialog()
                    }
                    4 -> speak("Привет! Я Stereoo AI. Это пример выбранного голоса. Чем могу помочь?")
                }
            }.setNegativeButton("Закрыть", null).show()
    }

    private fun chooseVoice() {
        // These are voices supported by the OpenAI Speech API family; Maple is not exposed there.
        val voices = arrayOf("alloy", "ash", "ballad", "cedar", "coral", "echo", "fable", "marin", "nova", "onyx", "sage", "shimmer", "verse")
        val labels = voices.map { voiceLabel(it) }.toTypedArray()
        val current = prefs.getString("tts_voice", "marin") ?: "marin"
        val selected = voices.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Голос помощника")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                prefs.edit().putString("tts_voice", voices[which]).apply()
                dialog.dismiss()
                status.text = "Выбран голос: ${labels[which]}. Нажми «Повторить ответ», чтобы проверить звучание."
                preferencesDialog()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun chooseStyle() {
        val ids = arrayOf("friendly", "expert", "casual", "humor", "business", "caring")
        val labels = arrayOf("Дружелюбный", "Эксперт", "Неформальный", "С юмором", "Деловой", "Заботливый")
        val selected = ids.indexOf(prefs.getString("conversation_style", "friendly")).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Стиль общения")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                prefs.edit().putString("conversation_style", ids[which]).apply()
                dialog.dismiss(); status.text = "Стиль общения: ${labels[which]}"; preferencesDialog()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun chooseAnswerLength() {
        val ids = arrayOf("short", "normal", "detailed")
        val labels = arrayOf("Кратко", "Обычно", "Подробно")
        val selected = ids.indexOf(prefs.getString("answer_length", "normal")).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Длина ответов")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                prefs.edit().putString("answer_length", ids[which]).apply()
                dialog.dismiss(); status.text = "Длина ответов: ${labels[which]}"; preferencesDialog()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun voiceLabel(id: String) = when (id) {
        "alloy" -> "Alloy · нейтральный"; "ash" -> "Ash · сдержанный"; "ballad" -> "Ballad · мягкий"
        "cedar" -> "Cedar · уверенный"; "coral" -> "Coral · дружелюбный"; "echo" -> "Echo · низкий тембр"
        "fable" -> "Fable · выразительный"; "marin" -> "Marin · естественный"; "nova" -> "Nova · энергичный"
        "onyx" -> "Onyx · насыщенный"; "sage" -> "Sage · спокойный"; "shimmer" -> "Shimmer · лёгкий"
        "verse" -> "Verse · артистичный"; else -> id
    }
    private fun styleLabel(id: String) = when (id) {
        "expert" -> "Эксперт"; "casual" -> "Неформальный"; "humor" -> "С юмором"; "business" -> "Деловой"; "caring" -> "Заботливый"; else -> "Дружелюбный"
    }
    private fun lengthLabel(id: String) = when (id) { "short" -> "Кратко"; "detailed" -> "Подробно"; else -> "Обычно" }

    private fun sendImage(
        bitmap: Bitmap,
        question: String = "Опиши фотографию по-русски."
    ) {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) {
            status.text = "Не найден API-ключ OpenAI. Нажми «Настроить API-ключ»."
            speak("Не найден ключ OpenAI. Открой настройку API ключа")
            keyDialog(); return
        }
        DiagnosticsTree.event(this, "PHOTO", "sending_to_api", "width=${bitmap.width} height=${bitmap.height} questionLength=${question.length}")
        status.text = "Отправляю фотографию на анализ…"
        val scaled = if (bitmap.width > 1200 || bitmap.height > 1200) {
            val ratio = minOf(1200f / bitmap.width, 1200f / bitmap.height)
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
        } else bitmap
        val bytes = ByteArrayOutputStream().also { scaled.compress(Bitmap.CompressFormat.JPEG, 82, it) }.toByteArray()
        val dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        val imagePrompt = "$question\n\n${styleInstructions()} ${lengthLabel(prefs.getString("answer_length", "normal") ?: "normal")}\nОтветь строго в двух разделах и не добавляй вступление.\nКРАТКО: ровно 2 предложения, максимум 35 слов суммарно. Это самостоятельный естественный ответ для озвучивания: назови главные объекты и самое важное действие/обстановку. Не включай просьбы и длинные оговорки.\nПОДРОБНО: полный полезный анализ изображения для показа на экране, с расположением предметов, читаемыми надписями и важными деталями. Не выдумывай того, чего нельзя уверенно увидеть."
        val content = JSONArray()
            .put(JSONObject().put("type", "input_text").put("text", imagePrompt))
            .put(JSONObject().put("type", "input_image").put("image_url", dataUrl))
        callApi(JSONObject().put("model", "gpt-4.1-mini")
            .put("input", JSONArray().put(JSONObject().put("role", "user").put("content", content))), isImage = true)
    }
    private fun callApi(body: JSONObject, isImage: Boolean = false) {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) {
            status.text = "Не найден API-ключ OpenAI. Нажми «Настроить API-ключ»."
            speak("Не найден ключ OpenAI. Открой настройку API ключа")
            keyDialog(); return
        }
        DiagnosticsTree.event(this, "API", "request_started", "model=${body.optString("model")} inputType=${if (body.optJSONArray("input") != null) "messages_or_parts" else "text"}")
        status.text = "Запрос отправлен в OpenAI. Жду ответ…"
        executor.execute {
            try {
                val conn = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 60000
                conn.doOutput = true
                conn.setRequestProperty("Authorization", "Bearer $key")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                DiagnosticsTree.event(this, "API", "http_response", "code=${conn.responseCode}")
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) throw Exception(JSONObject(response).optJSONObject("error")?.optString("message") ?: response)
                val json = JSONObject(response)
                // Responses API may expose a convenient top-level output_text in addition
                // to the text parts nested inside output[].
                val result = StringBuilder()
                val topLevelText = json.optString("output_text", "")
                if (topLevelText.isNotBlank()) result.append(topLevelText)
                val output = if (topLevelText.isBlank()) json.optJSONArray("output") ?: JSONArray() else JSONArray()
                for (i in 0 until output.length()) {
                    val item = output.optJSONObject(i) ?: continue
                    val content = item.optJSONArray("content") ?: continue
                    for (j in 0 until content.length()) {
                        val part = content.optJSONObject(j) ?: continue
                        if (part.optString("type") == "output_text") result.append(part.optString("text"))
                    }
                }
                val answer = result.toString().trim().ifBlank {
                    val responseStatus = json.optString("status", "неизвестен")
                    val incomplete = json.optJSONObject("incomplete_details")?.optString("reason")
                    "OpenAI не вернул текстовый ответ (статус: $responseStatus${incomplete?.let { ", причина: $it"}.orEmpty()})."
                }
                DiagnosticsTree.event(this, "API", "answer_received", "status=${json.optString("status", "unknown")} answerLength=${answer.length}")
                runOnUiThread {
                    if (isImage) {
                        val short = Regex("(?is)КРАТКО\\s*:\\s*(.*?)(?=ПОДРОБНО\\s*:|$)").find(answer)?.groupValues?.get(1)?.trim()
                        val detailed = Regex("(?is)ПОДРОБНО\\s*:\\s*(.*)$").find(answer)?.groupValues?.get(1)?.trim()
                        val visible = if (!detailed.isNullOrBlank()) detailed else answer.removePrefix(short.orEmpty()).trim().ifBlank { answer }
                        val spoken = if (!short.isNullOrBlank()) {
                            short.split(Regex("(?<=[.!?])\\s+")).take(3).joinToString(" ").take(420)
                        } else {
                            answer.split(Regex("(?<=[.!?])\\s+")).take(2).joinToString(" ").take(300)
                        }
                        status.text = visible
                        lastAnswer = spoken
                        if (prefs.getBoolean("speak_answers", true)) speak(spoken, resumeAfter = true)
                        else { resumeAfterSpeech = true; onSpeechFinished() }
                    } else {
                        lastAnswer = answer
                        status.text = answer
                        if (prefs.getBoolean("speak_answers", true)) speak(answer, resumeAfter = true)
                        else { resumeAfterSpeech = true; onSpeechFinished() }
                    }
                }
                conn.disconnect()
            } catch (e: Exception) {
                val message = e.message ?: "не удалось связаться с API"
                DiagnosticsTree.event(this, "API", "request_failed", "${e.javaClass.simpleName}: $message")
                android.util.Log.e("StereooAssistant", "OpenAI request failed", e)
                runOnUiThread {
                    status.text = "Ошибка OpenAI: $message"
                    speak("Ошибка OpenAI. $message")
                }
            }
        }
    }
    override fun onDestroy() {
        speechGeneration++
        releaseSpeechPlayer()
        tts.stop(); tts.shutdown(); executor.shutdownNow()
        super.onDestroy()
    }
}
