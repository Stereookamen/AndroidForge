package com.fersaiyan.cyanbridge.stereoo

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local, bounded diagnostic trail for glasses commands and assistant routing. Never logs API keys or image bytes. */
object DiagnosticsTree {
    private const val TAG = "StereooDiagnostics"
    private const val FILE_NAME = "stereoo_diagnostics.log"
    private const val MAX_BYTES = 1_500_000L
    private val lock = Any()

    fun event(context: Context, area: String, event: String, details: String = "") {
        val safe = details.replace('\n', ' ').replace('\r', ' ').take(700)
        val line = "${SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(Date())} | $area | $event" +
            if (safe.isNotBlank()) " | $safe" else ""
        Log.i(TAG, line)
        synchronized(lock) {
            try {
                val file = File(context.filesDir, FILE_NAME)
                if (file.exists() && file.length() > MAX_BYTES) {
                    val old = file.readLines().takeLast(2500)
                    file.writeText(old.joinToString("\n", postfix = "\n"))
                }
                file.appendText(line + "\n")
            } catch (e: Exception) {
                Log.e(TAG, "Could not write diagnostic log", e)
            }
        }
    }

    fun exportText(context: Context): String = synchronized(lock) {
        val file = File(context.filesDir, FILE_NAME)
        if (file.exists()) file.readText() else "Журнал пока пуст.\n"
    }

    fun clear(context: Context) = synchronized(lock) {
        File(context.filesDir, FILE_NAME).writeText("")
    }
}
