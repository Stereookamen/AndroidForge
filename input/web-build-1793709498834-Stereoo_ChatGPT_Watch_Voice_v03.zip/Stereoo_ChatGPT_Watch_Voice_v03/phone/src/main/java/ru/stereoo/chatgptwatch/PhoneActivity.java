package ru.stereoo.chatgptwatch;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Phone-side bridge: no OpenAI API, credentials or audio recording. */
public class PhoneActivity extends Activity {
    private TextView info;
    private TextView accessStatus;
    private TextView attemptStatus;
    private TextView debugStatus;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        drawUi();
        if (isRequestFromWatch(getIntent())) openChatGpt(false);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (isRequestFromWatch(intent)) openChatGpt(false);
    }

    @Override protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private boolean isRequestFromWatch(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        return intent != null && Intent.ACTION_VIEW.equals(intent.getAction())
            && uri != null && "stereoo".equals(uri.getScheme())
            && "chatgpt".equals(uri.getHost()) && "/open".equals(uri.getPath());
    }

    /** @param training When true, record a manual tap on Voice instead of clicking automatically. */
    private void openChatGpt(boolean training) {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
            if (intent == null) {
                info.setText("ChatGPT не найден. Установи официальное приложение и войди в аккаунт.");
                return;
            }
            if (!isAccessibilityEnabled()) {
                VoiceAccessibilityService.clear(this);
                info.setText("Служба Stereoo выключена. Включи её в специальных возможностях телефона.");
            } else if (training) {
                VoiceAccessibilityService.learn(this);
                info.setText("Нажми кнопку голосового разговора в ChatGPT ВРУЧНУЮ, затем вернись сюда.");
            } else {
                VoiceAccessibilityService.arm(this);
                info.setText("Открываю ChatGPT и ищу Voice. Вернись сюда, если голос не запустится, чтобы увидеть диагностику.");
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException ex) {
            VoiceAccessibilityService.clear(this);
            info.setText("Не получилось открыть ChatGPT: " + ex.getMessage());
        }
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager manager = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        if (manager == null) return false;
        String id = new ComponentName(this, VoiceAccessibilityService.class).flattenToString();
        for (AccessibilityServiceInfo service : manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
            if (id.equals(service.getId())) return true;
        }
        return false;
    }

    private void updateStatus() {
        if (accessStatus == null) return;
        accessStatus.setText(isAccessibilityEnabled()
                ? "Спецвозможности: включены ✅"
                : "Спецвозможности: ВЫКЛЮЧЕНЫ ⛔");
        attemptStatus.setText("Последняя попытка:\n" + VoiceAccessibilityService.lastStatus(this));
        debugStatus.setText("Диагностика:\n" + VoiceAccessibilityService.lastDebug(this)
                + "\nОбученное нажатие: "
                + (VoiceAccessibilityService.calibrated(this) ? "есть ✅" : "нет"));
    }

    private void drawUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xff0a0e18);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setPadding(dp(22), dp(32), dp(22), dp(30));
        scroll.addView(layout);
        layout.addView(label("Stereoo ChatGPT Bridge 0.3", 23, 0xffe4ebff, true));
        layout.addView(label("TicWatch Pro 3 → телефон → ChatGPT Voice", 13, 0xff9cacc9, false));
        info = label("Улучшенный поиск кнопки Voice и обучение по нажатию.", 15, 0xffdce3f4, false);
        layout.addView(info);
        accessStatus = label("Проверяю доступ…", 16, 0xffb5ebc0, true);
        layout.addView(accessStatus);

        Button permissions = makeButton("1. ПРОВЕРИТЬ СПЕЦВОЗМОЖНОСТИ", 0xff35659c);
        permissions.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            catch (Exception e) { info.setText("Не удалось открыть настройки специальных возможностей."); }
        });
        addButton(layout, permissions);

        Button test = makeButton("2. ПРОВЕРИТЬ CHATGPT + VOICE", 0xff444edb);
        test.setOnClickListener(v -> openChatGpt(false));
        addButton(layout, test);

        Button learn = makeButton("3. ОБУЧИТЬ КНОПКУ VOICE", 0xff33856b);
        learn.setOnClickListener(v -> {
            if (!isAccessibilityEnabled()) {
                info.setText("Сначала включи службу Stereoo в специальных возможностях!");
                return;
            }
            openChatGpt(true);
        });
        addButton(layout, learn);
        layout.addView(label("Обучение: ChatGPT откроется. Один раз нажми Voice ВРУЧНУЮ, дождись начала разговора, вернись в Bridge. Затем запусти с часов.", 12, 0xff9eacc6, false));

        attemptStatus = label("", 14, 0xffe4ebff, true);
        addWithMargin(layout, attemptStatus, 14);
        debugStatus = label("", 13, 0xffafbcd3, false);
        addWithMargin(layout, debugStatus, 5);

        Button refresh = makeButton("ОБНОВИТЬ ДИАГНОСТИКУ", 0xff354a68);
        refresh.setOnClickListener(v -> updateStatus());
        addButton(layout, refresh);

        Button copy = makeButton("СКОПИРОВАТЬ ДИАГНОСТИКУ", 0xff354a68);
        copy.setOnClickListener(v -> {
            String report = "Stereoo v0.3\n" + accessStatus.getText() + "\n" + attemptStatus.getText()
                    + "\n" + debugStatus.getText();
            ClipboardManager clip = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clip != null) {
                clip.setPrimaryClip(ClipData.newPlainText("Stereoo debug", report));
                Toast.makeText(this, "Диагностика скопирована", Toast.LENGTH_SHORT).show();
            }
        });
        addButton(layout, copy);

        Button reset = makeButton("СБРОСИТЬ ОБУЧЕНИЕ", 0xff674957);
        reset.setOnClickListener(v -> { VoiceAccessibilityService.forgetCalibration(this); updateStatus(); });
        addButton(layout, reset);

        TextView foot = label("Работает только с ChatGPT; не использует OpenAI API. Голос идёт через смартфон."
                + " Для проверки разблокируй экран и один раз запусти Voice вручную."
                + " Если кнопка сместилась после обновления ChatGPT, сбрось обучение.\n\n"
                + "Разработчик: Жданов Александр", 12, 0xff8491aa, false);
        addWithMargin(layout, foot, 14);
        setContentView(scroll);
        updateStatus();
    }

    private Button makeButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        return b;
    }

    private void addButton(LinearLayout layout, Button button) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(49));
        p.topMargin = dp(13);
        layout.addView(button, p);
    }
    private void addWithMargin(LinearLayout layout, TextView view, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(margin);
        layout.addView(view, p);
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(6), 0, dp(6));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }
}
