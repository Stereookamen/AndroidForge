package ru.stereoo.zontwatch;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native, round-screen-friendly Wear OS 2 app. No phone companion needed. */
public final class MainActivity extends Activity {
    private static final int WHITE = Color.rgb(243, 249, 249);
    private static final int MUTED = Color.rgb(158, 180, 181);
    private static final int GREEN = Color.rgb(88, 222, 185);
    private static final int ORANGE = Color.rgb(255, 178, 81);
    private static final int RED = Color.rgb(255, 127, 135);
    private static final int BACKGROUND = Color.rgb(7, 16, 21);
    private static final int CARD = Color.rgb(24, 38, 44);

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ZontApi api = new ZontApi();
    private SecureStore store;
    private LinearLayout root;
    private TextView notice;
    private boolean busy;
    private JSONArray availableDevices;
    private JSONObject currentDevice;
    private ZontApi.Voltage currentVoltage;
    private long lastRefreshAt;
    private final Runnable refreshAfterCommand = this::refresh;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(BACKGROUND);
        store = new SecureStore(this);
        if (store.getToken().isEmpty()) showLogin();
        else { showDashboard(); refresh(); }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + .5f);
    }

    private void makePage() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        scroll.setVerticalScrollBarEnabled(false);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(32), dp(22), dp(36));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);
        heading("ZONT", 25, GREEN);
        heading("Stereoo Watch", 12, MUTED);
        space(13);
    }

    private TextView heading(String text, int size, int color) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(size);
        label.setTextColor(color);
        label.setGravity(Gravity.CENTER);
        if (size >= 20) label.setTypeface(null, Typeface.BOLD);
        label.setPadding(dp(2), dp(2), dp(2), dp(5));
        root.addView(label, new LinearLayout.LayoutParams(-1, -2));
        return label;
    }

    private void space(int amount) {
        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, dp(amount)));
    }

    private Button button(String text, int accent, View.OnClickListener onClick) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(13.5f);
        button.setTextColor(WHITE);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(51));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(28));
        bg.setStroke(dp(1), accent);
        button.setBackground(bg);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(51));
        params.setMargins(dp(4), dp(3), dp(4), dp(4));
        root.addView(button, params);
        button.setOnClickListener(v -> {
            if (!busy && onClick != null) onClick.onClick(v);
        });
        return button;
    }

    private EditText input(String hint, int type) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setTextColor(WHITE);
        edit.setHintTextColor(MUTED);
        edit.setHint(hint);
        edit.setTextSize(14);
        edit.setInputType(type);
        edit.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(55));
        params.setMargins(dp(4), dp(3), dp(4), dp(3));
        root.addView(edit, params);
        return edit;
    }

    private void message(String text, int color) {
        if (notice != null) {
            notice.setText(text);
            notice.setTextColor(color);
        }
    }

    private void createMessage() {
        notice = heading("", 12, MUTED);
    }

    private void showLogin() {
        makePage();
        currentDevice = null;
        currentVoltage = null;
        heading("Вход в ZONT", 16, WHITE);
        heading("Пароль не сохраняется", 11, MUTED);
        EditText login = input("Логин ZONT", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        login.setText(store.getContact());
        EditText password = input("Пароль ZONT", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        button("Войти", GREEN, v -> {
            String user = login.getText().toString().trim();
            String pass = password.getText().toString();
            if (user.isEmpty() || pass.isEmpty()) {
                message("Введите логин и пароль", RED);
                return;
            }
            password.setText("");
            work("Входим в ZONT…", () -> api.authenticate(user, pass), token -> {
                try { store.putCredentials(user, token); }
                catch (Exception e) {
                    message("Ошибка защищённого хранилища", RED);
                    return;
                }
                showDashboard();
                refresh();
            });
        });
        createMessage();
        space(5);
        heading("Нужен интернет на часах", 11, MUTED);
    }

    private void showDashboard() {
        makePage();
        if (currentDevice == null) {
            heading("Получаем данные…", 13, MUTED);
        } else {
            String model = currentDevice.optString("devtype", "");
            String name = currentDevice.optString("name", "Автомобиль");
            heading(name, 16, WHITE);
            if (!model.isEmpty()) heading(model, 11, MUTED);
            space(5);
            JSONObject io = currentDevice.optJSONObject("io");
            if (io == null) io = new JSONObject();
            String guard = io.optString("guard-state", "");
            String guardText = "enabled".equals(guard) ? "ВКЛЮЧЕНА" :
                "disabled".equals(guard) ? "ВЫКЛЮЧЕНА" :
                "enabling".equals(guard) ? "ВКЛЮЧАЕТСЯ" : "НЕТ ДАННЫХ";
            heading("Охрана: " + guardText, 13, "enabled".equals(guard) ? GREEN : ORANGE);
            boolean engine = io.optBoolean("engine-state", false);
            heading("Двигатель: " + (!io.has("engine-state") ? "нет данных" :
                engine ? "работает" : "остановлен"), 13, engine ? GREEN : MUTED);
            JSONObject auto = io.optJSONObject("auto-ignition");
            String autoState = auto == null ? "" : auto.optString("state", "");
            String autoText = "enabled".equals(autoState) ? "активен" :
                "enabling".equals(autoState) ? "запускается" :
                "disabled".equals(autoState) ? "выключен" : "нет данных";
            heading("Автозапуск: " + autoText, 12, MUTED);
            String engineTemp = temperature(currentDevice, "engine");
            String cabinTemp = temperature(currentDevice, "cabin");
            if (engineTemp != null) heading("Мотор: " + engineTemp + " °C", 13, WHITE);
            if (cabinTemp != null) heading("Салон: " + cabinTemp + " °C", 13, WHITE);
            if (currentVoltage != null) {
                heading(String.format(Locale.getDefault(), "АКБ: %.1f В", currentVoltage.volts), 13, WHITE);
            }
            if (io.optBoolean("siren", false)) heading("⚠ ТРЕВОГА: сирена", 12, RED);
            if (lastRefreshAt > 0) {
                heading("Обновлено " + new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                    .format(new Date(lastRefreshAt)), 10, MUTED);
            }
        }

        space(4);
        button("↻ Обновить", GREEN, v -> refresh());
        if (currentDevice != null) {
            JSONObject io = currentDevice.optJSONObject("io");
            if (io == null) io = new JSONObject();
            boolean guardAvailable = io.has("guard-state");
            boolean autoAvailable = io.optJSONObject("auto-ignition") != null &&
                io.optJSONObject("auto-ignition").optBoolean("available", false);
            boolean engineRunning = io.optBoolean("engine-state", false);
            String autoState = io.optJSONObject("auto-ignition") == null ? "" :
                io.optJSONObject("auto-ignition").optString("state", "");
            button("🔒 Поставить на охрану", GREEN, v -> confirm(Command.ARM)).setEnabled(guardAvailable);
            button("🔓 Снять с охраны", ORANGE, v -> confirm(Command.DISARM)).setEnabled(guardAvailable);
            button("🚗 Запустить двигатель", GREEN, v -> confirm(Command.START))
                .setEnabled(autoAvailable && !engineRunning && "disabled".equals(autoState));
            button("■ Остановить автозапуск", RED, v -> confirm(Command.STOP))
                .setEnabled(autoAvailable && ("enabled".equals(autoState) || "enabling".equals(autoState)));
            if (!autoAvailable) heading("Автозапуск недоступен или не настроен", 11, MUTED);
        }
        space(5);
        button("Выбрать устройство", MUTED, v -> chooseDevice());
        button("Выйти из аккаунта", MUTED, v -> new AlertDialog.Builder(this)
            .setTitle("Выйти из ZONT?")
            .setMessage("Токен будет удалён с часов.")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Выйти", (dialog, which) -> {
                store.clear();
                availableDevices = null;
                showLogin();
            }).show());
        createMessage();
        heading("После команды проверьте состояние", 11, MUTED);
    }

    private static String temperature(JSONObject device, String assignment) {
        JSONObject config = device.optJSONObject("temperature_conf");
        JSONObject io = device.optJSONObject("io");
        if (config == null || io == null) return null;
        JSONArray names = config.optJSONArray("assignments");
        JSONArray readings = io.optJSONArray("temperature");
        if (names == null || readings == null) return null;
        for (int i = 0; i < Math.min(names.length(), readings.length()); i++) {
            if (!assignment.equals(names.optString(i))) continue;
            JSONObject sensor = readings.optJSONObject(i);
            if (sensor != null && "ok".equals(sensor.optString("state"))) {
                return String.valueOf(sensor.optInt("value"));
            }
        }
        return null;
    }

    private interface Task<T> { T perform() throws Exception; }
    private interface Done<T> { void complete(T value); }

    private <T> void work(String progress, Task<T> task, Done<T> done) {
        if (busy) return;
        busy = true;
        message(progress, ORANGE);
        executor.submit(() -> {
            try {
                T value = task.perform();
                ui.post(() -> {
                    busy = false;
                    if (!isFinishing() && !isDestroyed()) done.complete(value);
                });
            } catch (Exception error) {
                ui.post(() -> {
                    busy = false;
                    if (isFinishing() || isDestroyed()) return;
                    if (error instanceof ZontApi.ApiException &&
                        (((ZontApi.ApiException) error).httpCode == 403 ||
                         ((ZontApi.ApiException) error).httpCode == 401)) {
                        store.clear();
                        showLogin();
                        message("Доступ ZONT истёк. Войдите снова.", RED);
                    } else {
                        message("Ошибка: " + error.getMessage(), RED);
                    }
                });
            }
        });
    }

    private void refresh() {
        if (busy || store.getToken().isEmpty()) return;
        String token = store.getToken();
        String contact = store.getContact();
        work("Загружаем состояние…", () -> {
            JSONArray devices = api.devices(token, contact);
            long selectedId = store.getDeviceId();
            JSONObject selected = findDevice(devices, selectedId);
            if (selected == null && devices.length() == 1) selected = devices.optJSONObject(0);
            ZontApi.Voltage voltage = null;
            if (selected != null) {
                try { voltage = api.latestVoltage(token, contact, idOf(selected)); }
                catch (Exception ignored) { /* Voltage is optional, never block core controls. */ }
            }
            return new DeviceData(devices, selected, voltage);
        }, data -> {
            availableDevices = data.devices;
            if (data.devices.length() == 0) {
                currentDevice = null;
                showDashboard();
                message("В аккаунте ZONT нет устройств", RED);
                return;
            }
            if (data.selected == null) {
                currentDevice = null;
                showDashboard();
                chooseDevice();
                return;
            }
            currentDevice = data.selected;
            currentVoltage = data.voltage;
            store.setDeviceId(idOf(currentDevice));
            lastRefreshAt = System.currentTimeMillis();
            showDashboard();
        });
    }

    private static long idOf(JSONObject object) {
        if (object == null) return -1L;
        return object.has("id") ? object.optLong("id", -1L) : object.optLong("device_id", -1L);
    }

    private static JSONObject findDevice(JSONArray array, long id) {
        if (array == null || id <= 0) return null;
        for (int i = 0; i < array.length(); i++) {
            JSONObject obj = array.optJSONObject(i);
            if (idOf(obj) == id) return obj;
        }
        return null;
    }

    private static final class DeviceData {
        final JSONArray devices;
        final JSONObject selected;
        final ZontApi.Voltage voltage;
        DeviceData(JSONArray devices, JSONObject selected, ZontApi.Voltage voltage) {
            this.devices = devices; this.selected = selected; this.voltage = voltage;
        }
    }

    private void chooseDevice() {
        if (availableDevices == null || availableDevices.length() == 0) {
            message("Сначала загрузите устройства", ORANGE);
            return;
        }
        String[] titles = new String[availableDevices.length()];
        for (int i = 0; i < titles.length; i++) {
            JSONObject dev = availableDevices.optJSONObject(i);
            titles[i] = (dev == null ? "Устройство" : dev.optString("name", "Устройство")) +
                " (" + (dev == null ? "?" : dev.optString("devtype", "ZONT")) + ")";
        }
        new AlertDialog.Builder(this)
            .setTitle("Выберите машину")
            .setItems(titles, (dialog, index) -> {
                JSONObject device = availableDevices.optJSONObject(index);
                if (device != null) {
                    store.setDeviceId(idOf(device));
                    currentDevice = device;
                    currentVoltage = null;
                    lastRefreshAt = 0;
                    showDashboard();
                    refresh();
                }
            })
            .setNegativeButton("Отмена", null)
            .show();
    }

    private enum Command { ARM, DISARM, START, STOP }

    private void confirm(Command command) {
        if (currentDevice == null || store.getDeviceId() <= 0) return;
        if (System.currentTimeMillis() - lastRefreshAt > 120_000L) {
            message("Данные устарели. Сначала обновите.", ORANGE);
            return;
        }
        String title;
        String explanation;
        switch (command) {
            case ARM:
                title = "Включить охрану?";
                explanation = "Отправить команду постановки на охрану?";
                break;
            case DISARM:
                title = "Снять с охраны?";
                explanation = "Машина станет незащищённой. Подтвердить?";
                break;
            case START:
                title = "Завести двигатель?";
                explanation = "Только на открытом воздухе! Не запускайте машину в гараже. " +
                    "Убедитесь, что автомобиль безопасно подготовлен к автозапуску.";
                break;
            default:
                title = "Остановить автозапуск?";
                explanation = "Остановится только двигатель, запущенный системой автозапуска.";
        }
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(explanation)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Подтвердить", (dialog, which) -> execute(command))
            .show();
    }

    private void execute(Command command) {
        String token = store.getToken();
        String contact = store.getContact();
        long device = store.getDeviceId();
        work("Отправляем команду…", () -> {
            switch (command) {
                case ARM: api.setGuard(token, contact, device, true); break;
                case DISARM: api.setGuard(token, contact, device, false); break;
                case START: api.setAutoIgnition(token, contact, device, true); break;
                case STOP: api.setAutoIgnition(token, contact, device, false); break;
            }
            return true;
        }, ignored -> {
            message("Команда принята сервером. Проверяем выполнение…", GREEN);
            ui.removeCallbacks(refreshAfterCommand);
            ui.postDelayed(refreshAfterCommand, 3500L);
        });
    }

    @Override protected void onDestroy() {
        ui.removeCallbacks(refreshAfterCommand);
        executor.shutdownNow();
        super.onDestroy();
    }
}
