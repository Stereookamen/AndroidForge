package ru.stereoo.zontwatch;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.HttpsURLConnection;

/** Legacy ZONT API, as documented at https://zont-online.ru/api/docs/ */
final class ZontApi {
    private static final String ENDPOINT = "https://my.zont.online/api/";

    static final class ApiException extends IOException {
        final int httpCode;
        ApiException(String message, int httpCode) {
            super(message);
            this.httpCode = httpCode;
        }
    }

    String authenticate(String login, String password) throws Exception {
        String pair = login + ":" + password;
        String auth = "Basic " + Base64.encodeToString(
            pair.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        JSONObject body = new JSONObject().put("client_name", "Stereoo ZONT Watch");
        JSONObject result = post("get_authtoken", body, login, null, auth);
        String token = result.optString("token", "");
        if (token.isEmpty()) throw new ApiException("Сервер не выдал токен доступа", 0);
        return token;
    }

    JSONArray devices(String token, String contact) throws Exception {
        JSONObject request = new JSONObject().put("load_io", true);
        JSONObject response = post("devices", request, contact, token, null);
        JSONArray data = response.optJSONArray("devices");
        if (data == null) throw new ApiException("Список устройств не получен", 0);
        return data;
    }

    void setGuard(String token, String contact, long id, boolean enabled) throws Exception {
        JSONObject request = new JSONObject()
            .put("device_id", id)
            .put("portname", "guard-state")
            .put("type", "string")
            .put("value", enabled ? "enabled" : "disabled");
        post("set_io_port", request, contact, token, null);
    }

    void setAutoIgnition(String token, String contact, long id, boolean enabled) throws Exception {
        JSONObject request = new JSONObject()
            .put("device_id", id)
            .put("portname", "auto-ignition")
            .put("type", "auto-ignition")
            .put("value", new JSONObject().put("state", enabled ? "engine" : "disabled"));
        post("set_io_port", request, contact, token, null);
    }

    /** Returns latest voltage and its sample age. Missing or old data is not displayed. */
    Voltage latestVoltage(String token, String contact, long id) throws Exception {
        long now = System.currentTimeMillis() / 1000L;
        JSONObject item = new JSONObject()
            .put("device_id", id)
            .put("data_types", new JSONArray().put("ztc_state"))
            .put("mintime", now - 3600L)
            .put("maxtime", now);
        JSONObject request = new JSONObject().put("requests", new JSONArray().put(item));
        JSONObject result = post("load_data", request, contact, token, null);
        JSONArray responses = result.optJSONArray("responses");
        if (responses == null || responses.length() == 0) return null;
        JSONObject data = responses.optJSONObject(0);
        if (data == null || !data.optBoolean("ok", true)) return null;
        JSONObject state = data.optJSONObject("ztc_state");
        if (state == null) return null;
        JSONArray samples = state.optJSONArray("voltage");
        if (samples == null || samples.length() == 0) return null;
        long time = 0L;
        Double voltage = null;
        for (int i = 0; i < samples.length(); i++) {
            JSONArray sample = samples.optJSONArray(i);
            if (sample == null || sample.length() < 2) continue;
            long delta = sample.optLong(0);
            if (i == 0 || delta >= 0) time = delta;
            else time -= delta;  // ZONT Delta-time Array: negative interval is forward in time.
            if (!sample.isNull(1)) {
                double value = sample.optDouble(1, Double.NaN);
                if (!Double.isNaN(value)) voltage = value;
            }
        }
        if (voltage == null || time <= 0 || time > now + 60 || now - time > 600) return null;
        return new Voltage(voltage, now - time);
    }

    static final class Voltage {
        final double volts;
        final long sampleAgeSeconds;
        Voltage(double volts, long age) { this.volts = volts; this.sampleAgeSeconds = age; }
    }

    private JSONObject post(String method, JSONObject body, String contact,
                            String token, String basicAuth) throws Exception {
        URL url = new URL(ENDPOINT + method);
        HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(15000);
            conn.setInstanceFollowRedirects(false);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("X-ZONT-Client", contact);
            if (token != null) conn.setRequestProperty("X-ZONT-Token", token);
            if (basicAuth != null) conn.setRequestProperty("Authorization", basicAuth);
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = conn.getOutputStream()) { out.write(bytes); }

            int status = conn.getResponseCode();
            InputStream stream = status >= 200 && status < 300
                ? conn.getInputStream() : conn.getErrorStream();
            String raw = readUtf8(stream);
            JSONObject result;
            try { result = new JSONObject(raw); }
            catch (JSONException e) {
                throw new ApiException("Некорректный ответ ZONT (HTTP " + status + ")", status);
            }
            if (status < 200 || status >= 300 || !result.optBoolean("ok", false)) {
                Object message = result.opt("error_ui");
                String errorText = message == null ? result.optString("error", "Неизвестная ошибка") : message.toString();
                throw new ApiException("Ошибка ZONT: " + errorText + " (HTTP " + status + ")", status);
            }
            return result;
        } finally { conn.disconnect(); }
    }

    private static String readUtf8(InputStream stream) throws IOException {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (out.length() > 250_000) throw new IOException("Ответ ZONT слишком большой");
                out.append(line);
            }
        }
        return out.toString();
    }
}
