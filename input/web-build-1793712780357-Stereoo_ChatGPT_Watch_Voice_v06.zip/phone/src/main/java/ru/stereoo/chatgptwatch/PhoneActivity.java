package ru.stereoo.chatgptwatch;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.provider.Settings;
import android.view.Gravity;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Phone-side bridge: no OpenAI API, credentials or audio recording. */
public class PhoneActivity extends Activity {
    private TextView info;
    private TextView accessStatus;
    private TextView attemptStatus;
    private TextView debugStatus;
    private TextView audioStatus;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable periodicRefresh = new Runnable() {
        @Override public void run() {
            updateStatus();
            ui.postDelayed(this, 1500);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        drawUi();
        if (isRequestFromWatch(getIntent())) openChatGpt(false);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (isRequestFromWatch(intent)) openChatGpt(false);
    }

    @Override protected void onResume() {
        super.onResume();
        ui.removeCallbacks(periodicRefresh);
        periodicRefresh.run();
    }

    @Override protected void onPause() {
        ui.removeCallbacks(periodicRefresh);
        super.onPause();
    }

    private boolean isRequestFromWatch(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        return intent != null && Intent.ACTION_VIEW.equals(intent.getAction())
            && uri != null && "stereoo".equals(uri.getScheme())
            && "chatgpt".equals(uri.getHost()) && "/open".equals(uri.getPath());
    }

    /** @param training When true, record a manual tap on Voice instead of clicking automatically. */
    private void openChatGpt(boolean training) {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
            if (intent == null) {
                info.setText("ChatGPT не найден. Установи официальное приложение и войди в аккаунт.");
                return;
            }
            if (!isAccessibilityEnabled()) {
                VoiceAccessibilityService.clear(this);
                info.setText("Служба Stereoo выключена. Включи её в специальных возможностях телефона.");
            } else if (training) {
                VoiceAccessibilityService.learn(this);
                info.setText("Нажми кнопку голосового разговора в ChatGPT ВРУЧНУЮ, затем вернись сюда.");
            } else {
                VoiceAccessibilityService.arm(this);
                info.setText("Открываю ChatGPT и ищу Voice. Вернись сюда, если голос не запустится, чтобы увидеть диагностику.");
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException ex) {
            VoiceAccessibilityService.clear(this);
            info.setText("Не получилось открыть ChatGPT: " + ex.getMessage());
        }
    }

    // Check both the actual Android setting and the API list. Some OEM Android
    // builds may omit a service from getEnabledAccessibilityServiceList().
    // The user-visible switch alone does not prove the service has connected.
    private boolean inSecureSettings() {
        String raw = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(raw)) return false;
        ComponentName expected = new ComponentName(this, VoiceAccessibilityService.class);
        for (String entry : raw.split(":")) {
            ComponentName candidate = ComponentName.unflattenFromString(entry.trim());
            if (expected.equals(candidate)) return true;
        }
        return false;
    }

    private boolean inManagerList() {
        AccessibilityManager manager = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        if (manager == null) return false;
        ComponentName expected = new ComponentName(this, VoiceAccessibilityService.class);
        try {
            for (AccessibilityServiceInfo service : manager.getEnabledAccessibilityServiceList(
                    AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
                ComponentName candidate = ComponentName.unflattenFromString(service.getId());
                if (expected.equals(candidate)) return true;
                if (service.getResolveInfo() != null && service.getResolveInfo().serviceInfo != null) {
                    android.content.pm.ServiceInfo si = service.getResolveInfo().serviceInfo;
                    if (expected.equals(new ComponentName(si.packageName, si.name))) return true;
                }
            }
        } catch (Exception ignored) { }
        return false;
    }

    private boolean isAccessibilityEnabled() {
        return inSecureSettings() || inManagerList() || VoiceAccessibilityService.isConnected();
    }

    private void updateStatus() {
        if (accessStatus == null) return;
        boolean secure = inSecureSettings();
        boolean list = inManagerList();
        boolean connected = VoiceAccessibilityService.isConnected();
        accessStatus.setText((secure || list || connected
                ? "Разрешение: ВКЛЮЧЕНО ✅" : "Разрешение: НЕ ОБНАРУЖЕНО ⛔")
                + "\nСлужба: " + (connected ? "ПОДКЛЮЧЕНА ✅" : "НЕ ПОДКЛЮЧЕНА ⚠️"));
        if (audioStatus != null) audioStatus.setText("Bluetooth HFP:\n" + WatchAudioDiagnostic.status() + "\nДоступные устройства: " + WatchAudioDiagnostic.devices(this));
        attemptStatus.setText("Последняя попытка:\n" + VoiceAccessibilityService.lastStatus(this));
        debugStatus.setText("Диагностика:\n" + VoiceAccessibilityService.lastDebug(this)
                + "\nПроверка Android: настройка=" + (secure ? "да" : "нет")
                + ", список=" + (list ? "да" : "нет")
                + ", соединение=" + (connected ? "да" : "нет")
                + "\nОбученное нажатие: "
                + (VoiceAccessibilityService.calibrated(this) ? "есть ✅" : "нет"));
    }

    private void drawUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xff0a0e18);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setPadding(dp(22), dp(32), dp(22), dp(30));
        scroll.addView(layout);
        layout.addView(label("Stereoo ChatGPT Bridge 0.6", 23, 0xffe4ebff, true));
        layout.addView(label("TicWatch Pro 3 → телефон → ChatGPT Voice", 13, 0xff9cacc9, false));
        info = label("Проверяем фактический маршрут звука на часы. Запуск ChatGPT Voice не меняли.", 15, 0xffdce3f4, false);
        layout.addView(info);
        accessStatus = label("Проверяю доступ…", 16, 0xffb5ebc0, true);
        layout.addView(accessStatus);

        Button permissions = makeButton("1. ПРОВЕРИТЬ СПЕЦВОЗМОЖНОСТИ", 0xff35659c);
        permissions.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            catch (Exception e) { info.setText("Не удалось открыть настройки специальных возможностей."); }
        });
        addButton(layout, permissions);

        Button test = makeButton("2. ПРОВЕРИТЬ CHATGPT + VOICE", 0xff444edb);
        test.setOnClickListener(v -> openChatGpt(false));
        addButton(layout, test);

        Button learn = makeButton("3. ОБУЧИТЬ КНОПКУ VOICE", 0xff33856b);
        learn.setOnClickListener(v -> {
            if (!isAccessibilityEnabled()) {
                info.setText("Сначала включи службу Stereoo в специальных возможностях!");
                return;
            }
            openChatGpt(true);
        });
        addButton(layout, learn);
        layout.addView(label("Обучение: ChatGPT откроется. Один раз нажми Voice ВРУЧНУЮ, дождись начала разговора, вернись в Bridge. Затем запусти с часов.", 12, 0xff9eacc6, false));

        layout.addView(label("ТЕСТ ЗВУКА НА ЧАСАХ", 18, 0xffd7e6ff, true));
        layout.addView(label("Телефонные вызовы на часах должны быть включены. На 18 секунд проверяем канал HFP и пробуем вывести собственный сигнал Bridge прямо на часы. Сигнал прозвучит примерно через 4 секунды.", 12, 0xff9eacc6, false));
        Button hfpTest = makeButton("4. ПРОВЕРИТЬ ЗВУК ЧАСОВ (HFP)", 0xff167c87);
        hfpTest.setOnClickListener(v -> {
            boolean ok = WatchAudioDiagnostic.begin(this, false);
            info.setText(ok ? "Слушай часы: через 4 секунды прозвучит тестовый сигнал. Через 8–10 секунд нажми «СКОПИРОВАТЬ ДИАГНОСТИКУ»." : "Канал HFP не открылся. Проверь диагностику ниже.");
            updateStatus();
        });
        addButton(layout, hfpTest);
        Button hfpVoice = makeButton("5. ТЕСТ CHATGPT С КАНАЛОМ HFP", 0xff277a65);
        hfpVoice.setOnClickListener(v -> {
            boolean ok = WatchAudioDiagnostic.begin(this, true);
            updateStatus();
            if (ok) ui.postDelayed(() -> openChatGpt(false), 1200);
            else info.setText("Сначала нужно обнаружить Bluetooth HFP часы. Смотри статус ниже.");
        });
        addButton(layout, hfpVoice);
        Button hfpStop = makeButton("ОСТАНОВИТЬ АУДИОТЕСТ", 0xff714654);
        hfpStop.setOnClickListener(v -> { WatchAudioDiagnostic.stop(); updateStatus(); });
        addButton(layout, hfpStop);
        audioStatus = label("", 13, 0xff92e3ce, false);
        addWithMargin(layout, audioStatus, 10);

        attemptStatus = label("", 14, 0xffe4ebff, true);
        addWithMargin(layout, attemptStatus, 14);
        debugStatus = label("", 13, 0xffafbcd3, false);
        addWithMargin(layout, debugStatus, 5);

        Button refresh = makeButton("ОБНОВИТЬ ДИАГНОСТИКУ", 0xff354a68);
        refresh.setOnClickListener(v -> updateStatus());
        addButton(layout, refresh);

        Button copy = makeButton("СКОПИРОВАТЬ ДИАГНОСТИКУ", 0xff354a68);
        copy.setOnClickListener(v -> {
            String report = "Stereoo v0.6\n" + accessStatus.getText() + "\n" + attemptStatus.getText()
                    + "\n" + debugStatus.getText() + "\n" + audioStatus.getText();
            ClipboardManager clip = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clip != null) {
                clip.setPrimaryClip(ClipData.newPlainText("Stereoo debug", report));
                Toast.makeText(this, "Диагностика скопирована", Toast.LENGTH_SHORT).show();
            }
        });
        addButton(layout, copy);

        Button reset = makeButton("СБРОСИТЬ ОБУЧЕНИЕ", 0xff674957);
        reset.setOnClickListener(v -> { VoiceAccessibilityService.forgetCalibration(this); updateStatus(); });
        addButton(layout, reset);

        TextView foot = label("Без OpenAI API. Прямой аудиотест проверяет только звук самого Bridge. Он не переключает звук официального приложения ChatGPT."
                + " Для проверки разблокируй экран и один раз запусти Voice вручную."
                + " Если кнопка сместилась после обновления ChatGPT, сбрось обучение.\n\n"
                + "Разработчик: Жданов Александр", 12, 0xff8491aa, false);
        addWithMargin(layout, foot, 14);
        setContentView(scroll);
        updateStatus();
    }

    private Button makeButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        return b;
    }

    private void addButton(LinearLayout layout, Button button) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(49));
        p.topMargin = dp(13);
        layout.addView(button, p);
    }
    private void addWithMargin(LinearLayout layout, TextView view, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(margin);
        layout.addView(view, p);
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(6), 0, dp(6));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }
}
