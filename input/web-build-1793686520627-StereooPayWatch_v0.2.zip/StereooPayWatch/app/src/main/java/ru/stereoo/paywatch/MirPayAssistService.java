package ru.stereoo.paywatch;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * User-enabled accessibility helper for Mir Pay. It never changes DPI, does not
 * touch NFC/payment logic, and does not read/edit card entry fields.
 * Every click must be explicitly selected by the user in the helper menu.
 */
public final class MirPayAssistService extends AccessibilityService {
    private static final String TARGET = "ru.nspk.mirpay";
    private static final int BG = Color.rgb(8, 23, 32);
    private static final int CARD = Color.rgb(22, 47, 59);
    private static final int ACCENT = Color.rgb(44, 228, 181);
    private static final int TEXT = Color.WHITE;

    private WindowManager windowManager;
    private View bubble;
    private View menu;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean destroyed;
    private boolean scheduled;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        refreshOverlay();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || destroyed) return;
        // State and content updates may be noisy; debounce updates to avoid jitter.
        if (!scheduled) {
            scheduled = true;
            handler.postDelayed(() -> {
                scheduled = false;
                refreshOverlay();
            }, 180);
        }
    }

    @Override public void onInterrupt() { hideAll(); }

    @Override public boolean onUnbind(android.content.Intent intent) {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        hideAll();
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        hideAll();
        super.onDestroy();
    }

    private AccessibilityNodeInfo mirPayRoot() {
        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows != null) {
                for (AccessibilityWindowInfo w : windows) {
                    if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                    AccessibilityNodeInfo root = w.getRoot();
                    if (root != null && root.getPackageName() != null && TARGET.contentEquals(root.getPackageName())) return root;
                }
            }
            AccessibilityNodeInfo active = getRootInActiveWindow();
            if (active != null && active.getPackageName() != null && TARGET.contentEquals(active.getPackageName())) return active;
        } catch (RuntimeException ignored) {
            // A protected or changing window might be temporarily unavailable.
        }
        return null;
    }

    private void refreshOverlay() {
        if (destroyed || windowManager == null) return;
        if (mirPayRoot() == null) {
            hideAll();
        } else if (menu == null && bubble == null) {
            showBubble();
        }
    }

    private void hideAll() {
        remove(bubble);
        remove(menu);
        bubble = null;
        menu = null;
    }

    private void remove(View view) {
        if (view == null || windowManager == null) return;
        try { windowManager.removeView(view); } catch (IllegalArgumentException ignored) { }
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(float value) {
        return (int) (getResources().getDisplayMetrics().density * value + 0.5f);
    }

    private WindowManager.LayoutParams params(int width, int height, int gravity, int y) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                width, height, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = gravity;
        p.y = y;
        return p;
    }

    private void showBubble() {
        if (bubble != null || destroyed || windowManager == null) return;
        TextView b = new TextView(this);
        b.setText("⇧");
        b.setContentDescription("Управление Mir Pay, без смены DPI");
        b.setTextSize(24);
        b.setTextColor(BG);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackground(background(ACCENT, 30));
        b.setOnClickListener(v -> showMenu());
        try {
            windowManager.addView(b, params(dp(44), dp(44), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, dp(10)));
            bubble = b;
        } catch (RuntimeException e) { bubble = null; }
    }

    private TextView row(String title, boolean primary, Runnable action) {
        TextView item = new TextView(this);
        item.setText(title);
        item.setTextSize(13);
        item.setTextColor(primary ? BG : TEXT);
        item.setGravity(Gravity.CENTER);
        item.setMinHeight(dp(40));
        item.setPadding(dp(10), dp(7), dp(10), dp(7));
        item.setBackground(background(primary ? ACCENT : CARD, 16));
        item.setOnClickListener(v -> action.run());
        return item;
    }

    private void addRow(LinearLayout container, String title, boolean primary, Runnable action) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(6));
        container.addView(row(title, primary, action), lp);
    }

    private void showMenu() {
        if (menu != null || destroyed) return;
        if (mirPayRoot() == null) { hideAll(); return; }
        remove(bubble);
        bubble = null;

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(12));
        panel.setBackground(background(BG, 24));

        TextView header = new TextView(this);
        header.setText("Stereoo Pay  •  Кнопки");
        header.setTextSize(14);
        header.setTextColor(ACCENT);
        header.setGravity(Gravity.CENTER);
        header.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        panel.addView(header);

        TextView hint = new TextView(this);
        hint.setText("Выбирай действие вручную");
        hint.setTextSize(11);
        hint.setTextColor(Color.LTGRAY);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(3), 0, dp(10));
        panel.addView(hint);

        final ArrayList<Control> actions = new ArrayList<>();
        AccessibilityNodeInfo root = mirPayRoot();
        if (root != null) collectButtons(root, actions, 0);
        if (actions.isEmpty()) {
            addRow(panel, "Кнопки не обнаружены", false,
                    () -> Toast.makeText(this, "Попробуй прокрутку", Toast.LENGTH_SHORT).show());
        } else {
            for (Control c : actions) {
                addRow(panel, "Нажать: " + c.label, true, () -> {
                    closeMenu();
                    // Re-locate the current button on the underlying screen.
                    handler.postDelayed(() -> clickControl(c), 160);
                });
            }
        }
        addRow(panel, "ПРОКРУТИТЬ ВНИЗ", false, () -> {
            closeMenu(); handler.postDelayed(() -> scroll(true), 160);
        });
        addRow(panel, "ПРОКРУТИТЬ ВВЕРХ", false, () -> {
            closeMenu(); handler.postDelayed(() -> scroll(false), 160);
        });
        addRow(panel, "ОБНОВИТЬ СПИСОК", false, () -> {
            closeMenu(); handler.postDelayed(this::showMenu, 250);
        });
        addRow(panel, "ЗАКРЫТЬ", false, this::closeMenu);

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFillViewport(false);
        scroll.addView(panel);
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int width = Math.min(metrics.widthPixels - dp(26), dp(290));
        int height = (int) (metrics.heightPixels * 0.76f);
        try {
            windowManager.addView(scroll, params(width, height, Gravity.CENTER, 0));
            menu = scroll;
        } catch (RuntimeException e) { menu = null; showBubble(); }
    }

    private static final class Control {
        final String label;
        final int occurrence;
        Control(String label, int occurrence) { this.label = label; this.occurrence = occurrence; }
    }

    private void collectButtons(AccessibilityNodeInfo node, ArrayList<Control> out, int depth) {
        if (node == null || depth > 25 || out.size() >= 6) return;
        // Buttons only; never inspect, display or record EditText, passwords or card data.
        CharSequence cls = node.getClassName();
        CharSequence title = node.getText();
        if (node.isClickable() && node.isEnabled() && cls != null &&
                cls.toString().endsWith("Button") && title != null && title.length() > 0) {
            String label = title.toString().replace('\n', ' ').trim();
            if (!label.isEmpty()) {
                int occurrence = 0;
                for (Control c : out) if (c.label.equals(label)) occurrence++;
                out.add(new Control(label.length() > 40 ? label.substring(0, 40) : label, occurrence));
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectButtons(node.getChild(i), out, depth + 1);
            if (out.size() >= 6) break;
        }
    }

    private void clickControl(Control control) {
        AccessibilityNodeInfo root = mirPayRoot();
        if (root == null) { notifyUser("Mir Pay не открыт"); return; }
        int[] seen = {0};
        boolean done = clickMatching(root, control.label, control.occurrence, seen, 0);
        if (!done) notifyUser("Кнопка недоступна, обнови список");
    }

    private boolean clickMatching(AccessibilityNodeInfo node, String label, int occurrence,
                                  int[] seen, int depth) {
        if (node == null || depth > 25) return false;
        CharSequence cls = node.getClassName();
        CharSequence value = node.getText();
        if (node.isClickable() && node.isEnabled() && cls != null &&
                cls.toString().endsWith("Button") && value != null &&
                value.toString().replace('\n',' ').trim().startsWith(label)) {
            if (seen[0]++ == occurrence)
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            if (clickMatching(node.getChild(i), label, occurrence, seen, depth + 1)) return true;
        }
        return false;
    }

    private void scroll(boolean down) {
        AccessibilityNodeInfo root = mirPayRoot();
        if (root == null) return;
        if (!scrollNode(root, down, 0)) notifyUser("Экран не поддерживает прокрутку");
    }

    private boolean scrollNode(AccessibilityNodeInfo node, boolean down, int depth) {
        if (node == null || depth > 25) return false;
        if (node.isScrollable()) {
            int action = down ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD;
            if (node.performAction(action)) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            if (scrollNode(node.getChild(i), down, depth + 1)) return true;
        }
        return false;
    }

    private void closeMenu() {
        remove(menu);
        menu = null;
        if (mirPayRoot() != null) showBubble();
    }

    private void notifyUser(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
