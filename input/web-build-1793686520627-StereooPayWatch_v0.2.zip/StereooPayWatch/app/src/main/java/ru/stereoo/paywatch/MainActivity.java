package ru.stereoo.paywatch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Standalone watch control panel for the unmodified, separately installed Mir Pay.
 * No card information is requested, processed or stored by this app.
 */
public final class MainActivity extends Activity {
    private static final String MIRPAY = "ru.nspk.mirpay";
    private static final int BG = Color.rgb(7, 21, 30);
    private static final int PANEL = Color.rgb(22, 42, 52);
    private static final int SECONDARY = Color.rgb(31, 55, 68);
    private static final int MINT = Color.rgb(44, 228, 181);
    private static final int TEXT = Color.rgb(241, 249, 250);
    private static final int MUTED = Color.rgb(155, 185, 193);
    private LinearLayout content;
    private boolean showDiagnostics = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        drawHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (content != null && !showDiagnostics) drawHome();
    }

    @Override
    public void onBackPressed() {
        if (showDiagnostics) {
            showDiagnostics = false;
            drawHome();
        } else {
            super.onBackPressed();
        }
    }

    private void initializeScreen() {
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setVerticalScrollBarEnabled(false);
        scroller.setBackgroundColor(BG);
        scroller.setClipToPadding(false);
        scroller.setPadding(dp(23), dp(12), dp(23), dp(20));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(0, dp(10), 0, dp(22));
        scroller.addView(content);
        setContentView(scroller);
    }

    private void drawHome() {
        showDiagnostics = false;
        initializeScreen();

        TextView mark = text("S", 22, BG, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(background(MINT, 28));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(46), dp(46));
        mp.bottomMargin = dp(9);
        content.addView(mark, mp);

        centerText("STEREOO  /  WEAR OS", 10, MUTED, true, 4);
        centerText("PAY", 33, TEXT, true, 3);
        centerText("Панель управления Mir Pay", 12, MUTED, false, 17);

        LinearLayout status = container(PANEL);
        String version = mirPayVersion();
        label(status, version == null ? "MIR PAY НЕ НАЙДЕН" : "MIR PAY УСТАНОВЛЕН",
                12, version == null ? Color.rgb(255, 175, 146) : MINT, true, 4);
        label(status, version == null ? "Установи оригинальное приложение на часы" : "Версия: " + version,
                12, TEXT, false, 8);
        NfcAdapter nfc = NfcAdapter.getDefaultAdapter(this);
        String nfcText = nfc == null ? "NFC: модуль не найден" :
                (nfc.isEnabled() ? "NFC: включён" : "NFC: выключен");
        label(status, nfcText, 12, MUTED, false, 1);

        button("УПРАВЛЕНИЕ БЕЗ DPI", true, this::openAccessibilitySettings);
        button("ОТКРЫТЬ MIR PAY", false, () -> launchMirPay(false));
        button("МОИ КАРТЫ", false, () -> launchMirPay(true));
        button("НАСТРОЙКИ ОПЛАТЫ", false, this::openPaymentSettings);
        button("НАСТРОЙКИ MIR PAY", false, this::openMirPaySettings);
        button("ДИАГНОСТИКА ЧАСОВ", false, () -> {
            showDiagnostics = true;
            drawDiagnostics();
        });

        centerText("Включи службу в специальных возможностях. В Mir Pay появится кнопка ⇧ для управления скрытыми элементами.",
                11, MUTED, false, 9);
        centerText("Карты и платежи обрабатывает только оригинальный Mir Pay.",
                11, MUTED, false, 12);
        centerText("Жданов Александр  ·  v0.2", 10, MUTED, false, 2);
    }

    private void drawDiagnostics() {
        initializeScreen();
        button("‹  НАЗАД", false, () -> {
            showDiagnostics = false;
            drawHome();
        });
        centerText("ДИАГНОСТИКА", 21, TEXT, true, 10);
        centerText("Проверка возможностей часов", 11, MUTED, false, 12);
        LinearLayout card = container(PANEL);
        String report = diagnosticReport();
        String[] lines = report.split("\\n");
        for (String line : lines) {
            label(card, line, 12, line.contains("нет") || line.contains("выключен") ?
                    Color.rgb(255, 183, 153) : TEXT, false, 9);
        }
        button("СКОПИРОВАТЬ ОТЧЁТ", true, () -> {
            ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cb != null) {
                cb.setPrimaryClip(ClipData.newPlainText("Stereoo Pay diagnosis", report));
                toast("Отчёт скопирован. Банковских данных в нём нет.");
            }
        });
        button("ПАМЯТКА ПО DPI", false, this::showDpiInfo);
        centerText("Если Mir Pay открывается белым экраном и вылетает, эта панель не сможет его исправить. " +
                "Для причины сбоя нужен журнал logcat с часов.", 11, MUTED, false, 10);
    }

    private String diagnosticReport() {
        String version = mirPayVersion();
        boolean found = version != null;
        boolean launchable = found && getPackageManager().getLaunchIntentForPackage(MIRPAY) != null;
        NfcAdapter nfc = NfcAdapter.getDefaultAdapter(this);
        boolean hce = getPackageManager().hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION);
        int dpi = getResources().getDisplayMetrics().densityDpi;
        return "Устройство: " + Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                "Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n" +
                "Mir Pay: " + (found ? version : "не установлен") + "\n" +
                "Запуск Mir Pay: " + (launchable ? "доступен" : "недоступен") + "\n" +
                "NFC: " + (nfc == null ? "нет модуля" : (nfc.isEnabled() ? "включён" : "выключен")) + "\n" +
                "NFC HCE: " + (hce ? "есть" : "нет") + "\n" +
                "DPI интерфейса: " + dpi + "\n" +
                "Важно: совместимость и готовность к оплате этим тестом не подтверждаются.";
    }

    private String mirPayVersion() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(MIRPAY, 0);
            return info.versionName == null ? "определить не удалось" : info.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private void launchMirPay(boolean cards) {
        if (mirPayVersion() == null) {
            toast("Mir Pay не найден на часах");
            return;
        }
        Intent launch = getPackageManager().getLaunchIntentForPackage(MIRPAY);
        if (launch == null) {
            toast("У Mir Pay не обнаружен доступный экран запуска");
            return;
        }
        if (cards) toast("Добавление карт выполняется внутри Mir Pay");
        try {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (ActivityNotFoundException | SecurityException e) {
            toast("Не удалось запустить оригинальный Mir Pay");
        }
    }

    private void openAccessibilitySettings() {
        new AlertDialog.Builder(this)
                .setTitle("Управление кнопками")
                .setMessage("1. В специальных возможностях включи службу «Stereoo Pay — помощь с кнопками».\n\n" +
                        "2. Открой оригинальный Mir Pay. Внизу появится кнопка ⇧.\n\n" +
                        "3. Нажми ⇧ и выбери нужную кнопку Mir Pay. DPI не изменяется.\n\n" +
                        "Служба видит элементы интерфейса. Не используй её для ввода или передачи банковских реквизитов.")
                .setNegativeButton("ОТМЕНА", (d, w) -> d.dismiss())
                .setPositiveButton("ОТКРЫТЬ", (d, w) -> {
                    if (!tryOpen(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                        toast("Не удалось открыть настройки. Зайди в Спец. возможности вручную.");
                }).show();
    }

    private void openPaymentSettings() {
        // Different Wear OS firmware versions expose different NFC/payment screens.
        if (tryOpen(new Intent("android.settings.NFC_PAYMENT_SETTINGS"))) return;
        if (tryOpen(new Intent(Settings.ACTION_NFC_SETTINGS))) return;
        if (tryOpen(new Intent(Settings.ACTION_WIRELESS_SETTINGS))) return;
        toast("Системные настройки NFC недоступны на этой прошивке");
    }

    private void openMirPaySettings() {
        if (mirPayVersion() == null) {
            toast("Mir Pay не найден на часах");
            return;
        }
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + MIRPAY));
        if (!tryOpen(intent)) toast("Системная страница Mir Pay недоступна");
    }

    private boolean tryOpen(Intent intent) {
        try {
            startActivity(intent);
            return true;
        } catch (ActivityNotFoundException | SecurityException e) {
            return false;
        }
    }

    private void showDpiInfo() {
        new AlertDialog.Builder(this)
                .setTitle("DPI и Mir Pay")
                .setMessage("Приложение не может менять масштаб другого приложения без системных прав. " +
                        "С телефона через Bugjaeger (ADB shell на часах):\n\n" +
                        "Уменьшить: wm density 160\n\n" +
                        "Вернуть: wm density reset\n\n" +
                        "Эти команды не устраняют ошибки совместимости Mir Pay.")
                .setPositiveButton("ПОНЯТНО", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private LinearLayout container(int color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(14), dp(17), dp(13));
        card.setBackground(background(color, 20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        content.addView(card, lp);
        return card;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(size);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setIncludeFontPadding(true);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return tv;
    }

    private void label(LinearLayout parent, String value, int size, int color,
                       boolean bold, int bottomMarginDp) {
        TextView tv = text(value, size, color, bold);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(bottomMarginDp);
        parent.addView(tv, lp);
    }

    private void centerText(String value, int size, int color, boolean bold, int bottomMarginDp) {
        TextView tv = text(value, size, color, bold);
        tv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(bottomMarginDp);
        content.addView(tv, lp);
    }

    private void button(String value, boolean primary, Runnable handler) {
        TextView b = text(value, primary ? 14 : 12, primary ? BG : TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(primary ? 59 : 51));
        b.setPadding(dp(10), dp(7), dp(10), dp(7));
        b.setBackground(background(primary ? MINT : SECONDARY, 23));
        b.setClickable(true);
        b.setFocusable(true);
        b.setOnClickListener(view -> handler.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(9);
        content.addView(b, lp);
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    private int dp(float value) {
        return (int) (getResources().getDisplayMetrics().density * value + 0.5f);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
