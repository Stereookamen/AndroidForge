package ru.stereoo.morkovsk

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val store by lazy { getSharedPreferences("morkovsk", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.accessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.openOzon).setOnClickListener { openOzon() }
        findViewById<Button>(R.id.start).setOnClickListener {
            if (MorkovService.current == null) {
                toast("Сначала включи «Морковск Авто» в Спецвозможностях Android")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                MorkovService.current?.startRun()
                openOzon()
            }
            updateStatus()
        }
        findViewById<Button>(R.id.continueBtn).setOnClickListener {
            MorkovService.current?.manualCartDone()
                ?: toast("Сначала включи спецвозможности")
            updateStatus()
        }
        findViewById<Button>(R.id.scan).setOnClickListener {
            MorkovService.current?.scanNow()
            updateStatus()
        }
        findViewById<Button>(R.id.diagnostic).setOnClickListener {
            val report = store.getString("diagnostic", "") ?: ""
            if (report.isBlank()) toast("Нет показаний. Запусти программу и открой Морковск.")
            else {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Морковск: диагностика", report))
                toast("Диагностика скопирована. Проверь личные данные перед отправкой.")
            }
        }
        findViewById<Button>(R.id.stop).setOnClickListener {
            MorkovService.current?.stopRun()
            updateStatus()
        }
    }

    override fun onResume() { super.onResume(); updateStatus() }

    private fun updateStatus() {
        val enabled = MorkovService.current != null
        val running = store.getBoolean("running", false)
        status.text = "Спецвозможности: ${if (enabled) "включены ✓" else "НЕ включены"}\n" +
            "Автоматика: ${if (running) "РАБОТАЕТ" else "не работает"}\n" +
            "Этап: ${store.getString("phase", "—")}\n" +
            "Посещено разделов: ${store.getInt("visits", 0)}\n" +
            "Добавление в корзину: ${if (store.getInt("cart", 0) == 1) "кнопка нажата" else "не выполнено"}\n\n" +
            (store.getString("status", "Нажми «Начать сбор», когда Ozon готов.") ?: "")
    }

    private fun openOzon() {
        val deepLink = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ozon.ru/gameapp/main?miniapp=regularDraw")).apply {
            setPackage(MorkovService.OZON)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(deepLink)
        } catch (_: Exception) {
            val launch = packageManager.getLaunchIntentForPackage(MorkovService.OZON)
            if (launch != null) {
                startActivity(launch)
                toast("Открой «Морковск» в Ozon вручную")
            } else toast("Ozon не найден. Установи официальный Ozon.")
        }
    }

    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
}
