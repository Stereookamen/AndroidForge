# AI Stereoo · исправленная база HeyCyan SDK для AndroidForge

## Исправления по журналу AndroidForge (18)
- В `MainActivity.kt` заменены вызовы `withContext(Dispatchers.Main)` внутри обычных callback-блоков на запуск корутины главного потока.
- В `WifiP2pBroadcastReceiver.kt` и `WifiP2pManagerSingleton.kt` исправлено имя Android API-константы на `WIFI_P2P_CONNECTION_CHANGED_ACTION`.
- В `WifiP2pManagerSingleton.kt` добавлен импорт `BroadcastReceiver`; константа `TAG` перенесена в единственный `companion object`.
- Gradle Wrapper SDK-примера обновляется до 8.13.
- Добавлена задача `bundleDebug`, которую запрашивает AndroidForge.
- Задаются имя `AI Stereoo` и applicationId `ru.stereooai.go`.

## Сборка
Загрузите ZIP в AndroidForge и запустите сборку. Для скачивания исходников SDK и зависимостей требуется доступ к GitHub и Maven-репозиториям.

## Важно
Это сборочная база на основе примера HeyCyan SDK, не готовое приложение с десятью экранами из макета. Перед выдачей рабочего APK необходимо подтвердить успешную сборку в AndroidForge. Интеграция OpenAI и финальный интерфейс ещё не реализованы. Секретных API-ключей в проекте нет.
