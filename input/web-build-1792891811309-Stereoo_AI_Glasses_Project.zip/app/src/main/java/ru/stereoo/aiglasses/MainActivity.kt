package ru.stereoo.aiglasses

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import android.util.Base64

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var lastAnswer = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Stereoo AI Glasses"
            textSize = 25f
            gravity = Gravity.CENTER
        }, match(-1, -2))
        layout.addView(TextView(this).apply {
            text = "Голосовой помощник и анализ фотографий"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }, match(-1, -2))
        input = EditText(this).apply {
            hint = "Напиши вопрос..."
            minLines = 2
            gravity = Gravity.TOP
        }
        layout.addView(input, match(-1, -2))
        addButton(layout, "ОТПРАВИТЬ ВОПРОС") { sendText(input.text.toString()) }
        addButton(layout, "🎙 ГОВОРИТЬ") { listen() }
        addButton(layout, "📷 ВЫБРАТЬ ФОТОГРАФИЮ") {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 22)
        }
        addButton(layout, "🔊 ПОВТОРИТЬ ОТВЕТ") {
            if (lastAnswer.isNotBlank()) tts.speak(lastAnswer, TextToSpeech.QUEUE_FLUSH, null, "answer")
        }
        addButton(layout, "🔑 НАСТРОИТЬ API-КЛЮЧ") { keyDialog() }
        status = TextView(this).apply {
            text = "Готов к работе. Для ответов нужен API-ключ OpenAI."
            textSize = 15f
            setPadding(0, 16, 0, 0)
        }
        layout.addView(status, match(-1, -2))
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun match(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
    }
    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("ru", "RU")
    }
    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говори, я слушаю")
        }
        try { startActivityForResult(intent, 11) }
        catch (_: Exception) { status.text = "На телефоне не найден сервис распознавания речи." }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == 11) {
            val words = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!words.isNullOrEmpty()) { input.setText(words[0]); sendText(words[0]) }
        } else if (requestCode == 22) {
            val uri = data.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream) ?: throw Exception("Не удалось прочитать изображение")
                    sendImage(bitmap)
                }
            } catch (e: Exception) { status.text = "Ошибка фото: ${e.message}" }
        }
    }
    private fun keyDialog() {
        val field = EditText(this).apply {
            hint = "sk-..."
            setText(prefs.getString("api_key", ""))
            inputType = 129
        }
        AlertDialog.Builder(this).setTitle("API-ключ OpenAI")
            .setMessage("Ключ хранится только в данных этого приложения на телефоне. Не публикуй его в GitHub.")
            .setView(field)
            .setPositiveButton("Сохранить") { _, _ ->
                prefs.edit().putString("api_key", field.text.toString().trim()).apply()
                status.text = "API-ключ сохранён на устройстве."
            }.setNegativeButton("Отмена", null).show()
    }
    private fun sendText(text: String) {
        if (text.isBlank()) { status.text = "Сначала введи вопрос или нажми «Говорить»."; return }
        val body = JSONObject().put("model", "gpt-4.1-mini")
            .put("input", text)
        callApi(body)
    }
    private fun sendImage(bitmap: Bitmap) {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) { keyDialog(); return }
        val scaled = if (bitmap.width > 1200 || bitmap.height > 1200) {
            val ratio = minOf(1200f / bitmap.width, 1200f / bitmap.height)
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
        } else bitmap
        val bytes = ByteArrayOutputStream().also { scaled.compress(Bitmap.CompressFormat.JPEG, 82, it) }.toByteArray()
        val dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        val content = JSONArray()
            .put(JSONObject().put("type", "input_text").put("text", "Опиши фотографию по-русски."))
            .put(JSONObject().put("type", "input_image").put("image_url", dataUrl))
        callApi(JSONObject().put("model", "gpt-4.1-mini")
            .put("input", JSONArray().put(JSONObject().put("role", "user").put("content", content))))
    }
    private fun callApi(body: JSONObject) {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) { keyDialog(); return }
        status.text = "Думаю…"
        executor.execute {
            try {
                val conn = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 60000
                conn.doOutput = true
                conn.setRequestProperty("Authorization", "Bearer $key")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) throw Exception(JSONObject(response).optJSONObject("error")?.optString("message") ?: response)
                val json = JSONObject(response)
                val output = json.optJSONArray("output") ?: JSONArray()
                val result = StringBuilder()
                for (i in 0 until output.length()) {
                    val item = output.optJSONObject(i) ?: continue
                    val content = item.optJSONArray("content") ?: continue
                    for (j in 0 until content.length()) {
                        val part = content.optJSONObject(j) ?: continue
                        if (part.optString("type") == "output_text") result.append(part.optString("text"))
                    }
                }
                val answer = result.toString().ifBlank { "Не удалось получить текстовый ответ." }
                runOnUiThread {
                    lastAnswer = answer
                    status.text = answer
                    tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "answer")
                }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread { status.text = "Ошибка: ${e.message ?: "не удалось связаться с API"}" }
            }
        }
    }
    override fun onDestroy() {
        tts.stop(); tts.shutdown(); executor.shutdownNow()
        super.onDestroy()
    }
}
