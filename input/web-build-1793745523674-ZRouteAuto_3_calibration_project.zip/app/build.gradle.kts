plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.zrouteauto"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.zrouteauto"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }
}
