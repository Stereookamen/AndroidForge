package com.example.zrouteauto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(Color.rgb(18, 22, 31))
        }
        fun text(s: String) = TextView(this).apply {
            this.text = s; textSize = 16f; setTextColor(Color.WHITE)
            setPadding(0, dp(7), 0, dp(7))
        }
        fun input(h: String, v: String) = EditText(this).apply {
            hint = h; setText(v); setSingleLine(true); textSize = 15f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        root.addView(text("🧟 Z ROUTE AUTO 3.0"))
        root.addView(text("Режим распознавания: подготовка калибровки"))
        root.addView(Button(this).apply {
            this.text = "Включить службу касаний"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(text("Координаты задаются в пикселях текущего разрешения экрана. Сначала проверяй каждую точку вручную."))
        val names = listOf("X кнопки босса" to "360", "Y кнопки босса" to "760",
            "X кнопки выбора отряда" to "360", "Y кнопки выбора отряда" to "1100",
            "X подтверждения атаки" to "360", "Y подтверждения атаки" to "1400")
        val fields = names.map { (n,v) -> input(n,v).also { root.addView(it) } }
        root.addView(input("Пауза между проверками, секунд", "5").also { /* kept visible */ })
        root.addView(text("Автоматическая отправка пока выключена: сначала нужна проверка распознавания на твоём реальном экране."))
        root.addView(Button(this).apply {
            this.text = "ТЕСТ ОДНОГО КАСАНИЯ"
            setOnClickListener {
                val p = getSharedPreferences("macro", MODE_PRIVATE)
                p.edit().putInt("x", fields[0].text.toString().toIntOrNull() ?: 360)
                    .putInt("y", fields[1].text.toString().toIntOrNull() ?: 760).apply()
                AutoTapService.testTap = true
                Toast.makeText(this@MainActivity, "Одно тестовое касание отправлено службе", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            this.text = "СТОП"
            setOnClickListener { AutoTapService.running = false; AutoTapService.testTap = false }
        })
        root.addView(text("Важно: эта версия ещё не распознаёт возвращение отрядов и не запускает бесконечные атаки. Она подготовлена для безопасной калибровки управления."))
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
