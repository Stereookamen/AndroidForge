package com.example.zrouteauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class AutoTapService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (testTap) {
            testTap = false
            val p = getSharedPreferences("macro", MODE_PRIVATE)
            val path = Path().apply { moveTo(p.getInt("x", 360).toFloat(), p.getInt("y", 760).toFloat()) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
            dispatchGesture(gesture, null, null)
        }
    }
    override fun onInterrupt() { running = false; testTap = false }
    companion object {
        @Volatile var running = false
        @Volatile var testTap = false
    }
}
