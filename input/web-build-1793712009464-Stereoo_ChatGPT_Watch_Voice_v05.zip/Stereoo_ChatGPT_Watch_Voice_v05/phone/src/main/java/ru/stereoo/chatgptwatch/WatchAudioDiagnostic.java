package ru.stereoo.chatgptwatch;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.Locale;

/** Diagnostic HFP voice channel test. Does NOT capture ChatGPT audio. */
public final class WatchAudioDiagnostic {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static AudioManager manager;
    private static int previousMode = AudioManager.MODE_NORMAL;
    private static boolean active = false;
    private static boolean routingRequested = false;
    private static String status = "Проверка HFP ещё не проводилась.";
    private static Runnable cleanup;
    private static long session = 0;

    private WatchAudioDiagnostic() { }

    public static synchronized String status() { return status; }

    public static synchronized String devices(Context ctx) {
        if (Build.VERSION.SDK_INT < 31) return "Для проверки нужен Android 12 или выше.";
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return "AudioManager отсутствует";
            List<AudioDeviceInfo> items = am.getAvailableCommunicationDevices();
            if (items == null || items.isEmpty()) return "Android не сообщил ни одного устройства связи";
            StringBuilder out = new StringBuilder();
            for (AudioDeviceInfo d : items) {
                if (out.length() > 0) out.append("; ");
                out.append(type(d.getType())).append(" / ").append(name(d));
            }
            return out.toString();
        } catch (Exception ex) { return "Ошибка определения аудиоустройств: " + ex.getClass().getSimpleName(); }
    }

    private static String type(int type) {
        if (type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) return "BT HFP/SCO";
        if (Build.VERSION.SDK_INT >= 31 && type == AudioDeviceInfo.TYPE_BLE_HEADSET) return "BLE headset";
        if (type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) return "Динамик телефона";
        if (type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE) return "Разговорный динамик телефона";
        return "тип=" + type;
    }

    private static String name(AudioDeviceInfo info) {
        CharSequence value = info.getProductName();
        return value == null ? "без имени" : value.toString();
    }

    private static boolean isHeadset(AudioDeviceInfo info) {
        return info.getType() == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (Build.VERSION.SDK_INT >= 31 && info.getType() == AudioDeviceInfo.TYPE_BLE_HEADSET);
    }

    public static synchronized boolean begin(Context context, boolean chatGptMode) {
        stop();
        if (Build.VERSION.SDK_INT < 31) {
            status = "Нужен Android 12+ для setCommunicationDevice";
            return false;
        }
        try {
            manager = (AudioManager) context.getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
            if (manager == null) { status = "Android AudioManager недоступен"; return false; }
            previousMode = manager.getMode();
            // Communication mode makes the list of HFP devices visible to the router.
            manager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            List<AudioDeviceInfo> available = manager.getAvailableCommunicationDevices();
            AudioDeviceInfo selected = null;
            for (AudioDeviceInfo d : available) {
                if (!isHeadset(d)) continue;
                String n = name(d).toLowerCase(Locale.ROOT);
                if (n.contains("ticwatch") || n.contains("pro 3")) { selected = d; break; }
                if (selected == null) selected = d;
            }
            if (selected == null) {
                status = "❌ Bluetooth-канал звонков не найден среди устройств связи. Android видит: " + devices(context);
                restore();
                return false;
            }
            boolean accepted = manager.setCommunicationDevice(selected);
            if (!accepted) {
                status = "❌ Android отказал в выборе " + type(selected.getType()) + " / " + name(selected);
                restore();
                return false;
            }
            active = true;
            routingRequested = true;
            final long thisSession = ++session;
            status = "Запрошено " + type(selected.getType()) + " (" + name(selected) + "). " +
                    "Проверяем, действительно ли канал подключится.";
            // Routing can take seconds. Test tone only in direct diagnostic mode.
            if (!chatGptMode) MAIN.postDelayed(() -> {
                if (active && session == thisSession) playVoiceTone();
            }, 5000);
            MAIN.postDelayed(() -> {
                if (active && session == thisSession) {
                    AudioDeviceInfo current = manager.getCommunicationDevice();
                    status = "Текущий канал: " + (current == null ? "Android не сообщил" : type(current.getType()) + " / " + name(current))
                            + (chatGptMode ? ". Слушай голос ChatGPT и проверь микрофон часов." : ". Прозвучал ли сигнал в часах?");
                }
            }, 8000);
            long duration = chatGptMode ? 90000L : 18000L;
            cleanup = () -> {
                if (session == thisSession && active) {
                    String observation = status;
                    stop();
                    status = observation + " Сессия завершена, маршрут восстановлен.";
                }
            };
            MAIN.postDelayed(cleanup, duration);
            return true;
        } catch (SecurityException ex) {
            status = "❌ Android запретил переключение аудио: " + ex.getMessage();
            restore(); return false;
        } catch (Exception ex) {
            status = "❌ Ошибка HFP: " + ex.getClass().getSimpleName() + ": " + ex.getMessage();
            restore(); return false;
        }
    }

    private static void playVoiceTone() {
        // Route test through VOICE_COMMUNICATION, not the media stream.
        // The signal is a quiet 700 Hz mono tone for 1.5 seconds.
        new Thread(() -> {
            AudioTrack track = null;
            try {
                final int rate = 16000;
                final int count = 24000;
                short[] samples = new short[count];
                for (int i = 0; i < count; i++) {
                    double fade = Math.min(1, Math.min(i / 800.0, (count - i) / 800.0));
                    samples[i] = (short) (Math.sin(2 * Math.PI * 700 * i / rate) * 4000 * fade);
                }
                int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) throw new IllegalStateException("Нет аудиобуфера");
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(rate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                        .setBufferSizeInBytes(Math.max(min, samples.length * 2))
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build();
                int written = track.write(samples, 0, samples.length);
                if (written <= 0) throw new IllegalStateException("Не удалось записать звук");
                track.play();
                Thread.sleep(2000);
            } catch (Exception ex) {
                synchronized (WatchAudioDiagnostic.class) {
                    status = "Ошибка воспроизведения сигнала: " + ex.getClass().getSimpleName();
                }
            } finally {
                if (track != null) {
                    try { track.stop(); } catch (Exception ignored) { }
                    track.release();
                }
            }
        }, "Stereoo-HFP-tone").start();
    }

    public static synchronized void stop() {
        session++;
        if (cleanup != null) { MAIN.removeCallbacks(cleanup); cleanup = null; }
        if (routingRequested || active) {
            restore();
            status = "Маршрут Bluetooth сброшен. Звук возвращён под управление Android.";
        }
        active = false;
        routingRequested = false;
    }

    private static void restore() {
        if (manager == null) return;
        try { manager.clearCommunicationDevice(); } catch (Exception ignored) { }
        try { manager.setMode(previousMode); } catch (Exception ignored) { }
        active = false;
        routingRequested = false;
    }
}
