package ru.stereoo.morkovsk

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

/**
 * The app cannot grant itself restricted settings or Accessibility permissions.
 * Every settings page below is launched by a user gesture; user approves access in Android UI.
 */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var setupState: TextView
    private lateinit var visitCount: TextView
    private lateinit var cartCount: TextView
    private lateinit var phaseText: TextView
    private lateinit var runProgress: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() { updateStatus(); handler.postDelayed(this, 1600) }
    }
    private val store by lazy { getSharedPreferences("morkovsk", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        setupState = findViewById(R.id.setupState)
        visitCount = findViewById(R.id.visitCount)
        cartCount = findViewById(R.id.cartCount)
        phaseText = findViewById(R.id.phaseText)
        runProgress = findViewById(R.id.runProgress)

        findViewById<Button>(R.id.accessibility).setOnClickListener { openAccessibilitySettings() }
        findViewById<Button>(R.id.appInfo).setOnClickListener { openAppInfo() }
        findViewById<Button>(R.id.maxLink).setOnClickListener { openMaxLink() }
        findViewById<Button>(R.id.guide).setOnClickListener {
            startActivity(Intent(this, SetupGuideActivity::class.java))
        }
        findViewById<Button>(R.id.checkAccess).setOnClickListener {
            updateStatus()
            toast(if (accessibilityEnabled()) "Служба включена ✓" else "Служба ещё не включена. Открой инструкцию.")
        }
        findViewById<Button>(R.id.openOzon).setOnClickListener { openOzon() }
        findViewById<Button>(R.id.start).setOnClickListener {
            if (MorkovService.current == null) {
                toast("Спецвозможности не подключены. Открой инструкцию и включи службу вручную")
                startActivity(Intent(this, SetupGuideActivity::class.java))
            } else {
                MorkovService.current?.startRun()
                openOzon()
            }
            updateStatus()
        }
        findViewById<Button>(R.id.continueBtn).setOnClickListener {
            MorkovService.current?.manualCartDone()
                ?: toast("Сначала включи спецвозможности")
            updateStatus()
        }
        findViewById<Button>(R.id.scan).setOnClickListener {
            MorkovService.current?.scanNow()
            updateStatus()
        }
        findViewById<Button>(R.id.diagnostic).setOnClickListener {
            val report = store.getString("diagnostic", "") ?: ""
            if (report.isBlank()) toast("Нет показаний. Запусти программу и открой Морковск.")
            else {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Морковск: диагностика", report))
                toast("Диагностика скопирована. Проверь личные данные перед отправкой.")
            }
        }
        findViewById<Button>(R.id.stop).setOnClickListener {
            MorkovService.current?.stopRun()
            updateStatus()
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(refresh)
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun accessibilityEnabled(): Boolean {
        return try {
            val manager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any { entry ->
                val service = entry.resolveInfo?.serviceInfo
                service?.packageName == packageName && service?.name == MorkovService::class.java.name
            }
        } catch (_: Exception) { MorkovService.current != null }
    }

    private fun updateStatus() {
        val enabled = accessibilityEnabled()
        val connected = MorkovService.current != null
        val running = store.getBoolean("running", false)
        val visits = store.getInt("visits", 0)
        val cart = store.getInt("cart", 0) == 1
        val phase = store.getString("phase", "Ожидание") ?: "Ожидание"
        val lastMessage = store.getString("status", "Нажми «НАЧАТЬ СБОР», когда Ozon готов.") ?: ""

        setupState.text = when {
            connected -> "✓  ДОСТУП РАЗРЕШЁН  •  МОЖНО ЗАПУСКАТЬ"
            enabled -> "◌  РАЗРЕШЕНО  •  ЖДЁМ ПОДКЛЮЧЕНИЯ СЛУЖБЫ"
            else -> "🔒  НУЖЕН ДОСТУП К СПЕЦВОЗМОЖНОСТЯМ"
        }
        setupState.setBackgroundResource(if (connected) R.drawable.bg_green_info
            else if (enabled) R.drawable.bg_yellow_info else R.drawable.bg_info)
        visitCount.text = visits.toString()
        cartCount.text = if (cart) "✓" else "—"
        phaseText.text = if (running) "🟢  Собираем • этап: $phase"
                         else "●  Автоматика остановлена • $phase"
        runProgress.visibility = if (running) android.view.View.VISIBLE else android.view.View.GONE
        status.text = buildString {
            append(if (running) "🟢  Сбор запущен" else "⏸  Сбор не запущен")
            append("\n")
            append(if (enabled) "✓ Специальные возможности: включены"
                else "🔒 Специальные возможности: выключены")
            append("\n")
            append("🚪 Посещено разделов: $visits")
            append("\n")
            append("🛒 Добавление в корзину: ")
            append(if (cart) "кнопка нажата" else "ещё не выполнено")
            append("\n\n")
            append(lastMessage)
        }
    }

    private fun openAccessibilitySettings() {
        try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        catch (_: Exception) { toast("Не удалось открыть настройки. Открой Настройки → Спецвозможности вручную.") }
    }

    private fun openAppInfo() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            })
        } catch (_: Exception) {
            toast("Не удалось открыть сведения. Открой Настройки → Приложения → Морковск Авто.")
        }
    }

    private fun openMaxLink() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://max.ru/u/f9LHodD0cOIvFUqFHruX6ZUwfTUbDrQ1kAskhE3eCqWuk0VTOJ-IygB7jsM")))
        } catch (_: Exception) {
            toast("Не удалось открыть ссылку Max")
        }
    }

    private fun openOzon() {
        val deepLink = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ozon.ru/gameapp/main?miniapp=regularDraw")).apply {
            setPackage(MorkovService.OZON)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(deepLink) }
        catch (_: Exception) {
            val launch = packageManager.getLaunchIntentForPackage(MorkovService.OZON)
            if (launch != null) {
                startActivity(launch)
                toast("Открой «Морковск» в Ozon вручную")
            } else toast("Ozon не найден. Установи официальный Ozon.")
        }
    }

    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
}
