AI Stereoo Android source package for AndroidForge

Open this Gradle project directory:
  android/CyanBridge

Gradle wrapper: 8.13
App module: :app
Debug APK task: :app:assembleDebug
Expected output: android/CyanBridge/app/build/outputs/apk/debug/app-debug.apk

The sibling heycyan-core directory is included because the Android settings file uses it as a composite build. This is source code, not a prebuilt APK. A first build requires access to the Maven repositories configured by Gradle. No API key, signing key, APK, Gradle cache, or local SDK configuration is included.
