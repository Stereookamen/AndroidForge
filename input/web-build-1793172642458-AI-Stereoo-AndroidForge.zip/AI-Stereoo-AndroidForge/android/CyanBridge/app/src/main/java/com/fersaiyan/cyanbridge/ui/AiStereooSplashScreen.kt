package com.fersaiyan.cyanbridge.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fersaiyan.cyanbridge.shared.icons.AppIcon
import com.fersaiyan.cyanbridge.shared.icons.imageVector

@Composable
internal fun AiStereooSplashScreen(isRussian: Boolean) {
    val transition = rememberInfiniteTransition(label = "splash-logo")
    val pulse = transition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "logo-pulse",
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050A16)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(168.dp)
                    .scale(pulse.value)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0x663A69FF),
                                Color(0x443A25A8),
                                Color.Transparent,
                            ),
                        ),
                        CircleShape,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = AppIcon.Glasses.imageVector(),
                    contentDescription = null,
                    modifier = Modifier.size(100.dp),
                    tint = Color(0xFF49C6FF),
                )
            }
            Spacer(Modifier.height(20.dp))
            Text(
                text = "AI Stereoo",
                style = TextStyle(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF48D5FF), Color(0xFFB25CFF)),
                    ),
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                    shadow = Shadow(color = Color(0x884C5AFF), blurRadius = 18f),
                ),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = if (isRussian) "Ваш AI-помощник в умных очках" else "Your AI assistant in smart glasses",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}
