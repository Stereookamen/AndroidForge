package com.fersaiyan.cyanbridge.localmodels.remote

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Device-local storage for the user's direct OpenAI API credential. */
object OpenAiApiKeyPrefs {
    private const val SECRET_PREFS = "openai_api_secrets"
    private const val KEY_API_KEY = "api_key"

    private fun prefs(context: Context) = EncryptedSharedPreferences.create(
        context.applicationContext,
        SECRET_PREFS,
        MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun getApiKey(context: Context): String = prefs(context)
        .getString(KEY_API_KEY, "")
        ?.trim()
        .orEmpty()

    fun isConfigured(context: Context): Boolean = getApiKey(context).isNotBlank()

    fun setApiKey(context: Context, apiKey: String) {
        prefs(context).edit().putString(KEY_API_KEY, apiKey.trim()).apply()
    }

    fun clear(context: Context) {
        prefs(context).edit().remove(KEY_API_KEY).apply()
    }
}
