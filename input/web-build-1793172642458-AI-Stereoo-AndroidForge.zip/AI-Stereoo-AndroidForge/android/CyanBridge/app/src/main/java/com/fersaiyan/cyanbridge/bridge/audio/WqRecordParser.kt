package com.fersaiyan.cyanbridge.bridge.audio

import android.util.Log

/**
 * Parser for WQ Record Protocol V2 frames used by MemoMind glasses.
 *
 * ## Frame format (partially known)
 *
 * ```text
 * ┌─────────┬──────────────┬──────────────────┬──────────────────┐
 * │ Magic   │ frameCnt     │ Payload (Opus)   │ [CRC32 optional] │
 * │ (1 byte)│ (uint?)      │ (variable)       │ (4 bytes)        │
 * └─────────┴──────────────┴──────────────────┴──────────────────┘
 * ```
 *
 * ## Known constraints (from decompiled binary analysis)
 *
 * - **Magic byte**: Value unknown — the Dart runtime constant needs BLE sniffing
 *   to confirm. Error string found in binary:
 *   `[wq_record_v2] !! magic byte mismatch: expected `
 * - **frameCnt**: Range-checked at receiver, but byte-size and endianness
 *   are unknown. Error string:
 *   `[wq_record_v2] !! frameCnt out of range: `
 * - **Payload**: Opus-encoded audio data (24000 Hz, mono, variable bitrate)
 * - **CRC32**: Optional 4-byte trailer controlled by a `needCRC` flag.
 *   When present, it covers the magic + frameCnt + payload fields.
 *
 * ## Usage
 *
 * ```kotlin
 * val parser = WqRecordParser()
 * val frame = parser.parse(bleNotificationBytes)
 * if (frame != null) {
 *     val opusBytes = frame.opusPayload
 *     // Decode with OpusDecoderWrapper
 * }
 * ```
 *
 * Tag: WqRecordParser
 */
class WqRecordParser {

    companion object {
        private const val TAG = "WqRecordParser"

        // TODO: Verify magic byte value via BLE sniffing
        // This is a placeholder — the actual value is a Dart runtime constant
        // that must be confirmed from a live capture.
        const val MAGIC_BYTE: Byte = 0xA5.toByte()

        // TODO: Verify frameCnt encoding via BLE sniffing
        // Likely uint16 LE based on range-check patterns in the binary.
        const val FRAME_CNT_SIZE = 2

        /** Smallest possible valid frame: magic(1) + frameCnt(2) = 3 bytes. */
        private const val MIN_FRAME_SIZE = 1 + FRAME_CNT_SIZE
    }

    /**
     * Parsed WQ Record Protocol V2 frame.
     *
     * @property magic The magic byte from the frame header
     * @property frameCnt Frame counter value (monotonically increasing)
     * @property opusPayload The Opus-encoded audio payload
     * @property crc32 Optional CRC32 checksum, if present in the frame
     */
    data class WqFrame(
        val magic: Byte,
        val frameCnt: Int,
        val opusPayload: ByteArray,
        val crc32: Int? = null,
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is WqFrame) return false
            return magic == other.magic &&
                frameCnt == other.frameCnt &&
                opusPayload.contentEquals(other.opusPayload) &&
                crc32 == other.crc32
        }

        override fun hashCode(): Int {
            var result = magic.hashCode()
            result = 31 * result + frameCnt
            result = 31 * result + opusPayload.contentHashCode()
            result = 31 * result + (crc32 ?: 0)
            return result
        }
    }

    /**
     * Parse a single WQ Record Protocol V2 frame from raw bytes.
     *
     * Returns `null` if:
     * - The frame is too short (< magic + frameCnt bytes)
     * - The magic byte does not match [MAGIC_BYTE]
     *   (but currently only logs the mismatch — see caveat below)
     * - There is no payload after the header
     *
     * **Caveat:** Because [MAGIC_BYTE] is a placeholder that may be wrong,
     * a magic mismatch is logged but does **not** cause the parse to fail
     * (so captured data can still be analysed). Set `strict = true` to
     * enforce magic validation after the constant is confirmed.
     *
     * @param data Raw bytes from BLE notification (characteristic 0x2020)
     * @param strict When true, return null on magic mismatch (default: false)
     * @return Parsed [WqFrame] or null if the frame is invalid
     */
    fun parse(data: ByteArray, strict: Boolean = false): WqFrame? {
        if (data.size < MIN_FRAME_SIZE) {
            Log.w(TAG, "Frame too short: ${data.size} bytes (minimum $MIN_FRAME_SIZE)")
            return null
        }

        val magic = data[0]
        if (magic != MAGIC_BYTE) {
            Log.w(
                TAG,
                "Magic byte mismatch: expected 0x${MAGIC_BYTE.toUByte().toString(16)}, " +
                    "got 0x${magic.toUByte().toString(16)}",
            )
            if (strict) {
                return null
            }
            // Non-strict: continue parsing for analysis purposes
        }

        // Parse frameCnt (assuming uint16 LE for now — TODO: verify via BLE sniffing)
        val frameCnt = when (FRAME_CNT_SIZE) {
            1 -> data[1].toInt() and 0xFF
            2 -> (data[1].toInt() and 0xFF) or ((data[2].toInt() and 0xFF) shl 8)
            4 -> (data[1].toInt() and 0xFF) or
                ((data[2].toInt() and 0xFF) shl 8) or
                ((data[3].toInt() and 0xFF) shl 16) or
                ((data[4].toInt() and 0xFF) shl 24)
            else -> {
                Log.w(TAG, "Unsupported FRAME_CNT_SIZE: $FRAME_CNT_SIZE")
                return null
            }
        }

        // Extract Opus payload (everything after magic + frameCnt)
        val payloadStart = 1 + FRAME_CNT_SIZE

        if (payloadStart >= data.size) {
            Log.w(TAG, "No payload in frame (header only)")
            return null
        }

        // TODO: Subtract 4 bytes for CRC32 if the `needCRC` flag is set
        // For now, assume no CRC32 is present.
        val payloadEnd = data.size
        val opusPayload = data.copyOfRange(payloadStart, payloadEnd)

        Log.v(
            TAG,
            "Parsed frame: magic=0x${magic.toUByte().toString(16)}, " +
                "frameCnt=$frameCnt, payloadSize=${opusPayload.size}",
        )

        return WqFrame(
            magic = magic,
            frameCnt = frameCnt,
            opusPayload = opusPayload,
        )
    }
}
