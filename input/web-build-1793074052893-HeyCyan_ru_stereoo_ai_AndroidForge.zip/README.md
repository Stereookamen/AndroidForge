# HeyCyan → Stereoo AI (AndroidForge build)

This project contains the original HeyCyan APK and a GitHub Actions workflow that rebuilds it through Apktool, updates the manifest package/version, and signs the output APK.

## Requested metadata
- Android application ID / manifest package: `ru.stereoo.ai`
- Version name: `1.0`
- Original app: HeyCyan `com.glasssutdio.wear`, version `1.0.173_20261017`

## Build with AndroidForge / GitHub Actions
1. Upload this project to a GitHub repository.
2. Open **Actions**.
3. Select **Rebuild HeyCyan as Stereoo AI**.
4. Press **Run workflow**.
5. Download artifact **Stereoo-AI-1.0-apk**. The installable file is `Stereoo_AI_1.0.apk`.

The workflow uses Apktool to rebuild the original APK and Android SDK tools to zipalign and sign it. The signing key is a temporary debug key generated for the workflow. A separately signed rebuild will not update an installed original HeyCyan in place; uninstall the original first or install side-by-side if its package ID is still different.

## Important
This is a first baseline rebuild for compatibility testing, not a guarantee that every proprietary service remains functional after changing the package ID. Some services (for example, Firebase / OAuth / vendor-side app-ID checks) can depend on the original package and signing certificate. No app logic or UI features are intentionally changed.
