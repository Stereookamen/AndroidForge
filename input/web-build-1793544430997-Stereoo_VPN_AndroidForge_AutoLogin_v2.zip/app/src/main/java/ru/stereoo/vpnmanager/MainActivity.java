package ru.stereoo.vpnmanager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.HttpAuthHandler;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebViewDatabase;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONTokener;
import org.json.JSONObject;

/**
 * Native shell for the owner's existing HTTPS VPN management cabinet.
 * No 3x-ui API credentials or private subscription URLs are embedded in the APK.
 */
public final class MainActivity extends Activity {
    private static final String SITE_URL = "https://cabinet.stereoo-vpn.ru/";
    private static final String SITE_HOST = "cabinet.stereoo-vpn.ru";
    private static final String SUBSCRIPTION_ELEMENT = "subscription-url";

    private WebView webView;
    private ProgressBar progressBar;
    private TextView subtitle;
    private boolean mainPageFailed = false;
    private SecureLoginStore loginStore;
    private boolean caddyAutoTried = false;
    private boolean panelAutoTried = false;
    private boolean panelPromptShown = false;
    private String pendingCaddyUser;
    private String pendingCaddyPassword;
    private String pendingPanelPassword;


    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        loginStore = new SecureLoginStore(this);
        getWindow().setStatusBarColor(Color.rgb(7, 21, 31));
        getWindow().setNavigationBarColor(Color.rgb(7, 21, 31));

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.rgb(7, 21, 31));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(15), dp(6), dp(8), dp(6));
        toolbar.setBackgroundResource(R.drawable.header_background);

        TextView mark = new TextView(this);
        mark.setText("S");
        mark.setTextColor(Color.rgb(6, 29, 35));
        mark.setTextSize(19);
        mark.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(makePill());
        toolbar.addView(mark, new LinearLayout.LayoutParams(dp(37), dp(37)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(11), 0, 0, 0);
        TextView heading = new TextView(this);
        heading.setText(R.string.toolbar_title);
        heading.setTextSize(16);
        heading.setTextColor(Color.WHITE);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titles.addView(heading);
        subtitle = new TextView(this);
        subtitle.setText("Кабинет управления");
        subtitle.setTextSize(11);
        subtitle.setTextColor(Color.rgb(147, 185, 197));
        titles.addView(subtitle);
        toolbar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView refresh = toolbarButton("⟳", "Обновить панель");
        toolbar.addView(refresh, new LinearLayout.LayoutParams(dp(44), dp(46)));
        refresh.setOnClickListener(v -> webView.reload());

        TextView more = toolbarButton("⋮", "Дополнительные действия");
        toolbar.addView(more, new LinearLayout.LayoutParams(dp(40), dp(46)));
        more.setOnClickListener(this::showMenu);
        layout.addView(toolbar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        FrameLayout pageContainer = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        pageContainer.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setIndeterminate(false);
        progressBar.setMax(100);
        progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(19, 218, 199)));
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3), Gravity.TOP);
        pageContainer.addView(progressBar, progressParams);
        layout.addView(pageContainer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(layout);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Required by existing VPN cabinet UI.
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        WebView.setWebContentsDebuggingEnabled(false);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int progress) {
                progressBar.setProgress(progress);
                progressBar.setVisibility(progress >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        webView.setWebViewClient(new CabinetWebViewClient());

        if (state != null && webView.restoreState(state) != null) {
            // Retain the open client page on device rotation.
        } else {
            webView.loadUrl(SITE_URL);
        }
    }

    private TextView toolbarButton(String symbol, String description) {
        TextView text = new TextView(this);
        text.setText(symbol);
        text.setTextSize(27);
        text.setTextColor(Color.rgb(218, 242, 245));
        text.setGravity(Gravity.CENTER);
        text.setContentDescription(description);
        return text;
    }

    private android.graphics.drawable.GradientDrawable makePill() {
        android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
        shape.setColor(Color.rgb(19, 218, 199));
        shape.setCornerRadius(dp(11));
        return shape;
    }

    private int dp(float pixels) {
        return Math.round(pixels * getResources().getDisplayMetrics().density);
    }

    private boolean isCabinet(Uri uri) {
        return uri != null && "https".equalsIgnoreCase(uri.getScheme())
            && SITE_HOST.equalsIgnoreCase(uri.getHost())
            && (uri.getPort() == -1 || uri.getPort() == 443);
    }

    private void showMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add("Главная");
        menu.getMenu().add("Скопировать ссылку подписки");
        menu.getMenu().add("Поделиться подпиской");
        menu.getMenu().add("Сохранить / изменить пароль кабинета");
        menu.getMenu().add("Открыть панель в браузере");
        menu.getMenu().add("Выйти и очистить сессию");
        menu.setOnMenuItemClickListener(item -> {
            String title = String.valueOf(item.getTitle());
            switch (title) {
                case "Главная": webView.loadUrl(SITE_URL); return true;
                case "Скопировать ссылку подписки": useSubscriptionLink(false); return true;
                case "Поделиться подпиской": useSubscriptionLink(true); return true;
                case "Сохранить / изменить пароль кабинета": showPanelLoginDialog(true); return true;
                case "Открыть панель в браузере": openExternal(Uri.parse(SITE_URL)); return true;
                case "Выйти и очистить сессию": confirmLogout(); return true;
                default: return false;
            }
        });
        menu.show();
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this)
            .setTitle("Выйти из кабинета?")
            .setMessage("Сохранённые пароли, локальные cookie и данные входа будут удалены. Приложение закроется. VPN-клиенты не изменятся.")
            .setNegativeButton("Отмена", (d, which) -> {})
            .setPositiveButton("Выйти", (d, which) -> {
                webView.stopLoading();
                loginStore.clear();
                CookieManager.getInstance().removeAllCookies(done -> {
                    CookieManager.getInstance().flush();
                    WebViewDatabase.getInstance(this).clearHttpAuthUsernamePassword();
                    WebStorage.getInstance().deleteAllData();
                    webView.clearCache(true);
                    webView.clearHistory();
                    finishAffinity();
                });
            }).show();
    }

    private void useSubscriptionLink(boolean share) {
        if (!isCabinet(Uri.parse(webView.getUrl() == null ? "" : webView.getUrl()))) {
            Toast.makeText(this, "Открой страницу клиента в кабинете", Toast.LENGTH_SHORT).show();
            return;
        }
        String js = "(function(){var e=document.getElementById('" + SUBSCRIPTION_ELEMENT + "');return e ? e.value : '';})()";
        webView.evaluateJavascript(js, response -> {
            try {
                Object parsed = new JSONTokener(response).nextValue();
                String link = parsed instanceof String ? (String) parsed : "";
                Uri uri = Uri.parse(link);
                if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) {
                    Toast.makeText(this, "Сначала открой «Ссылка подписки» у клиента", Toast.LENGTH_LONG).show();
                    return;
                }
                if (share) {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_SUBJECT, "Подключение VPN");
                    intent.putExtra(Intent.EXTRA_TEXT,
                        "Ссылка для подключения VPN. Не нужно по ней переходить. Просто скопируйте её и вставьте в программу, которую вы используете в своём телефоне для VPN.\n\n" + link);
                    startActivity(Intent.createChooser(intent, "Отправить подписку"));
                } else {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    clipboard.setPrimaryClip(ClipData.newPlainText("VPN-подписка", link));
                    Toast.makeText(this, "Ссылка скопирована", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception ex) {
                Toast.makeText(this, "Не удалось прочитать ссылку", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ex) {
            Toast.makeText(this, "Нет приложения для открытия ссылки", Toast.LENGTH_SHORT).show();
        }
    }

    private void showCaddyDialog(HttpAuthHandler handler, String suggestedUser) {
        LinearLayout content = makeCredentialsForm();
        EditText username = new EditText(this);
        username.setSingleLine(true);
        username.setHint("Логин Caddy");
        username.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
        username.setText(suggestedUser);
        EditText password = makePasswordField("Пароль Caddy");
        CheckBox remember = new CheckBox(this);
        remember.setText("Запомнить на этом телефоне");
        remember.setChecked(true);
        content.addView(username);
        content.addView(password);
        content.addView(remember);
        new AlertDialog.Builder(this)
            .setTitle("Защищённый вход Caddy")
            .setMessage("Введи данные один раз. Пароль сохраняется зашифрованным на телефоне.")
            .setView(content)
            .setCancelable(false)
            .setPositiveButton("Войти", (dialog, which) -> {
                String u = username.getText().toString().trim();
                String p = password.getText().toString();
                // Store only after a successfully loaded page, not blindly on submit.
                pendingCaddyUser = remember.isChecked() ? u : null;
                pendingCaddyPassword = remember.isChecked() ? p : null;
                caddyAutoTried = true;
                handler.proceed(u, p);
            })
            .setNegativeButton("Отмена", (dialog, which) -> handler.cancel())
            .show();
    }

    private LinearLayout makeCredentialsForm() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(8), dp(24), 0);
        return box;
    }

    private EditText makePasswordField(String hint) {
        EditText password = new EditText(this);
        password.setSingleLine(true);
        password.setHint(hint);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return password;
    }

    private void handlePanelLoginPage() {
        if (panelAutoTried) {
            panelAutoTried = false;
            pendingPanelPassword = null;
            loginStore.removePanel();
            Toast.makeText(this, "Пароль панели не подошёл. Введи новый.", Toast.LENGTH_LONG).show();
            panelPromptShown = false;
        }
        String password = loginStore.getPanel();
        if (password != null) {
            submitPanelPassword(password, false);
        } else if (!panelPromptShown) {
            showPanelLoginDialog(false);
        }
    }

    private void showPanelLoginDialog(boolean fromMenu) {
        if (!fromMenu) panelPromptShown = true;
        LinearLayout box = makeCredentialsForm();
        EditText password = makePasswordField("Пароль Stereoo VPN Manager");
        CheckBox remember = new CheckBox(this);
        remember.setText("Запомнить и входить автоматически");
        remember.setChecked(true);
        box.addView(password);
        box.addView(remember);
        new AlertDialog.Builder(this)
            .setTitle("Вход в VPN Manager")
            .setMessage("Данные сохраняются зашифрованными на этом устройстве, не в APK.")
            .setView(box)
            .setPositiveButton("Продолжить", (dialog, which) -> {
                String p = password.getText().toString();
                if (p.isEmpty()) return;
                if (fromMenu && !isPanelLoginPage()) {
                    if (remember.isChecked()) {
                        loginStore.putPanel(p);
                        Toast.makeText(this, "Пароль сохранён. При следующем входе подставится сам.", Toast.LENGTH_LONG).show();
                    } else {
                        loginStore.removePanel();
                        Toast.makeText(this, "Автовход отключён", Toast.LENGTH_SHORT).show();
                    }
                    return;
                }
                submitPanelPassword(p, remember.isChecked());
            })
            .setNegativeButton("Отмена", (dialog, which) -> {})
            .show();
    }

    private boolean isPanelLoginPage() {
        return isCabinet(Uri.parse(webView.getUrl() == null ? "" : webView.getUrl()))
            && "/login".equals(Uri.parse(webView.getUrl()).getPath());
    }

    private void submitPanelPassword(String password, boolean rememberAfterSuccess) {
        if (!isPanelLoginPage()) return;
        panelAutoTried = true;
        pendingPanelPassword = rememberAfterSuccess ? password : null;
        // Do not embed password directly in HTML. Use safe JS string escaping.
        String js = "(function(){var p=document.querySelector('input[name=\"password\"]');"
            + "if(!p||!p.form)return false;"
            + "p.value=" + JSONObject.quote(password) + ";"
            + "p.dispatchEvent(new Event('input',{bubbles:true}));"
            + "var b=p.form.querySelector('button[type=submit]');"
            + "if(b)b.click();else p.form.requestSubmit();return true;})()";
        webView.evaluateJavascript(js, result -> {
            if (!"true".equals(result)) {
                panelAutoTried = false;
                pendingPanelPassword = null;
                Toast.makeText(this, "Не найдена форма входа. Введи пароль на странице.", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        webView.saveState(state);
        super.onSaveInstanceState(state);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    private final class CabinetWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if ("stereoovpn".equals(uri.getScheme())) {
                if (request.isForMainFrame() && isCabinet(Uri.parse(view.getUrl() == null ? "" : view.getUrl()))) {
                    if ("copy".equals(uri.getHost())) useSubscriptionLink(false);
                    if ("share".equals(uri.getHost())) useSubscriptionLink(true);
                }
                return true;
            }
            if (isCabinet(uri)) return false;
            if (!request.isForMainFrame()) return true;
            String scheme = uri.getScheme();
            if ("https".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)) {
                openExternal(uri);
            }
            return true; // No foreign pages inside the privileged cabinet WebView.
        }

        @Override
        public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm) {
            if (!SITE_HOST.equalsIgnoreCase(host)) {
                handler.cancel();
                return;
            }
            // Credentials are never hard-coded in the APK. Only use on the dedicated host.
            String[] stored = loginStore.getCaddy();
            if (!caddyAutoTried && stored != null) {
                caddyAutoTried = true;
                handler.proceed(stored[0], stored[1]);
                return;
            }
            if (caddyAutoTried && stored != null) {
                // A second challenge after auto-login usually means the password changed.
                loginStore.removeCaddy();
                Toast.makeText(MainActivity.this, "Сохранённый пароль Caddy не подошёл", Toast.LENGTH_LONG).show();
            }
            showCaddyDialog(handler, stored == null ? "stereoo" : stored[0]);
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel(); // Never bypass HTTPS certificate errors for an admin panel.
            Toast.makeText(MainActivity.this, "Ошибка сертификата HTTPS", Toast.LENGTH_LONG).show();
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) {
                mainPageFailed = true;
                subtitle.setText("Нет соединения • нажми ⟳");
            }
        }

        @Override
        public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                        android.webkit.WebResourceResponse response) {
            if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                mainPageFailed = true;
                if (response.getStatusCode() == 401) {
                    pendingCaddyUser = null;
                    pendingCaddyPassword = null;
                }
            }
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            mainPageFailed = false;
            subtitle.setText("Подключение…");
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (!mainPageFailed) subtitle.setText("cabinet.stereoo-vpn.ru");
            Uri uri = Uri.parse(url);
            if (!isCabinet(uri)) return;
            if (!mainPageFailed) {
                if (pendingCaddyUser != null) {
                    loginStore.putCaddy(pendingCaddyUser, pendingCaddyPassword);
                    pendingCaddyUser = null;
                    pendingCaddyPassword = null;
                }
                caddyAutoTried = false; // A later genuine auth challenge may use the saved password.
            }
            if ("/login".equals(uri.getPath())) {
                handlePanelLoginPage();
                return;
            }
            if (pendingPanelPassword != null && !mainPageFailed) {
                loginStore.putPanel(pendingPanelPassword);
                pendingPanelPassword = null;
            }
            panelAutoTried = false;
            panelPromptShown = false;
            // The existing website's share.js hides Share when navigator.share is absent in WebView.
            // Intercept only those two existing buttons. No broad JavaScript-to-native bridge.
            String hooks = "(function(){"
                + "if(window.__stereooNativeHooks) return;window.__stereooNativeHooks=true;"
                + "document.addEventListener('click',function(e){"
                + "var t=e.target&&e.target.closest&&e.target.closest('#copy-subscription,#share-subscription');"
                + "if(!t)return;e.preventDefault();e.stopImmediatePropagation();"
                + "window.location.href=t.id==='copy-subscription'?'stereoovpn://copy':'stereoovpn://share';"
                + "},true);"
                + "var s=document.getElementById('share-subscription');if(s)s.hidden=false;"
                + "})();";
            view.evaluateJavascript(hooks, null);
        }
    }
}
