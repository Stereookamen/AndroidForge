package ru.stereoo.vpnmanager;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Device-local, AES-GCM encrypted credentials. The AES key stays in Android Keystore. */
final class SecureLoginStore {
    private static final String PREFS = "secure_local_login_v2";
    private static final String ALIAS = "stereoo_vpn_aes_login_v2";
    private static final String CADDY = "caddy";
    private static final String PANEL = "panel";
    private final SharedPreferences prefs;

    SecureLoginStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(ALIAS)) return (SecretKey) store.getKey(ALIAS, null);
        KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return gen.generateKey();
    }

    private void save(String name, String raw) {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            cipher.updateAAD(name.getBytes(StandardCharsets.UTF_8));
            byte[] iv = cipher.getIV();
            byte[] encrypted = cipher.doFinal(raw.getBytes(StandardCharsets.UTF_8));
            String packed = Base64.encodeToString(iv, Base64.NO_WRAP) + ":"
                    + Base64.encodeToString(encrypted, Base64.NO_WRAP);
            prefs.edit().putString(name, packed).apply();
        } catch (Exception e) {
            // Never silently store plaintext if encryption is unavailable.
            prefs.edit().remove(name).apply();
        }
    }

    private String load(String name) {
        String packed = prefs.getString(name, null);
        if (packed == null) return null;
        try {
            String[] parts = packed.split(":", 2);
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] encrypted = Base64.decode(parts[1], Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            cipher.updateAAD(name.getBytes(StandardCharsets.UTF_8));
            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception e) {
            prefs.edit().remove(name).apply();
            return null;
        }
    }

    void putCaddy(String username, String password) {
        try {
            JSONObject object = new JSONObject();
            object.put("user", username);
            object.put("password", password);
            save(CADDY, object.toString());
        } catch (Exception ignored) { }
    }

    String[] getCaddy() {
        String saved = load(CADDY);
        if (saved == null) return null;
        try {
            JSONObject obj = new JSONObject(saved);
            return new String[]{obj.getString("user"), obj.getString("password")};
        } catch (Exception e) { return null; }
    }

    void putPanel(String password) { save(PANEL, password); }
    String getPanel() { return load(PANEL); }
    void removeCaddy() { prefs.edit().remove(CADDY).apply(); }
    void removePanel() { prefs.edit().remove(PANEL).apply(); }
    void clear() { prefs.edit().clear().commit(); }
}
