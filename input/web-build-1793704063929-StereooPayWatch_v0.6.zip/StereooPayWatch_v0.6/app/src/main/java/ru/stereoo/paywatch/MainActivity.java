package ru.stereoo.paywatch;

import android.app.Activity;
import android.Manifest;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Standalone watch control panel for the unmodified, separately installed Mir Pay.
 * No card information is requested, processed or stored by this app.
 */
public final class MainActivity extends Activity {
    private static final String MIRPAY = "ru.nspk.mirpay";
    private static final String PREFS = "stereoo_pay_settings";
    private static final String CAMERA_GUARD = "deny_camera_dialogs";
    // A dark, high-contrast look designed for a circular 227dp-class screen.
    private static final int BG = Color.rgb(5, 15, 29);
    private static final int PANEL = Color.rgb(15, 35, 55);
    private static final int SECONDARY = Color.rgb(23, 43, 65);
    private static final int MINT = Color.rgb(64, 232, 218);
    private static final int BLUE = Color.rgb(84, 128, 245);
    private static final int TEXT = Color.rgb(244, 251, 255);
    private static final int MUTED = Color.rgb(160, 189, 210);
    private static final int WARNING = Color.rgb(255, 170, 126);
    private LinearLayout content;
    private boolean showDiagnostics = false;
    private boolean showExtras = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        drawHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (content != null && !showDiagnostics) drawHome();
    }

    @Override
    public void onBackPressed() {
        if (showDiagnostics) {
            showDiagnostics = false;
            drawHome();
        } else {
            super.onBackPressed();
        }
    }

    private void initializeScreen() {
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setVerticalScrollBarEnabled(false);
        scroller.setBackgroundColor(BG);
        scroller.setClipToPadding(false);
        scroller.setPadding(dp(21), dp(14), dp(21), dp(24));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(0, dp(10), 0, dp(18));
        scroller.addView(content);
        setContentView(scroller);
    }

    private void drawHome() {
        showDiagnostics = false;
        initializeScreen();

        // Original vector brand mark, not a Mir Pay logo or payment credential.
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        logo.setContentDescription("Значок Stereoo Pay");
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(78), dp(78));
        iconParams.bottomMargin = dp(3);
        content.addView(logo, iconParams);

        centerText("S T E R E O O", 10, MINT, true, 3);
        centerText("PAY WATCH", 23, TEXT, true, 5);
        centerText("Помощник Mir Pay на часах", 11, MUTED, false, 14);

        LinearLayout status = container(PANEL);
        String version = mirPayVersion();
        statusLine(status, "●", version == null ? "Mir Pay не установлен" : "Mir Pay  " + version,
                version == null ? WARNING : MINT);
        NfcAdapter nfc = NfcAdapter.getDefaultAdapter(this);
        statusLine(status, "◉", nfc == null ? "NFC не обнаружен" :
                (nfc.isEnabled() ? "NFC включён" : "NFC выключен"),
                nfc != null && nfc.isEnabled() ? MINT : WARNING);
        boolean cameraAllowed = getPackageManager().checkPermission(
                Manifest.permission.CAMERA, MIRPAY) == PackageManager.PERMISSION_GRANTED;
        statusLine(status, "◈", cameraAllowed ? "Камера: доступ разрешён" : "Камера: доступ не выдан",
                cameraAllowed ? WARNING : MINT);

        LinearLayout densityStatus = container(PANEL);
        statusLine(densityStatus, "◷", "DPI сейчас: " + DensityController.currentDpi(this)
                + (DensityController.isActive(this) ? "  •  Режим 160 активен" : ""), MINT);
        statusLine(densityStatus, "⚿", DensityController.granted(this)
                ? "ADB-разрешение: выдано" : "ADB-разрешение: требуется", 
                DensityController.granted(this) ? MINT : WARNING);

        prominentButton("▶", "MIR PAY • DPI 160", "Сначала масштаб, потом запуск", true,
                () -> launchMirPay(false));
        prominentButton("↶", "ВОССТАНОВИТЬ DPI", "Вернуть исходный масштаб часов", false,
                this::restoreDensity);
        prominentButton("⌁", "ПУЛЬТ УПРАВЛЕНИЯ", "Курсор, кнопки и прокрутка", false,
                this::openAccessibilitySettings);

        sectionHeader("АВТОМАТИКА И ЗАЩИТА");
        button(DensityController.autoEnabled(this) ? "✓  АВТО-DPI: ВКЛ" : "○  АВТО-DPI: ВЫКЛ",
                false, this::toggleAutoDpi);
        button("РАЗРЕШЕНИЕ / ИНСТРУКЦИЯ", false, this::showDpiInfo);
        button(cameraGuardEnabled() ? "✓  АВТООТКАЗ КАМЕРЫ: ВКЛ" : "○  АВТООТКАЗ КАМЕРЫ: ВЫКЛ",
                false, this::toggleCameraGuard);
        button(showExtras ? "−  СКРЫТЬ ДОПОЛНИТЕЛЬНО" : "+  ДОПОЛНИТЕЛЬНО", false, () -> {
            showExtras = !showExtras;
            drawHome();
        });
        if (showExtras) {
            button("ЗАПРЕТ КАМЕРЫ / ADB", false, this::showCameraInfo);
            button("НАСТРОЙКИ ОПЛАТЫ", false, this::openPaymentSettings);
            button("НАСТРОЙКИ MIR PAY", false, this::openMirPaySettings);
            button("ДИАГНОСТИКА ЧАСОВ", false, () -> {
                showDiagnostics = true;
                drawDiagnostics();
            });
        }
        centerText("160 DPI на время Mir Pay • данные карт не читаются", 10, MUTED, false, 7);
        centerText("Жданов Александр   •   0.6", 10, MUTED, false, 2);
    }

    private void statusLine(LinearLayout parent, String glyph, String value, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView dot = text(glyph, 14, color, true);
        dot.setGravity(Gravity.CENTER);
        row.addView(dot, new LinearLayout.LayoutParams(dp(24), dp(25)));
        TextView title = text(value, 11, TEXT, false);
        title.setMaxLines(2);
        row.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.bottomMargin = dp(3);
        parent.addView(row, rp);
    }

    private void sectionHeader(String value) {
        TextView tv = text(value, 10, MUTED, true);
        tv.setGravity(Gravity.CENTER);
        tv.setLetterSpacing(0.10f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        lp.bottomMargin = dp(9);
        content.addView(tv, lp);
    }

    private void prominentButton(String glyph, String title, String subtitle,
                                 boolean primary, Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), dp(8), dp(10), dp(8));
        row.setMinimumHeight(dp(66));
        row.setBackground(buttonBackground(primary));
        row.setClickable(true);
        row.setFocusable(true);
        row.setContentDescription(title + ". " + subtitle);
        row.setOnClickListener(v -> action.run());

        TextView icon = text(glyph, 19, primary ? BG : MINT, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(background(primary ? 0x44FFFFFF : PANEL, 16));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(38), dp(38));
        ip.rightMargin = dp(8);
        row.addView(icon, ip);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView top = text(title, 11, primary ? BG : TEXT, true);
        top.setMaxLines(2);
        titles.addView(top);
        TextView bottom = text(subtitle, 10, primary ? Color.rgb(14, 73, 77) : MUTED, false);
        bottom.setMaxLines(2);
        titles.addView(bottom);
        row.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));

        TextView arrow = text("›", 22, primary ? BG : MINT, true);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(dp(15), -2));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        content.addView(row, lp);
    }

    private GradientDrawable buttonBackground(boolean primary) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                primary ? new int[]{MINT, 0xFF63D9FA} : new int[]{PANEL, SECONDARY});
        d.setCornerRadius(dp(20));
        if (!primary) d.setStroke(dp(1), 0xFF244A60);
        return d;
    }

    private void drawDiagnostics() {
        initializeScreen();
        button("‹  НАЗАД", false, () -> {
            showDiagnostics = false;
            drawHome();
        });
        centerText("ДИАГНОСТИКА", 21, TEXT, true, 10);
        centerText("Проверка возможностей часов", 11, MUTED, false, 12);
        LinearLayout card = container(PANEL);
        String report = diagnosticReport();
        String[] lines = report.split("\\n");
        for (String line : lines) {
            label(card, line, 12, line.contains("нет") || line.contains("выключен") ?
                    Color.rgb(255, 183, 153) : TEXT, false, 9);
        }
        button("СКОПИРОВАТЬ ОТЧЁТ", true, () -> {
            ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cb != null) {
                cb.setPrimaryClip(ClipData.newPlainText("Stereoo Pay diagnosis", report));
                toast("Отчёт скопирован. Банковских данных в нём нет.");
            }
        });
        button("ПАМЯТКА ПО DPI", false, this::showDpiInfo);
        button("КАК ЗАПРЕТИТЬ КАМЕРУ", false, this::showCameraInfo);
        centerText("DPI переключается на всех экранах часов, а не только внутри Mir Pay. " +
                "При сбое автоматического возврата нажми «ВОССТАНОВИТЬ DPI».",
                11, MUTED, false, 10);
    }

    private String diagnosticReport() {
        String version = mirPayVersion();
        boolean found = version != null;
        boolean launchable = found && getPackageManager().getLaunchIntentForPackage(MIRPAY) != null;
        NfcAdapter nfc = NfcAdapter.getDefaultAdapter(this);
        boolean hce = getPackageManager().hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION);
        int dpi = getResources().getDisplayMetrics().densityDpi;
        return "Устройство: " + Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                "Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n" +
                "Mir Pay: " + (found ? version : "не установлен") + "\n" +
                "Запуск Mir Pay: " + (launchable ? "доступен" : "недоступен") + "\n" +
                "NFC: " + (nfc == null ? "нет модуля" : (nfc.isEnabled() ? "включён" : "выключен")) + "\n" +
                "NFC HCE: " + (hce ? "есть" : "нет") + "\n" +
                "Камера Mir Pay: " + (
                        getPackageManager().checkPermission(Manifest.permission.CAMERA, MIRPAY) ==
                                PackageManager.PERMISSION_GRANTED ? "РАЗРЕШЕНА" : "не разрешена") + "\n" +
                "Автоотказ камеры: " + (cameraGuardEnabled() ? "включен" : "выключен") + "\n" +
                "DPI интерфейса: " + dpi + "\n" +
                "DPI системный: " + DensityController.currentDpi(this) + "\n" +
                "DPI заводской: " + DensityController.initialDpi(this) + "\n" +
                "DPI сохранённый: " + DensityController.priorDpi(this) + "\n" +
                "Разрешение: " + (DensityController.granted(this) ? "выдано" : "нет") + "\n" +
                "Режим активен: " + DensityController.isActive(this) + "\n" +
                "Авто-DPI: " + DensityController.autoEnabled(this) + "\n" +
                "Последнее действие: " + DensityController.lastResult(this) + "\n" +
                "Важно: возможность оплаты не подтверждена.";
    }

    private String mirPayVersion() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(MIRPAY, 0);
            return info.versionName == null ? "определить не удалось" : info.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private void launchMirPay(boolean cards) {
        if (mirPayVersion() == null) {
            toast("Mir Pay не найден на часах");
            return;
        }
        Intent launch = getPackageManager().getLaunchIntentForPackage(MIRPAY);
        if (launch == null) {
            toast("Нет доступного экрана запуска Mir Pay");
            return;
        }
        // Apply 160 BEFORE opening Mir Pay. If privilege/API is missing, do
        // not launch at incompatible density by accident.
        if (!DensityController.activate(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Режим 160 не включился")
                    .setMessage(DensityController.lastResult(this) +
                            "\n\nРазрешение ADB выдаётся один раз. " +
                            "Посмотри инструкцию в настройках DPI.")
                    .setPositiveButton("ИНСТРУКЦИЯ", (d, w) -> showDpiInfo())
                    .setNegativeButton("ОТМЕНА", null).show();
            return;
        }
        try {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // Allow the system display configuration to settle.
            final Context applicationContext = getApplicationContext();
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try {
                    applicationContext.startActivity(launch);
                } catch (ActivityNotFoundException | SecurityException e) {
                    Toast.makeText(applicationContext, "Запуск Mir Pay не удался. Восстанови DPI.",
                            Toast.LENGTH_LONG).show();
                }
            }, 650);
        } catch (RuntimeException e) {
            toast("Запуск Mir Pay не удался. Восстанови DPI.");
        }
    }

    private void restoreDensity() {
        boolean ok = DensityController.restore(this);
        toast(DensityController.lastResult(this));
        if (ok) new Handler(Looper.getMainLooper()).postDelayed(this::drawHome, 450);
    }

    private void toggleAutoDpi() {
        boolean enabled = !DensityController.autoEnabled(this);
        DensityController.setAutoEnabled(this, enabled);
        toast(enabled ? "Авто-DPI включён (нужна служба спецвозможностей)" :
                "Авто-DPI выключен. Ручной запуск в 160 работает.");
        drawHome();
    }

    private void openAccessibilitySettings() {
        new AlertDialog.Builder(this)
                .setTitle("Управление кнопками")
                .setMessage("1. В специальных возможностях включи службу «Stereoo Pay — помощь с кнопками».\n\n" +
                        "2. Запускай Mir Pay через Stereoo Pay (режим 160). Появится бирюзовая кнопка управления.\n\n" +
                        "3. В пульте можно искать доступные кнопки или пользоваться ручным курсором.\n\n" +
                        "Если Mir Pay скрывает элементы от спецвозможностей, автоматический поиск может не сработать. " +
                        "Банковские реквизиты приложение не читает, не вводит и не сохраняет.")
                .setNegativeButton("ОТМЕНА", (d, w) -> d.dismiss())
                .setPositiveButton("ОТКРЫТЬ", (d, w) -> {
                    if (!tryOpen(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                        toast("Не удалось открыть настройки. Зайди в Спец. возможности вручную.");
                }).show();
    }

    private void openPaymentSettings() {
        // Different Wear OS firmware versions expose different NFC/payment screens.
        if (tryOpen(new Intent("android.settings.NFC_PAYMENT_SETTINGS"))) return;
        if (tryOpen(new Intent(Settings.ACTION_NFC_SETTINGS))) return;
        if (tryOpen(new Intent(Settings.ACTION_WIRELESS_SETTINGS))) return;
        toast("Системные настройки NFC недоступны на этой прошивке");
    }

    private void openMirPaySettings() {
        if (mirPayVersion() == null) {
            toast("Mir Pay не найден на часах");
            return;
        }
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + MIRPAY));
        if (!tryOpen(intent)) toast("Системная страница Mir Pay недоступна");
    }

    private boolean tryOpen(Intent intent) {
        try {
            startActivity(intent);
            return true;
        } catch (ActivityNotFoundException | SecurityException e) {
            return false;
        }
    }

    private boolean cameraGuardEnabled() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(CAMERA_GUARD, true);
    }

    private void toggleCameraGuard() {
        boolean next = !cameraGuardEnabled();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(CAMERA_GUARD, next).apply();
        toast(next ? "Автоотказ камеры включён (нужна служба спецвозможностей)" :
                "Автоотказ камеры выключен");
        drawHome();
    }

    private void showCameraInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Камера Mir Pay")
                .setMessage("Автоотказ: служба специальных возможностей пытается нажать " +
                        "«Запретить» ТОЛЬКО в системном запросе камеры для Mir Pay. " +
                        "Не может полностью запретить выдачу разрешения через настройки.\n\n" +
                        "Чтобы сильнее ограничить камеру, в Bugjaeger (ADB Shell часов) выполни:\n\n" +
                        "pm revoke ru.nspk.mirpay android.permission.CAMERA\n\n" +
                        "appops set ru.nspk.mirpay CAMERA ignore\n\n" +
                        "Проверить: appops get ru.nspk.mirpay CAMERA\n\n" +
                        "Этот запрет может повлиять на сканирование карты камерой, но не должен " +
                        "мешать ручному вводу. Сам по себе он не устраняет вылеты Mir Pay.")
                .setNegativeButton("ЗАКРЫТЬ", (d, w) -> d.dismiss())
                .setPositiveButton("НАСТРОЙКИ MIR PAY", (d, w) -> openMirPaySettings())
                .show();
    }

    private void showDpiInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Автоматический DPI 160")
                .setMessage("1. Установи Stereoo Pay 0.6 на часы.\n\n" +
                        "2. На телефоне открой Bugjaeger → Shell часов. Введи ОДНУ команду:\n\n" +
                        "pm grant ru.stereoo.paywatch android.permission.WRITE_SECURE_SETTINGS\n\n" +
                        "3. В часах включи службу специальных возможностей Stereoo Pay.\n\n" +
                        "4. Открывай Mir Pay кнопкой «MIR PAY • DPI 160». " +
                        "Исходный DPI сохраняется до переключения. После выхода служба " +
                        "попытается вернуть его автоматически.\n\n" +
                        "Если DPI не восстановился, открой Stereoo Pay → «ВОССТАНОВИТЬ DPI». " +
                        "Резервная команда в Bugjaeger:\nwm density reset\n\n" +
                        "ВНИМАНИЕ: сброс возвращает заводской DPI, а не установленный вручную. " +
                        "Для ручного значения введи wm density ЧИСЛО.\n\n" +
                        "Способ использует закрытый интерфейс Android и может быть заблокирован " +
                        "прошивкой. Если появится ошибка, смотри «Диагностика часов».")
                .setPositiveButton("ПОНЯТНО", null).show();
    }

    private LinearLayout container(int color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(14), dp(17), dp(13));
        card.setBackground(background(color, 20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        content.addView(card, lp);
        return card;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(size);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setIncludeFontPadding(true);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return tv;
    }

    private void label(LinearLayout parent, String value, int size, int color,
                       boolean bold, int bottomMarginDp) {
        TextView tv = text(value, size, color, bold);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(bottomMarginDp);
        parent.addView(tv, lp);
    }

    private void centerText(String value, int size, int color, boolean bold, int bottomMarginDp) {
        TextView tv = text(value, size, color, bold);
        tv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(bottomMarginDp);
        content.addView(tv, lp);
    }

    private void button(String value, boolean primary, Runnable handler) {
        TextView b = text(value, primary ? 13 : 11, primary ? BG : TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(primary ? 53 : 45));
        b.setPadding(dp(10), dp(7), dp(10), dp(7));
        b.setBackground(buttonBackground(primary));
        b.setClickable(true);
        b.setFocusable(true);
        b.setOnClickListener(view -> handler.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(9);
        content.addView(b, lp);
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    private int dp(float value) {
        return (int) (getResources().getDisplayMetrics().density * value + 0.5f);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
