package ru.stereoo.paywatch;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.util.Log;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Experimental default-display density switcher for Wear OS / Android 9.
 * It never executes shell commands and never modifies Mir Pay.
 * WRITE_SECURE_SETTINGS must be granted by the owner once through ADB.
 * Calls Android's internal IWindowManager interface via reflection; OEM or
 * future versions can block it. Every failure is reported without pretending
 * that writing the Settings database changes the display immediately.
 */
public final class DensityController {
    public static final int MIR_DPI = 160;
    public static final String PERMISSION = "android.permission.WRITE_SECURE_SETTINGS";
    private static final String TAG = "StereooDpi";
    private static final String PREFS = "stereoo_dpi_v06";
    private static final String ACTIVE = "session_active";
    private static final String PREVIOUS = "previous_dpi";
    private static final String PREVIOUS_OVERRIDE = "previous_override";
    private static final String SEEN = "mirpay_seen";
    private static final String AUTO = "auto_density_enabled";
    private static final String LAST_RESULT = "last_result";
    private static final String NONE = "(no override)";

    private DensityController() { }

    private static SharedPreferences preferences(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean granted(Context c) {
        return Build.VERSION.SDK_INT >= 23
                && c.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean autoEnabled(Context c) {
        return preferences(c).getBoolean(AUTO, true);
    }

    public static void setAutoEnabled(Context c, boolean enabled) {
        preferences(c).edit().putBoolean(AUTO, enabled).apply();
    }

    public static boolean isActive(Context c) {
        return preferences(c).getBoolean(ACTIVE, false);
    }

    public static boolean hasSeenMirPay(Context c) {
        return preferences(c).getBoolean(SEEN, false);
    }

    public static void markMirPaySeen(Context c) {
        if (isActive(c)) preferences(c).edit().putBoolean(SEEN, true).apply();
    }

    public static String lastResult(Context c) {
        return preferences(c).getString(LAST_RESULT, "Проверка DPI ещё не выполнялась");
    }

    private static void setResult(Context c, String message) {
        preferences(c).edit().putString(LAST_RESULT, message).apply();
        Log.i(TAG, message);
    }

    private static int userId() {
        // Wear OS uses the primary Android user (0). Deriving it from the UID
        // avoids the hidden UserHandle.getIdentifier() API.
        return Process.myUid() / 100000;
    }

    /** Returns system window manager Binder interface, not the public WindowManager facade. */
    private static Object windowManagerService() throws Exception {
        try {
            Class<?> global = Class.forName("android.view.WindowManagerGlobal");
            Method getter = global.getDeclaredMethod("getWindowManagerService");
            getter.setAccessible(true);
            Object service = getter.invoke(null);
            if (service != null) return service;
        } catch (ReflectiveOperationException | SecurityException ignored) {
            // Alternate path through Android's service manager.
        }
        Class<?> serviceManager = Class.forName("android.os.ServiceManager");
        Method getService = serviceManager.getDeclaredMethod("getService", String.class);
        getService.setAccessible(true);
        Object binder = getService.invoke(null, "window");
        Class<?> binderClass = Class.forName("android.os.IBinder");
        Class<?> stub = Class.forName("android.view.IWindowManager$Stub");
        Method asInterface = stub.getDeclaredMethod("asInterface", binderClass);
        asInterface.setAccessible(true);
        Object interfaceObject = asInterface.invoke(null, binder);
        if (interfaceObject == null) throw new IllegalStateException("Служба window недоступна");
        return interfaceObject;
    }

    private static Object invokeWindow(String operation, Class<?>[] signature,
                                       Object... args) throws Exception {
        Object wm = windowManagerService();
        Class<?> iwm = Class.forName("android.view.IWindowManager");
        Method method = iwm.getMethod(operation, signature);
        method.setAccessible(true);
        try {
            return method.invoke(wm, args);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof Exception) throw (Exception) cause;
            throw e;
        }
    }

    private static int baseDisplayDensity() throws Exception {
        Object o = invokeWindow("getBaseDisplayDensity", new Class[]{int.class}, 0);
        if (!(o instanceof Integer)) throw new IllegalStateException("Нет данных о DPI дисплея");
        return (Integer) o;
    }

    private static int initialDisplayDensity() throws Exception {
        Object o = invokeWindow("getInitialDisplayDensity", new Class[]{int.class}, 0);
        if (!(o instanceof Integer)) throw new IllegalStateException("Нет заводского DPI");
        return (Integer) o;
    }

    public static int currentDpi(Context c) {
        try {
            int v = baseDisplayDensity();
            if (v > 0) return v;
        } catch (Exception | LinkageError ignored) { }
        return c.getResources().getDisplayMetrics().densityDpi;
    }

    public static int initialDpi(Context c) {
        try {
            int v = initialDisplayDensity();
            if (v > 0) return v;
        } catch (Exception | LinkageError ignored) { }
        return -1;
    }

    public static int priorDpi(Context c) {
        return preferences(c).getInt(PREVIOUS, -1);
    }

    private static void set(int density) throws Exception {
        invokeWindow("setForcedDisplayDensityForUser",
                new Class[]{int.class, int.class, int.class}, 0, density, userId());
    }

    private static void reset() throws Exception {
        invokeWindow("clearForcedDisplayDensityForUser",
                new Class[]{int.class, int.class}, 0, userId());
    }

    public static synchronized boolean activate(Context c) {
        if (!granted(c)) {
            setResult(c, "Нет разрешения WRITE_SECURE_SETTINGS. Выдай его через Bugjaeger.");
            return false;
        }
        if (isActive(c)) {
            try {
                if (baseDisplayDensity() != MIR_DPI) set(MIR_DPI);
                setResult(c, "Режим Mir Pay активен, DPI = " + MIR_DPI);
                return true;
            } catch (Exception | LinkageError e) {
                setResult(c, "Не удалось применить DPI: " + error(e));
                return false;
            }
        }
        int before;
        try {
            before = baseDisplayDensity();
        } catch (Exception | LinkageError e) {
            setResult(c, "Нельзя определить текущий DPI: " + error(e));
            return false;
        }
        if (before <= 0) {
            setResult(c, "Не удалось прочитать исходный DPI");
            return false;
        }
        String override;
        try {
            override = Settings.Secure.getString(c.getContentResolver(), "display_density_forced");
        } catch (RuntimeException e) {
            override = null;
        }
        SharedPreferences p = preferences(c);
        if (!p.edit().putInt(PREVIOUS, before)
                .putString(PREVIOUS_OVERRIDE, override == null || override.isEmpty() ? NONE : override)
                .putBoolean(SEEN, false)
                .putBoolean(ACTIVE, true).commit()) {
            setResult(c, "Не удалось сохранить исходный DPI, переключение отменено");
            return false;
        }
        try {
            if (before != MIR_DPI) set(MIR_DPI);
            setResult(c, "DPI " + before + " → " + MIR_DPI + "; исходное значение сохранено");
            return true;
        } catch (Exception | LinkageError e) {
            // Preserve recovery state: call might already have reached system_server.
            setResult(c, "Ошибка переключения. Можно восстановить DPI: " + error(e));
            return false;
        }
    }

    public static synchronized boolean restore(Context c) {
        if (!isActive(c)) {
            setResult(c, "Активного переключения нет; DPI не изменён");
            return true;
        }
        if (!granted(c)) {
            setResult(c, "Нет разрешения, восстанови DPI через Bugjaeger");
            return false;
        }
        SharedPreferences p = preferences(c);
        String oldOverride = p.getString(PREVIOUS_OVERRIDE, NONE);
        int old = p.getInt(PREVIOUS, -1);
        try {
            if (NONE.equals(oldOverride)) {
                try {
                    reset();
                } catch (Exception first) {
                    if (old <= 0) throw first;
                    set(old);
                }
            } else {
                int oldValue = Integer.parseInt(oldOverride);
                if (oldValue <= 0) throw new IllegalStateException("Некорректный прежний DPI");
                set(oldValue);
            }
            p.edit().putBoolean(ACTIVE, false).putBoolean(SEEN, false).commit();
            setResult(c, "Исходный DPI восстановлен (был " + old + ")");
            return true;
        } catch (Exception | LinkageError e) {
            setResult(c, "ОШИБКА восстановления DPI: " + error(e) + ". Используй Bugjaeger.");
            return false;
        }
    }

    private static String error(Throwable ex) {
        Throwable source = ex;
        if (source instanceof InvocationTargetException
                && ((InvocationTargetException) source).getCause() != null) {
            source = ((InvocationTargetException) source).getCause();
        }
        String message = source.getMessage();
        String s = source.getClass().getSimpleName();
        return s + (message == null ? "" : ": " + message);
    }
}
