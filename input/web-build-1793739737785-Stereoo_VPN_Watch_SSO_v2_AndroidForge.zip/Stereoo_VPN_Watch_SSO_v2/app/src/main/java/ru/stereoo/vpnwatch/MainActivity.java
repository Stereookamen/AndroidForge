package ru.stereoo.vpnwatch;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.InputType;
import android.text.Html;
import android.util.Base64;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.net.SocketTimeoutException;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.List;

/**
 * Wear OS monitoring app for the current one-password Flask login.
 * No Caddy HTTP Basic login, no embedded credentials, no TLS bypass.
 */
public class MainActivity extends Activity {
    private static final String DEFAULT_URL = "https://cabinet.stereoo-vpn.ru";
    private static final String KEY_ALIAS = "stereoo_vpn_watch_credentials_v2";
    private static final int BG = 0xff091322, PANEL = 0xff15263c, TEXT = 0xffeef6ff;
    private static final int MUTED = 0xffacbdd0, GREEN = 0xff38ddb5, RED = 0xffff8b8b;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final CookieManager cookies = new CookieManager(null, CookiePolicy.ACCEPT_ORIGINAL_SERVER);
    private LinearLayout content;
    private TextView status;
    private boolean busy = false;
    private String serverUrl;
    private String password = "";
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CookieHandler.setDefault(cookies);
        prefs = getSharedPreferences("watch", MODE_PRIVATE);
        serverUrl = prefs.getString("server", DEFAULT_URL);
        try { password = loadSecret(); } catch (Exception ignored) { password = ""; }
        drawMain();
        if (!password.isEmpty()) refresh();
    }

    private int dp(int x) { return (int)(getResources().getDisplayMetrics().density * x + .5f); }

    private LinearLayout column() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(dp(14), dp(13), dp(14), dp(25));
        v.setBackgroundColor(BG);
        return v;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0, dp(4), 0, dp(5));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        return t;
    }

    private Button button(String caption, Runnable callback) {
        Button b = new Button(this);
        b.setText(caption);
        b.setTextSize(13);
        b.setTextColor(0xff031d25);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(48));
        p.topMargin = dp(7);
        content.addView(b, p);
        b.setOnClickListener(v -> callback.run());
        return b;
    }

    private void screen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        content = column();
        scroll.addView(content);
        setContentView(scroll);
    }

    private void drawMain() {
        screen();
        content.addView(text("STEREOO VPN", 17, GREEN, true));
        content.addView(text("Мониторинг · Wear OS", 11, MUTED, false));
        content.addView(text("Сервер: " + host(serverUrl), 11, MUTED, false));
        status = text(password.isEmpty() ? "Укажи пароль панели" : "Данные ещё не загружены", 13, TEXT, false);
        content.addView(status);
        button("↻ Обновить", this::refresh);
        button("⚙ Изменить вход", this::drawSettings);
        content.addView(text("Разработчик: Жданов Александр", 9, MUTED, false));
    }

    private String host(String u) { try { return new URL(u).getHost(); } catch (Exception ignored) { return u; } }

    private void drawSettings() {
        screen();
        content.addView(text("Настройка входа", 17, GREEN, true));
        content.addView(text("Только пароль Stereoo VPN Manager. Логин и пароль Caddy больше не нужны.", 12, MUTED, false));
        EditText urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setText(serverUrl);
        urlInput.setTextSize(12);
        urlInput.setTextColor(TEXT);
        urlInput.setHint("https://cabinet.stereoo-vpn.ru");
        urlInput.setHintTextColor(MUTED);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        content.addView(urlInput);
        EditText passInput = new EditText(this);
        passInput.setSingleLine(true);
        passInput.setText(password);
        passInput.setTextSize(13);
        passInput.setTextColor(TEXT);
        passInput.setHint("Пароль панели");
        passInput.setHintTextColor(MUTED);
        passInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        content.addView(passInput);
        TextView message = text("", 11, RED, false);
        content.addView(message);
        button("Сохранить и войти", () -> {
            String u = urlInput.getText().toString().trim();
            String p = passInput.getText().toString();
            if (!isSafeUrl(u) || p.isEmpty()) {
                message.setText("Нужен HTTPS-адрес и пароль панели.");
                return;
            }
            serverUrl = u.replaceAll("/+$", "");
            password = p;
            try { saveSecret(p); }
            catch (Exception e) { message.setText("Не удалось безопасно сохранить пароль. Он действует до закрытия приложения."); }
            prefs.edit().putString("server", serverUrl).apply();
            cookies.getCookieStore().removeAll();
            drawMain();
            refresh();
        });
        button("← Назад", this::drawMain);
    }

    private boolean isSafeUrl(String url) {
        try {
            URL u = new URL(url);
            return "https".equalsIgnoreCase(u.getProtocol()) && !u.getHost().isEmpty()
                    && u.getUserInfo() == null && u.getPort() == -1
                    && (u.getPath().isEmpty() || "/".equals(u.getPath()))
                    && u.getQuery() == null && u.getRef() == null;
        } catch (Exception e) { return false; }
    }

    private void refresh() {
        if (busy) return;
        if (password.isEmpty()) { drawSettings(); return; }
        busy = true;
        if (status != null) { status.setText("Подключаемся…"); status.setTextColor(MUTED); }
        new Thread(() -> {
            try {
                String html = getPage("/");
                if (looksLikeLogin(html)) {
                    performLogin();
                    html = getPage("/");
                    if (looksLikeLogin(html)) throw new AuthException("Неверный пароль панели. Проверь «Изменить вход».");
                }
                String report = summarize(html);
                ui.post(() -> {
                    busy = false;
                    if (status != null) { status.setText(report); status.setTextColor(TEXT); }
                });
            } catch (Exception e) {
                String message = friendlyError(e);
                ui.post(() -> {
                    busy = false;
                    if (status != null) { status.setText(message); status.setTextColor(RED); }
                });
            }
        }, "watch-http").start();
    }

    private String friendlyError(Exception e) {
        if (e instanceof UnknownHostException) return "Не найден адрес домена (DNS). Проверь интернет на часах и DNS cabinet.stereoo-vpn.ru.\nПересборка приложения сама по себе DNS не исправит.";
        if (e instanceof SocketTimeoutException) return "Время ожидания истекло. Проверь интернет и доступность сервера.";
        if (e instanceof AuthException) return e.getMessage();
        String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        return "Ошибка подключения: " + m;
    }

    private boolean looksLikeLogin(String html) {
        return Pattern.compile("(?is)<input\\b[^>]*type=[\"']password[\"']", Pattern.CASE_INSENSITIVE).matcher(html).find()
                || html.contains("Неверный пароль") && html.contains("name=\"password\"");
    }

    private void performLogin() throws Exception {
        String login = getPage("/login");
        String csrf = inputValue(login, "csrf");
        if (csrf.isEmpty()) throw new AuthException("Не найден CSRF-токен страницы входа. Схема входа изменилась.");
        String data = "csrf=" + URLEncoder.encode(csrf, "UTF-8")
                + "&password=" + URLEncoder.encode(password, "UTF-8");
        Response r = request("POST", "/login", data);
        if (r.code == 401 || r.code == 403) throw new AuthException("Пароль панели не принят (HTTP " + r.code + ").");
        if (looksLikeLogin(r.body)) throw new AuthException("Неверный пароль панели. Открой «Изменить вход».");
    }

    private String inputValue(String html, String name) {
        Matcher m = Pattern.compile("(?is)<input\\b[^>]*>").matcher(html);
        while(m.find()) {
            String tag = m.group();
            if (name.equalsIgnoreCase(attr(tag, "name"))) return attr(tag, "value");
        }
        return "";
    }

    private String attr(String tag, String key) {
        Matcher m = Pattern.compile("(?is)\\b" + Pattern.quote(key) + "\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))").matcher(tag);
        return m.find() ? (m.group(1)!=null?m.group(1):(m.group(2)!=null?m.group(2):m.group(3))) : "";
    }

    private static final class Response {
        final int code; final String body;
        Response(int code, String body) {this.code=code; this.body=body;}
    }
    private static class AuthException extends Exception { AuthException(String reason) { super(reason); } }

    private String getPage(String path) throws Exception {
        Response r = request("GET", path, null);
        if (r.code == 401) throw new AuthException("Сервер требует HTTP Basic Auth (Caddy). На часах настроен новый однопарольный вход.");
        if (r.code == 403) throw new AuthException("Доступ запрещён (HTTP 403). Попробуй повторно войти.");
        if (r.code >= 400) throw new IOException("HTTP " + r.code);
        return r.body;
    }

    private Response request(String method, String path, String body) throws Exception {
        URL current = new URL(serverUrl + path);
        for (int redirects = 0; redirects < 5; redirects++) {
            if (!"https".equalsIgnoreCase(current.getProtocol()) || !current.getHost().equalsIgnoreCase(host(serverUrl)))
                throw new IOException("Небезопасный редирект запрещён");
            HttpsURLConnection conn = (HttpsURLConnection) current.openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(14000);
            conn.setRequestProperty("User-Agent", "StereooVPNWatch/2.0 WearOS");
            conn.setRequestProperty("Accept", "text/html");
            conn.setRequestMethod(method);
            if (body != null) {
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                conn.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = conn.getOutputStream()) {out.write(bytes);}
            }
            int code = conn.getResponseCode();
            String location = conn.getHeaderField("Location");
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                conn.disconnect();
                if (location == null) throw new IOException("Редирект без Location");
                current = new URL(current, location);
                if (code == 303 || code == 302 || code == 301) {method="GET"; body=null;}
                continue;
            }
            InputStream in = code < 400 ? conn.getInputStream() : conn.getErrorStream();
            String page = in != null ? readLimited(in) : "";
            conn.disconnect();
            return new Response(code, page);
        }
        throw new IOException("Слишком много перенаправлений");
    }

    private String readLimited(InputStream is) throws IOException {
        try (InputStream stream = is; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int n; int max=2*1024*1024;
            while((n=stream.read(buf))!=-1) {
                if (out.size()+n>max) throw new IOException("Слишком большой ответ сервера");
                out.write(buf,0,n);
            }
            return out.toString("UTF-8");
        }
    }

    private String plain(String input) {
        return Html.fromHtml(input.replaceAll("(?is)<script[^>]*>.*?</script>", "")
            .replaceAll("(?is)<style[^>]*>.*?</style>", ""), Html.FROM_HTML_MODE_LEGACY).toString().replace('\u00a0',' ').replaceAll("\\s+", " ").trim();
    }

    private String summarize(String html) {
        List<String> rows = new ArrayList<>();
        Pattern p = Pattern.compile("(?is)<div\\s+class=[\"'][^\"']*\\bkpi\\b[^\"']*[\"'][^>]*>\\s*<div\\s+class=[\"']kpi-label[\"'][^>]*>(.*?)</div>\\s*<div\\s+class=[\"'][^\"']*kpi-value[^\"']*[\"'][^>]*>(.*?)</div>");
        Matcher m = p.matcher(html);
        while (m.find() && rows.size()<8) {
            rows.add(plain(m.group(1)).replace("↗","") + ": " + plain(m.group(2)));
        }
        StringBuilder sb = new StringBuilder("✅ Кабинет доступен\n");
        if (rows.isEmpty()) sb.append("Вход выполнен. Карточки статистики не найдены.\n");
        else for(String item:rows) sb.append("\n").append(item);
        sb.append("\n\n↻ Обновить для новых данных");
        return sb.toString();
    }

    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(KEY_ALIAS)) return (SecretKey)store.getKey(KEY_ALIAS, null);
        KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build();
        gen.init(spec);
        return gen.generateKey();
    }
    private void saveSecret(String secret) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] iv=cipher.getIV(), encrypted=cipher.doFinal(secret.getBytes(StandardCharsets.UTF_8));
        byte[] joined=new byte[iv.length+encrypted.length];
        System.arraycopy(iv,0,joined,0,iv.length);
        System.arraycopy(encrypted,0,joined,iv.length,encrypted.length);
        prefs.edit().putString("login_blob", Base64.encodeToString(joined, Base64.NO_WRAP)).apply();
    }
    private String loadSecret() throws Exception {
        String raw = prefs.getString("login_blob", "");
        if (raw.isEmpty()) return "";
        byte[] joined=Base64.decode(raw, Base64.NO_WRAP);
        if(joined.length<29) return "";
        byte[] iv=new byte[12], enc=new byte[joined.length-12];
        System.arraycopy(joined,0,iv,0,12);
        System.arraycopy(joined,12,enc,0,enc.length);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128,iv));
        return new String(cipher.doFinal(enc),StandardCharsets.UTF_8);
    }
}
