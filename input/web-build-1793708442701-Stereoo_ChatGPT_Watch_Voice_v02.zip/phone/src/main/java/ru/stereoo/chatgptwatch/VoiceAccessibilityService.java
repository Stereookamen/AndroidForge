package ru.stereoo.chatgptwatch;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;

/**
 * User-enabled, narrowly scoped helper: when the watch requests Voice,
 * search the ChatGPT UI for an accessibility-labeled Voice button and click it.
 * No audio captured, no content stored, no traffic sent by this service.
 * No coordinate tapping, and no interaction with other apps.
 */
public class VoiceAccessibilityService extends AccessibilityService {
    private static final String PREFS = "stereoo_voice";
    private static final String PENDING_SINCE = "pending_since";
    private static final String LAST_STATUS = "last_status";
    private static final long WINDOW_MS = 12000L;
    private static final long MIN_INTERVAL_MS = 450L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastAttempt;
    private final Runnable retry = this::tryClickVoice;

    public static void arm(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong(PENDING_SINCE, SystemClock.elapsedRealtime())
                .putString(LAST_STATUS, "Ищу кнопку голосового режима в ChatGPT…")
                .apply();
    }

    public static void clear(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(PENDING_SINCE).apply();
    }

    public static String lastStatus(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(LAST_STATUS, "Пока нет попыток запуска");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (!"com.openai.chatgpt".contentEquals(event.getPackageName())) return;
        handler.removeCallbacks(retry);
        handler.postDelayed(retry, 180);
    }

    @Override public void onInterrupt() {
        handler.removeCallbacks(retry);
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(retry);
        super.onDestroy();
    }

    private void tryClickVoice() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        long since = prefs.getLong(PENDING_SINCE, 0);
        if (since == 0) return;
        long elapsed = SystemClock.elapsedRealtime() - since;
        if (elapsed < 0 || elapsed > WINDOW_MS) {
            prefs.edit().remove(PENDING_SINCE)
                    .putString(LAST_STATUS, "Автоматическая кнопка Voice не найдена за 12 секунд. Проверь настройки или пришли снимок экрана ChatGPT.")
                    .apply();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastAttempt < MIN_INTERVAL_MS) {
            handler.postDelayed(retry, MIN_INTERVAL_MS);
            return;
        }
        lastAttempt = now;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            try {
                if ("com.openai.chatgpt".contentEquals(root.getPackageName())) {
                    AccessibilityNodeInfo button = findVoiceButton(root, 0);
                    if (button != null) {
                        boolean clicked = button.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        if (clicked) {
                            prefs.edit().remove(PENDING_SINCE)
                                    .putString(LAST_STATUS, "Кнопка голосового режима нажата. Проверяй разговор в ChatGPT.")
                                    .apply();
                            return;
                        }
                    }
                }
            } finally {
                root.recycle();
            }
        }
        handler.postDelayed(retry, 650);
    }

    private AccessibilityNodeInfo findVoiceButton(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 35) return null;
        if (isVoiceControl(node)) {
            AccessibilityNodeInfo clickable = node;
            for (int i = 0; i < 3 && clickable != null; i++) {
                if (clickable.isClickable() && clickable.isEnabled() && clickable.isVisibleToUser()) {
                    return clickable;
                }
                clickable = clickable.getParent();
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            AccessibilityNodeInfo result = findVoiceButton(child, depth + 1);
            if (result != null) return result;
            child.recycle();
        }
        return null;
    }

    private boolean isVoiceControl(AccessibilityNodeInfo node) {
        if (!node.isVisibleToUser() || !node.isEnabled()) return false;
        CharSequence desc = node.getContentDescription();
        CharSequence text = node.getText();
        String s = (((desc == null ? "" : desc.toString()) + " "
                + (text == null ? "" : text.toString())).trim())
                .toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return false;
        // Microphone/dictation isn't a two-way conversation; never click it.
        if (has(s, "диктов", "dictat", "speech-to-text", "transcrib",
                "record audio", "voice input", "голосовой ввод", "записать аудио")) return false;
        boolean explicit = has(s, "voice mode", "voice conversation", "start voice",
                "voice chat", "talk with chatgpt", "talk to chatgpt",
                "голосовой режим", "голосовой разговор", "начать голос", "общаться голосом",
                "голосовой чат", "голосовой диалог");
        boolean shortLabel = s.equals("voice") || s.equals("голос")
                || s.equals("voice button") || s.equals("voice icon")
                || s.equals("голосовая беседа");
        if (!explicit && !shortLabel) return false;
        // Only click a button near the composer, not a menu/settings Voice item.
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        if (bounds.isEmpty()) return false;
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        return bounds.centerY() > metrics.heightPixels * 0.42f
                && bounds.centerX() > metrics.widthPixels * 0.37f;
    }

    private boolean has(String text, String... keys) {
        for (String key : keys) if (text.contains(key)) return true;
        return false;
    }
}
