package ru.stereoo.chatgptwatch;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Phone-side companion. No OpenAI API or credentials; no audio recording. */
public class PhoneActivity extends Activity {
    private TextView info;
    private TextView accessStatus;
    private TextView attemptStatus;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        drawUi();
        if (isRequestFromWatch(getIntent())) openChatGpt();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (isRequestFromWatch(intent)) openChatGpt();
    }

    @Override protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private boolean isRequestFromWatch(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        return intent != null && Intent.ACTION_VIEW.equals(intent.getAction())
            && uri != null && "stereoo".equals(uri.getScheme())
            && "chatgpt".equals(uri.getHost()) && "/open".equals(uri.getPath());
    }

    private void openChatGpt() {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
            if (intent == null) {
                info.setText("ChatGPT не найден. Установи официальное приложение и войди в аккаунт.");
                return;
            }
            if (isAccessibilityEnabled()) {
                VoiceAccessibilityService.arm(this);
                info.setText("Открываю ChatGPT. Автозапуск Voice включён: ищу кнопку голосового режима…");
            } else {
                VoiceAccessibilityService.clear(this);
                info.setText("Открываю ChatGPT. Для запуска Voice включи 'Start with Voice' в настройках ChatGPT либо службу Stereoo в Спец. возможностях телефона.");
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            VoiceAccessibilityService.clear(this);
            info.setText("Не получилось открыть ChatGPT: " + e.getMessage());
        }
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager mgr = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        if (mgr == null) return false;
        String id = new ComponentName(this, VoiceAccessibilityService.class).flattenToString();
        for (AccessibilityServiceInfo service : mgr.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
            if (id.equals(service.getId())) return true;
        }
        return false;
    }

    private void updateStatus() {
        if (accessStatus == null) return;
        accessStatus.setText(isAccessibilityEnabled()
                ? "Автокасание Voice: ВКЛЮЧЕНО ✅"
                : "Автокасание Voice: ВЫКЛЮЧЕНО");
        attemptStatus.setText("Последняя попытка: " + VoiceAccessibilityService.lastStatus(this));
    }

    private void drawUi() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setPadding(dp(22), dp(45), dp(22), dp(28));
        layout.setBackgroundColor(0xff0a0e18);
        layout.addView(label("Stereoo ChatGPT Bridge", 25, 0xffe4ebff, true));
        layout.addView(label("Команда с TicWatch Pro 3 → ChatGPT → голос", 15, 0xff9cacc9, false));
        info = label("Для автозапуска голоса включи службу ниже. Или используй Start with Voice в ChatGPT.", 16, 0xffdce3f4, false);
        LinearLayout.LayoutParams si = new LinearLayout.LayoutParams(-1, -2);
        si.topMargin = dp(22);
        layout.addView(info, si);
        accessStatus = label("Проверяю доступ…", 16, 0xffb5ebc0, true);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = dp(20);
        layout.addView(accessStatus, ap);

        Button permissions = makeButton("НАСТРОИТЬ АВТОЗАПУСК VOICE", 0xff3c72a8);
        permissions.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            catch (Exception ex) { info.setText("Не удалось открыть настройки специальных возможностей."); }
        });
        addButton(layout, permissions);

        Button test = makeButton("ПРОВЕРИТЬ CHATGPT + VOICE", 0xff444edb);
        test.setOnClickListener(v -> openChatGpt());
        addButton(layout, test);

        attemptStatus = label("", 13, 0xffaebbd3, false);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(14);
        layout.addView(attemptStatus, rp);
        TextView foot = label(
            "Разрешение специальных возможностей требуется только для автокасания. " +
            "Служба реагирует на ChatGPT в течение 12 секунд после команды. " +
            "Микрофон и динамик используются на смартфоне.\n\n" +
            "Разработчик: Жданов Александр", 12, 0xff8491aa, false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(18);
        layout.addView(foot, fp);
        setContentView(layout);
        updateStatus();
    }

    private Button makeButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        return b;
    }

    private void addButton(LinearLayout layout, Button button) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.topMargin = dp(16);
        layout.addView(button, p);
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(6), 0, dp(6));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }
}
