package ru.reglerpro.client;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final String API = "https://app.reglerpro.ru/php/taptop.php";
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private String login = "", password = "", homeId = "", homeName = "";
    private JSONArray devices = new JSONArray();
    private LinearLayout root, content;
    private EditText loginInput, passInput;
    private TextView status;
    private boolean busy = false;

    private final int BG = Color.rgb(3,19,47), PANEL = Color.rgb(9,31,70),
            PANEL2 = Color.rgb(13,43,91), CYAN = Color.rgb(0,174,255),
            WHITE = Color.rgb(239,246,255), MUTED = Color.rgb(157,187,225),
            GREEN = Color.rgb(42,220,125), RED = Color.rgb(255,105,105);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.rgb(2,11,29));
        showLogin();
    }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void base(String title) {
        root = column(); root.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        content = column(); content.setPadding(dp(18),dp(18),dp(18),dp(28));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,-1));
        setContentView(root);
    }
    private void gap(LinearLayout p, int h) {
        View v = new View(this); p.addView(v,new LinearLayout.LayoutParams(1,dp(h)));
    }
    private void addHeader(LinearLayout p, String title, String sub) {
        TextView t=text(title,26,WHITE,true); p.addView(t);
        TextView st=text(sub,13,MUTED,false); p.addView(st); gap(p,18);
    }
    private EditText field(String hint, boolean secret) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextColor(WHITE);
        e.setHintTextColor(MUTED); e.setHint(hint); e.setTextSize(16);
        e.setPadding(dp(15),dp(10),dp(15),dp(10)); e.setBackground(shape(PANEL2,0xFF24518B,14));
        if(secret) e.setInputType(129);
        return e;
    }
    private Button button(String label, Runnable click) {
        Button b = new Button(this); b.setText(label); b.setTextColor(WHITE);
        b.setAllCaps(false); b.setTextSize(16); b.setBackground(shape(0xFF087CE8,CYAN,18));
        b.setOnClickListener(v -> click.run()); return b;
    }
    private void showLogin() {
        base("login");
        addHeader(content,"ReglerPro","Умный контроль отопления");
        TextView logo=text("♨",76,CYAN,true); logo.setGravity(Gravity.CENTER);
        content.addView(logo,new LinearLayout.LayoutParams(-1,dp(150)));
        TextView brand=text("REGLERPRO",29,WHITE,true); brand.setGravity(Gravity.CENTER); content.addView(brand);
        gap(content,28);
        loginInput=field("Логин",false); content.addView(loginInput,new LinearLayout.LayoutParams(-1,dp(56)));
        gap(content,12);
        passInput=field("Пароль",true); content.addView(passInput,new LinearLayout.LayoutParams(-1,dp(56)));
        gap(content,18);
        Button enter=button("Войти",()->doLogin());
        content.addView(enter,new LinearLayout.LayoutParams(-1,dp(54)));
        gap(content,12);
        TextView note=text("Вход выполняется напрямую через официальный сервер ReglerPro. Пароль не записывается в приложение.",12,MUTED,false);
        content.addView(note);
        status=text("",13,RED,false); gap(content,12); content.addView(status);
    }
    private void setStatus(String s, boolean error) {
        if(status!=null){ status.setText(s); status.setTextColor(error?RED: MUTED); }
    }
    private void doLogin() {
        if(busy) return;
        login=loginInput.getText().toString().trim();
        password=passInput.getText().toString();
        if(login.isEmpty() || password.isEmpty()){setStatus("Введите логин и пароль",true);return;}
        hideKeyboard(); setStatus("Подключаемся…",false); busy=true;
        io.execute(() -> {
            try {
                JSONObject req = new JSONObject();
                req.put("action","login_user"); req.put("login",login); req.put("password",password);
                req.put("action_value1",""); req.put("action_value2","");
                JSONObject res = post(req);
                if(!res.optBoolean("bool",false)) throw new Exception(res.optString("text","Не удалось войти"));
                homeId=res.optString("home_now_id","");
                homeName=res.optString("home_now_name","Мой дом");
                main.post(() -> { busy=false; showDashboard(); loadDevices(); });
            } catch(Exception ex) {
                main.post(() -> { busy=false; setStatus("Ошибка входа: "+safe(ex.getMessage()),true); });
            }
        });
    }
    private void hideKeyboard(){
        try { ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(root.getWindowToken(),0); } catch(Exception ignored){}
    }
    private JSONObject post(JSONObject body) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(API).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(12000); c.setReadTimeout(15000);
        c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        byte[] data=body.toString().getBytes(StandardCharsets.UTF_8);
        c.getOutputStream().write(data);
        int code=c.getResponseCode();
        InputStream in=(code>=200 && code<300)?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[4096]; int n; while((n=in.read(buf))!=-1)out.write(buf,0,n);
        c.disconnect();
        String raw=new String(out.toByteArray(),StandardCharsets.UTF_8).trim();
        if(code<200 || code>=300) throw new Exception("HTTP "+code);
        if(raw.startsWith("[")) throw new Exception("Ожидался объект ответа");
        return new JSONObject(raw);
    }
    private JSONArray postArray(JSONObject body) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(API).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(12000); c.setReadTimeout(15000);
        c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        c.getOutputStream().write(body.toString().getBytes(StandardCharsets.UTF_8));
        int code=c.getResponseCode();
        InputStream in=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n;
        while((n=in.read(buf))!=-1)out.write(buf,0,n); c.disconnect();
        String raw=new String(out.toByteArray(),StandardCharsets.UTF_8).trim();
        if(code<200||code>=300)throw new Exception("HTTP "+code);
        return new JSONArray(raw);
    }
    private void showDashboard() {
        base("dashboard");
        LinearLayout top=row();
        LinearLayout titles=column();
        titles.addView(text("⌂  ReglerPro",25,WHITE,true));
        titles.addView(text(homeName.isEmpty()?"Мой дом":homeName,13,MUTED,false));
        top.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        Button refresh=button("Обновить",()->loadDevices());
        top.addView(refresh,new LinearLayout.LayoutParams(dp(112),dp(44)));
        content.addView(top); gap(content,18);
        TextView caption=text("МОЁ ОБОРУДОВАНИЕ",12,CYAN,true); content.addView(caption); gap(content,10);
        status=text("Загружаем данные…",13,MUTED,false); content.addView(status);
        gap(content,10);
        TextView warning=text("Пока доступен мониторинг. Команды включения/остановки и изменения настроек не активированы, пока не подтверждены точные параметры API.",12,MUTED,false);
        warning.setPadding(dp(14),dp(12),dp(14),dp(12)); warning.setBackground(shape(PANEL,0xFF20477A,14));
        content.addView(warning);
        gap(content,12);
    }
    private void loadDevices() {
        if(homeId.isEmpty()) return;
        if(status!=null) setStatus("Обновляем данные…",false);
        io.execute(() -> {
            try {
                JSONObject req=new JSONObject();
                req.put("action","get_all_dev"); req.put("range",50);
                req.put("userId",""); req.put("id_name",""); req.put("login",login);
                req.put("password",password); req.put("action_value1",homeId);
                req.put("action_value2",""); req.put("climat_war1","");
                JSONArray arr=postArray(req);
                main.post(()->renderDevices(arr));
            } catch(Exception ex) {
                main.post(()->setStatus("Не удалось получить устройства: "+safe(ex.getMessage()),true));
            }
        });
    }
    private void renderDevices(JSONArray arr) {
        devices=arr;
        // Rebuild dashboard retaining the actual server payload.
        showDashboard();
        if(arr.length()==0){setStatus("Устройства не найдены в выбранном доме",false);return;}
        status.setText("Обновлено с официального сервера • "+arr.length()+" записей");
        status.setTextColor(GREEN);
        for(int i=0;i<arr.length();i++){
            JSONObject dev=arr.optJSONObject(i); if(dev==null)continue;
            String type=dev.optString("type","");
            if(!type.equals("contr")&&!type.equals("dt"))continue;
            content.addView(deviceCard(dev));
            gap(content,12);
        }
        Button reload=button("Обновить показания",()->loadDevices());
        content.addView(reload,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView foot=text("Автообновление не включено. Нажимайте «Обновить показания» для нового запроса.",11,MUTED,false);
        gap(content,10); content.addView(foot);
    }
    private View deviceCard(JSONObject dev) {
        LinearLayout card=column(); card.setPadding(dp(16),dp(15),dp(16),dp(15));
        card.setBackground(shape(PANEL,0xFF24518B,18));
        String name=dev.optString("name","Устройство");
        boolean contr="contr".equals(dev.optString("type"));
        TextView title=text((contr?"♨  КОТЁЛ  ":"🌡  ДАТЧИК  ")+name,17,WHITE,true);
        card.addView(title); gap(card,10);
        if(contr){
            Map<String,Double> p=parseParams(dev.optString("params",""));
            double water=p.getOrDefault("temp_w",Double.NaN);
            double set=p.getOrDefault("temp_w_ust",Double.NaN);
            String state=stateText(p.getOrDefault("sost_rab",-1d));
            LinearLayout temps=row();
            LinearLayout left=column(); left.addView(text("ТЕМПЕРАТУРА ВОДЫ",11,MUTED,true));
            left.addView(text(fmt(water)+" °C",34,CYAN,true));
            temps.addView(left,new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout right=column(); right.addView(text("ЗАДАНО",11,MUTED,true));
            right.addView(text(fmt(set)+" °C",25,WHITE,true)); temps.addView(right);
            card.addView(temps); gap(card,8);
            card.addView(text(state,15,state.contains("Работает")?GREEN:MUTED,true));
            gap(card,5);
            card.addView(text("Связь: "+(dev.optString("mqtt_online","0").equals("1")?"онлайн":"нет подтверждения")+
                    "   •   ID: "+dev.optString("id_name",""),11,MUTED,false));
            JSONObject ts=parseObject(dev.optString("tstatArr",""));
            if(ts!=null && ts.optInt("tstatOn",0)==1){
                gap(card,5); card.addView(text("Климат-контроль: включён",13,CYAN,true));
            }
        } else {
            card.addView(text("Температура датчика",12,MUTED,false));
            card.addView(text(dev.optString("temp","—")+" °C",32,CYAN,true));
            card.addView(text("Связь: "+(dev.optLong("time",999999)<3600?"активен":"давно не обновлялся"),12,MUTED,false));
        }
        return card;
    }
    private JSONObject parseObject(String s){try{return new JSONObject(s);}catch(Exception e){return null;}}
    private Map<String,Double> parseParams(String s){
        Map<String,Double> m=new HashMap<>();
        // The official client encodes parameter values between letter delimiters.
        String[][] keys={{"temp_w_ust","a","b"},{"temp_w","d","e"},{"sost_rab","e","f"},
            {"vers","f","g"},{"temp_w_min","F","G"},{"vent_on","G","H"},
            {"shnek_temp","H","I"},{"tstatNow","k","l"}};
        for(String[] k:keys){
            int a=s.indexOf(k[1]), b=s.indexOf(k[2],a+1);
            if(a>=0&&b>a+1){try{m.put(k[0],Double.parseDouble(s.substring(a+1,b)));}catch(Exception ignored){}}
        }
        return m;
    }
    private String stateText(double s){
        if(s==0)return "⏸  Остановлен";
        if(s==1)return "●  Работает";
        if(s>=0)return "◉  Розжиг / угасание";
        return "Состояние не определено";
    }
    private String fmt(double v){return Double.isNaN(v)?"—":String.format(Locale.getDefault(),"%.1f",v);}
    private String safe(String s){return s==null?"неизвестная ошибка":s.replaceAll("[\\r\\n]"," ");}
    @Override public void onBackPressed(){ if(!homeId.isEmpty()){homeId="";password="";login="";showLogin();}else super.onBackPressed(); }
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
