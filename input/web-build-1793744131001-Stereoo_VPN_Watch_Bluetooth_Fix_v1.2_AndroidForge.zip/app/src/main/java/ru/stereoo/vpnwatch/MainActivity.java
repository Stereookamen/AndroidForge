package ru.stereoo.vpnwatch;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** A fully native Wear OS monitor. No WebView (not supported on Wear OS 2). */
public final class MainActivity extends Activity {
    private static final int BG = 0xff06111d;
    private static final int CARD = 0xff102535;
    private static final int WHITE = 0xfff1f8ff;
    private static final int CYAN = 0xff3de5df;
    private static final int MUTED = 0xff96adbd;
    private static final int SUCCESS = 0xff7cf0b8;
    private static final int ERROR = 0xffff8181;
    private static final int WARNING = 0xffffca72;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SecureLoginStore store;
    private StereooCabinetClient client;
    private TextView status;
    private TextView updated;
    private TextView info;
    private Button refresh;
    private TextView total;
    private TextView active;
    private TextView expired;
    private TextView disabled;
    private TextView soon3;
    private TextView due7;
    private TextView paid;
    private TextView revenue;
    private TextView traffic;
    private boolean busy;
    private int generation = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store = new SecureLoginStore(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildScreen();
        String[] caddy = store.getCaddy();
        String panel = store.getPanel();
        if (caddy != null && panel != null) {
            client = new StereooCabinetClient(this, caddy[0], caddy[1], panel, defaultFallbackIp());
            loadData(false, null, null, null, null, false);
        } else {
            status.setText("● Настройка входа");
            info.setText("Один раз введи доступ к кабинету. Сервер менять не нужно.");
            main.postDelayed(this::showCredentialsDialog, 300);
        }
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER_HORIZONTAL);
        column.setPadding(dp(22), dp(13), dp(22), dp(22));
        scroll.addView(column);
        setContentView(scroll);

        TextView title = tv("◉ STEREOO VPN", 17, CYAN, true);
        title.setGravity(Gravity.CENTER);
        column.addView(title, spacing(2));
        TextView subtitle = tv("МОНИТОР СЕРВЕРА", 10, MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        column.addView(subtitle, spacing(6));
        status = tv("● Ожидание подключения", 13, MUTED, true);
        status.setGravity(Gravity.CENTER);
        status.setMaxLines(2);
        column.addView(status, spacing(4));
        updated = tv("", 10, MUTED, false);
        updated.setGravity(Gravity.CENTER);
        column.addView(updated, spacing(10));

        total = addCard(column, "👥  Всего клиентов");
        active = addCard(column, "✅  Активные подписки");
        expired = addCard(column, "⌛  Истёкшие / лимит");
        disabled = addCard(column, "⛔  Выключены вручную");
        soon3 = addCard(column, "⚠️  Истекают за 3 дня");
        due7 = addCard(column, "📆  К продлению за 7 дней");
        paid = addCard(column, "✓  Оплатили за месяц");
        revenue = addCard(column, "₽  Выручка за месяц");
        traffic = addCard(column, "↕  Использовано трафика");

        info = tv("Показатели загружаются из твоего Stereoo VPN Manager.", 11, MUTED, false);
        info.setGravity(Gravity.CENTER);
        info.setPadding(dp(3), dp(4), dp(3), dp(6));
        column.addView(info, spacing(7));
        refresh = actionButton("⟳  Обновить", () -> loadData(false, null, null, null, null, false));
        column.addView(refresh, spacing(5));
        column.addView(actionButton("⚙  Изменить вход", this::showCredentialsDialog), spacing(12));
        TextView footer = tv("Жданов Александр\nДанные только для просмотра", 10, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        column.addView(footer, spacing(2));
    }

    private TextView addCard(LinearLayout column, String caption) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable background = new GradientDrawable();
        background.setColor(CARD);
        background.setCornerRadius(dp(13));
        box.setBackground(background);
        TextView name = tv(caption, 12, MUTED, false);
        box.addView(name);
        TextView value = tv("—", 20, WHITE, true);
        value.setSingleLine(true);
        value.setEllipsize(TextUtils.TruncateAt.END);
        box.addView(value);
        column.addView(box, spacing(5));
        return value;
    }

    // Direct IPv4 is a Wi-Fi-only last resort, never used across Wear Bluetooth proxy.
    private String defaultFallbackIp() {
        String stored = store.getFallbackIp();
        return stored == null ? "23.27.246.241" : stored;
    }

    private void showCredentialsDialog() {
        String[] currentBasic = store.getCaddy();
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(2), dp(10), 0);
        scroll.addView(content);

        EditText username = field("Логин Caddy", false);
        username.setText(currentBasic == null ? "stereoo" : currentBasic[0]);
        content.addView(username);
        EditText caddyPassword = field("Пароль Caddy", true);
        content.addView(caddyPassword);
        EditText panelPassword = field("Пароль VPN Manager", true);
        content.addView(panelPassword);
        EditText fallbackIp = field("Резервный IPv4 (только Wi-Fi)", false);
        fallbackIp.setText(defaultFallbackIp());
        content.addView(fallbackIp);
        TextView fallbackHint = tv("Через Bluetooth используется системное HTTPS-подключение Wear OS, как в старом приложении. Прямой IP допустим только для Wi-Fi. После смены IP обнови его.", 11, MUTED, false);
        content.addView(fallbackHint);
        CheckBox remember = new CheckBox(this);
        remember.setText("Запомнить на часах");
        remember.setTextSize(12);
        remember.setChecked(true);
        content.addView(remember);
        new AlertDialog.Builder(this)
                .setTitle("Подключение к кабинету")
                .setMessage("Как в старой рабочей версии: системное HTTPS через Bluetooth, вход Caddy и VPN Manager. Прямое соединение к резервному IP по Bluetooth отключено.")
                .setView(scroll)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Подключить", (dialog, which) -> {
                    String user = username.getText().toString().trim();
                    String pass = caddyPassword.getText().toString();
                    String panel = panelPassword.getText().toString();
                    String ip = fallbackIp.getText().toString().trim();
                    if (panel.isEmpty() || (user.isEmpty() != pass.isEmpty())) {
                        info.setText("Введи пароль VPN Manager. Логин и пароль Caddy либо оба заполнены, либо оба пустые.");
                        return;
                    }
                    try {
                        // Passwords are saved only after a successful connection.
                        client = new StereooCabinetClient(this, user, pass, panel, ip);
                        loadData(true, user, pass, panel, ip, remember.isChecked());
                    } catch (IllegalArgumentException e) {
                        info.setText(e.getMessage());
                    }
                }).show();
    }

    private EditText field(String hint, boolean secret) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setTextSize(14);
        edit.setHint(hint);
        edit.setInputType(secret ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT);
        return edit;
    }

    private void loadData(boolean enteredNewCredentials, String user, String basicPassword,
                          String panelPassword, String ip, boolean remember) {
        if (busy && !enteredNewCredentials) return;
        if (client == null) {
            info.setText("Сперва введи пароль доступа.");
            return;
        }
        busy = true;
        refresh.setEnabled(false);
        generation++;
        int run = generation;
        status.setText("● Подключаемся…");
        status.setTextColor(MUTED);
        info.setText("Читаем страницу клиентов и раздел выручки. Никаких команд изменения.");
        final StereooCabinetClient requestedClient = client;
        executor.execute(() -> {
            try {
                StereooCabinetClient.Snapshot result = requestedClient.getSnapshot();
                main.post(() -> {
                    if (run != generation || isFinishing()) return;
                    if (enteredNewCredentials) {
                        if (remember) {
                            store.putCaddy(user, basicPassword);
                            store.putPanel(panelPassword);
                            store.putFallbackIp(ip);
                        } else store.clear();
                    }
                    display(result);
                    busy = false;
                    refresh.setEnabled(true);
                });
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                main.post(() -> {
                    if (run != generation || isFinishing()) return;
                    status.setText("● Ошибка подключения");
                    status.setTextColor(ERROR);
                    info.setText(message + " Нажми «Обновить» или «Изменить вход».");
                    busy = false;
                    refresh.setEnabled(true);
                });
            }
        });
    }

    private void display(StereooCabinetClient.Snapshot result) {
        StereooHtmlParser.Result a = result.clients;
        StereooHtmlParser.Result p = result.payments;
        total.setText(a.get("clients"));
        active.setText(a.get("active"));
        expired.setText(a.get("expired"));
        disabled.setText(a.get("disabled"));
        soon3.setText(a.get("soon3"));
        traffic.setText(a.get("traffic"));
        revenue.setText(p.get("revenue"));
        paid.setText(p.get("paid"));
        due7.setText(p.get("due7"));
        boolean hasError = a.apiErrors > 0 || p.apiErrors > 0;
        status.setText(hasError ? "● Кабинет доступен · Ошибка 3x-ui" : "● Кабинет доступен");
        status.setTextColor(hasError ? WARNING : SUCCESS);
        updated.setText("Обновлено: " + new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
        info.setText(result.usedIpFallback
                ? "⚠ На Wi-Fi использован резервный IP с проверкой HTTPS-сертификата. При смене IP обнови его в настройках."
                : "Статистика из веб-кабинета. Трафик приблизительный. «—» означает, что показатель не найден.");
    }

    @Override protected void onDestroy() {
        generation++;
        main.removeCallbacksAndMessages(null);
        executor.shutdownNow();
        super.onDestroy();
    }

    private int dp(float v) { return (int)(getResources().getDisplayMetrics().density * v + 0.5f); }
    private LinearLayout.LayoutParams spacing(int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(bottom);
        return p;
    }
    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button actionButton(String label, Runnable run) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(WHITE);
        b.setMinHeight(dp(43));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xff174254);
        bg.setCornerRadius(dp(18));
        b.setBackground(bg);
        b.setOnClickListener(v -> run.run());
        return b;
    }
}
