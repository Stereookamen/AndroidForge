package ru.stereoo.vpnwatch;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.ProxyInfo;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.InetSocketAddress;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.Dns;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

/**
 * Read-only HTTPS client for Stereoo VPN Manager. Two independent authentication
 * stages are supported: optional Caddy HTTP Basic and the Flask panel login.
 *
 * Wear OS Bluetooth requests must use the Android platform networking stack.
 * The original working version used HttpURLConnection, which understands the
 * platform/companion proxy. OkHttp with direct-IP DNS fallback may bypass the
 * phone proxy, even when the watch has Internet over Bluetooth. Therefore the
 * primary path ALWAYS uses the original URLConnection stack. An explicit HTTP
 * proxy retry uses an OS-advertised proxy only. Direct-IP TLS fallback is
 * attempted only when the watch itself has an active Wi-Fi network.
 * All connections remain HTTPS with normal certificate/hostname validation.
 */
final class StereooCabinetClient {
    private static final String HOST = "cabinet.stereoo-vpn.ru";
    private static final String ROOT = "https://" + HOST;
    private final String basic;
    private final Context context;
    private final CookieManager platformCookies;
    private final String panelPassword;
    private final String fallbackIp;
    private final OkHttpClient http;
    private volatile boolean fallbackWasUsed = false;

    StereooCabinetClient(Context context, String caddyUser, String caddyPass, String panelPassword, String fallbackIp) {
        this.context = context.getApplicationContext();
        this.platformCookies = new CookieManager(null, CookiePolicy.ACCEPT_ORIGINAL_SERVER);
        // This is the same platform CookieHandler path as the original watch app.
        CookieHandler.setDefault(platformCookies);
        this.basic = caddyUser != null && !caddyUser.isEmpty() && caddyPass != null && !caddyPass.isEmpty()
                ? okhttp3.Credentials.basic(caddyUser, caddyPass, StandardCharsets.UTF_8) : null;
        this.panelPassword = panelPassword;
        this.fallbackIp = fallbackIp == null ? "" : fallbackIp.trim();

        final byte[] fallbackBytes = validateIpv4(this.fallbackIp);
        final List<Cookie> cookies = new ArrayList<>();
        CookieJar cookieJar = new CookieJar() {
            @Override public synchronized void saveFromResponse(HttpUrl url, List<Cookie> received) {
                synchronized (cookies) {
                    long now = System.currentTimeMillis();
                    cookies.removeIf(c -> c.expiresAt() <= now);
                    for (Cookie c : received) {
                        cookies.removeIf(old -> old.name().equals(c.name())
                                && old.domain().equals(c.domain()) && old.path().equals(c.path()));
                        if (c.expiresAt() > now) cookies.add(c);
                    }
                }
            }
            @Override public List<Cookie> loadForRequest(HttpUrl url) {
                synchronized (cookies) {
                    List<Cookie> result = new ArrayList<>();
                    for (Cookie c : cookies) if (c.matches(url)) result.add(c);
                    return result;
                }
            }
        };

        Dns dns = hostname -> {
            try {
                return Dns.SYSTEM.lookup(hostname);
            } catch (UnknownHostException original) {
                if (HOST.equalsIgnoreCase(hostname) && fallbackBytes != null) {
                    List<InetAddress> addresses = new ArrayList<>();
                    addresses.add(InetAddress.getByAddress(fallbackBytes));
                    return addresses;
                }
                throw original;
            }
        };
        http = new OkHttpClient.Builder()
                .dns(dns)
                .cookieJar(cookieJar)
                .followRedirects(false)
                .followSslRedirects(false)
                .connectTimeout(12, TimeUnit.SECONDS)
                .readTimeout(16, TimeUnit.SECONDS)
                .callTimeout(35, TimeUnit.SECONDS)
                .build();
    }

    private static byte[] validateIpv4(String value) {
        if (value == null || value.isEmpty()) return null;
        String[] parts = value.split("\\.", -1);
        if (parts.length != 4) throw new IllegalArgumentException("Резервный IP должен быть IPv4 (4 группы цифр).");
        byte[] out = new byte[4];
        for (int i = 0; i < 4; i++) {
            if (!parts[i].matches("[0-9]{1,3}")) throw new IllegalArgumentException("Неверный резервный IP.");
            int n = Integer.parseInt(parts[i]);
            if (n > 255) throw new IllegalArgumentException("Неверный резервный IP.");
            out[i] = (byte)n;
        }
        return out;
    }

    static final class Snapshot {
        StereooHtmlParser.Result clients;
        StereooHtmlParser.Result payments;
        boolean usedIpFallback;
    }

    Snapshot getSnapshot() throws Exception {
        Response first = get("/");
        if (first.code == 401) throw new IllegalArgumentException("Caddy требует логин и пароль HTTP Basic. Открой «Изменить вход» и введи данные Caddy.");
        if (first.code == 302 || first.code == 303 || StereooHtmlParser.isLogin(first.html)) {
            login();
            first = get("/");
        }
        if (first.code == 401) throw new IllegalArgumentException("HTTP 401: неверные данные Caddy.");
        if (first.code != 200) throw new IllegalStateException("Кабинет вернул HTTP " + first.code);
        if (!StereooHtmlParser.isDashboard(first.html)) {
            if (StereooHtmlParser.isLogin(first.html)) throw new IllegalArgumentException("Неверный пароль VPN Manager.");
            throw new IllegalStateException("Не обнаружена страница клиентов. Возможно, изменился шаблон.");
        }
        Snapshot result = new Snapshot();
        result.clients = StereooHtmlParser.clients(first.html);
        Response pay = get("/payments");
        if (pay.code == 401) throw new IllegalArgumentException("Caddy отверг HTTP Basic на /payments.");
        if (pay.code == 200 && pay.html.contains("ПОЛУЧЕНО ЗА МЕСЯЦ"))
            result.payments = StereooHtmlParser.payments(pay.html);
        else result.payments = new StereooHtmlParser.Result();
        result.usedIpFallback = fallbackWasUsed;
        return result;
    }

    private void login() throws Exception {
        Response loginPage = get("/login");
        if (loginPage.code == 401) throw new IllegalArgumentException("Caddy требует правильный логин и пароль.");
        if (loginPage.code != 200) throw new IllegalStateException("Ошибка страницы входа: HTTP " + loginPage.code);
        String csrf = StereooHtmlParser.csrf(loginPage.html);
        if (csrf == null) throw new IllegalStateException("Не найден CSRF формы входа.");
        String form = "csrf=" + java.net.URLEncoder.encode(csrf, "UTF-8")
                + "&password=" + java.net.URLEncoder.encode(panelPassword, "UTF-8");
        Response sent = request("/login", "POST", form);
        if (sent.code == 401) throw new IllegalArgumentException("Неверный логин или пароль Caddy.");
        if (sent.code == 403) throw new IllegalStateException("Ошибка проверки CSRF. Повтори вход.");
        if (sent.code == 429) throw new IllegalArgumentException("Слишком много попыток входа. Повтори позже.");
        if (sent.code == 200 && (sent.html.contains("Неверный пароль") || StereooHtmlParser.isLogin(sent.html)))
            throw new IllegalArgumentException("Неверный пароль VPN Manager.");
        if (sent.code != 302 && sent.code != 303 && sent.code != 200)
            throw new IllegalStateException("Ошибка входа: HTTP " + sent.code);
    }

    private Response get(String path) throws Exception { return request(path, "GET", null); }

    private Response request(String path, String method, String form) throws Exception {
        if (!path.equals("/") && !path.equals("/login") && !path.equals("/payments"))
            throw new IllegalArgumentException("Запрещённый путь: " + path);
        // PRIMARY: restore the exact type of transport the original app used.
        // URLConnection uses Android's built-in proxy selection for Bluetooth.
        try {
            return requestPlatform(path, method, form, null);
        } catch (UnknownHostException | ConnectException | SocketTimeoutException first) {
            // Some Wear builds expose the phone proxy via ConnectivityManager or
            // ProxySelector but fail to choose it automatically. Retry HTTPS
            // through ONLY explicitly advertised system HTTP proxies.
            Response proxied = requestThroughSystemProxy(path, method, form);
            if (proxied != null) return proxied;

            // The old v1.1 direct-IP fallback connected to :443 and failed on BT.
            // Only attempt it on a real Wi-Fi route, NEVER through Bluetooth.
            if (first instanceof UnknownHostException && onWatchWifi() && validateIpv4(fallbackIp) != null) {
                return requestWithWifiDnsFallback(path, method, form);
            }
            if (first instanceof UnknownHostException) {
                throw new IllegalStateException("DNS на часах не разрешил домен через Bluetooth. "
                        + "Системный HTTPS и прокси проверены. Проверь DNS домена и интернет часов; "
                        + "прямой IP через Bluetooth намеренно не используется.", first);
            }
            if (first instanceof ConnectException) {
                throw new IllegalStateException("Не удалось соединиться через Bluetooth-прокси. "
                        + "Wi-Fi часов может работать отдельно. Причина: " + first.getMessage(), first);
            }
            throw new IllegalStateException("Превышено время соединения через Bluetooth или Wi-Fi. "
                    + first.getMessage(), first);
        }
    }

    private Response requestPlatform(String path, String method, String form, Proxy proxy) throws Exception {
        URL url = new URL(ROOT + path);
        HttpURLConnection con = (HttpURLConnection) (proxy == null
                ? url.openConnection() : url.openConnection(proxy));
        try {
            con.setInstanceFollowRedirects(false);  // Never forward Caddy Basic to redirects.
            con.setConnectTimeout(12000);
            con.setReadTimeout(16000);
            con.setUseCaches(false);
            con.setRequestMethod(method);
            con.setRequestProperty("Accept", "text/html");
            con.setRequestProperty("User-Agent", "StereooVPNWatch/1.2 (Wear OS)");
            if (basic != null) con.setRequestProperty("Authorization", basic);
            if (form != null) {
                byte[] bytes = form.getBytes(StandardCharsets.UTF_8);
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                con.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream output = con.getOutputStream()) { output.write(bytes); }
            }
            int code = con.getResponseCode();
            InputStream in = code >= 400 ? con.getErrorStream() : con.getInputStream();
            byte[] bytes;
            try { bytes = readMax(in, 2 * 1024 * 1024); }
            finally { if (in != null) in.close(); }
            return new Response(code, new String(bytes, StandardCharsets.UTF_8));
        } finally {
            con.disconnect();
        }
    }

    private Response requestThroughSystemProxy(String path, String method, String form) {
        List<Proxy> proxies = new ArrayList<>();
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                ProxyInfo info = cm.getDefaultProxy();
                if (info != null && info.getHost() != null && info.getPort() > 0) {
                    proxies.add(new Proxy(Proxy.Type.HTTP,
                            InetSocketAddress.createUnresolved(info.getHost(), info.getPort())));
                }
            }
        } catch (Exception ignored) { /* Some Wear builds cannot inspect the proxy. */ }
        try {
            ProxySelector selector = ProxySelector.getDefault();
            if (selector != null) {
                List<Proxy> selected = selector.select(URI.create(ROOT + path));
                if (selected != null) for (Proxy proxy : selected) {
                    if (proxy != null && proxy.type() == Proxy.Type.HTTP && !proxies.contains(proxy))
                        proxies.add(proxy);
                }
            }
        } catch (Exception ignored) { }
        for (Proxy proxy : proxies) {
            try {
                return requestPlatform(path, method, form, proxy);
            } catch (Exception ignored) {
                // Continue to any other advertised proxy; never use guessed proxies.
            }
        }
        return null;
    }

    private boolean onWatchWifi() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network network = cm.getActiveNetwork();
            NetworkCapabilities caps = network == null ? null : cm.getNetworkCapabilities(network);
            return caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        } catch (Exception e) { return false; }
    }

    private Response requestWithWifiDnsFallback(String path, String method, String form) throws Exception {
        // Only when the watch has actual Wi-Fi. DNS override still preserves the
        // original HTTPS URL, hostname verification and SNI.
        Request.Builder req = new Request.Builder()
                .url(ROOT + path)
                .header("Accept", "text/html")
                .header("User-Agent", "StereooVPNWatch/1.2 (Wear OS)");
        if (basic != null) req.header("Authorization", basic);
        if (form == null) req.get();
        else req.post(RequestBody.create(
                MediaType.parse("application/x-www-form-urlencoded; charset=utf-8"), form));
        try (okhttp3.Response resp = http.newCall(req.build()).execute()) {
            byte[] bytes = readMax(resp.body() == null ? null : resp.body().byteStream(), 2 * 1024 * 1024);
            fallbackWasUsed = true;
            return new Response(resp.code(), new String(bytes, StandardCharsets.UTF_8));
        }
    }

    private static byte[] readMax(InputStream in, int limit) throws Exception {
        if (in == null) return new byte[0];
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) {
            if (baos.size() + n > limit) throw new IllegalStateException("Слишком большой HTML-ответ сервера.");
            baos.write(buffer, 0, n);
        }
        return baos.toByteArray();
    }

    private static final class Response {
        final int code;
        final String html;
        Response(int code, String html) { this.code = code; this.html = html; }
    }
}
