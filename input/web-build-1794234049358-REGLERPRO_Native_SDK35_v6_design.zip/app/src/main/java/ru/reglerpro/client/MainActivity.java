package ru.reglerpro.client;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.CookieManager;
import org.json.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final String API = "https://app.reglerpro.ru/php/taptop.php";
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private String login = "", password = "", homeId = "", homeName = "";
    private JSONArray devices = new JSONArray();
    private LinearLayout root, content;
    private EditText loginInput, passInput;
    private TextView status;
    private boolean busy = false;
    private WebView officialWebView;
    private boolean officialScreen = false;

    private final int BG = Color.rgb(7,16,34), PANEL = Color.rgb(15,30,54),
            PANEL2 = Color.rgb(20,42,72), CYAN = Color.rgb(64,210,220),
            WHITE = Color.rgb(242,247,255), MUTED = Color.rgb(151,171,198),
            GREEN = Color.rgb(72,220,157), RED = Color.rgb(255,112,125);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.rgb(4,10,22));
        showLogin();
    }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private GradientDrawable gradient(int top, int bottom, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{top, bottom});
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private void panel(LinearLayout view, int pad) {
        view.setPadding(dp(pad),dp(pad),dp(pad),dp(pad));
        view.setBackground(gradient(0xFF172F50,0xFF10213B,0xFF294968,20));
        view.setElevation(dp(3));
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void base(String title) {
        root = column(); root.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        content = column(); content.setPadding(dp(18),dp(18),dp(18),dp(28));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,-1));
        setContentView(root);
    }
    private void gap(LinearLayout p, int h) {
        View v = new View(this); p.addView(v,new LinearLayout.LayoutParams(1,dp(h)));
    }
    private void addHeader(LinearLayout p, String title, String sub) {
        TextView t=text(title,26,WHITE,true); p.addView(t);
        TextView st=text(sub,13,MUTED,false); p.addView(st); gap(p,18);
    }
    private EditText field(String hint, boolean secret) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextColor(WHITE);
        e.setHintTextColor(MUTED); e.setHint(hint); e.setTextSize(16);
        e.setPadding(dp(15),dp(10),dp(15),dp(10)); e.setBackground(shape(PANEL2,0xFF24518B,14));
        if(secret) e.setInputType(129);
        return e;
    }
    private Button button(String label, Runnable click) {
        Button b = new Button(this); b.setText(label); b.setTextColor(WHITE);
        b.setAllCaps(false); b.setTextSize(14); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setPadding(dp(12),0,dp(12),0); b.setMinHeight(dp(44));
        b.setBackground(gradient(0xFF087FAD,0xFF075B91,0xFF39C5D3,15));
        b.setElevation(dp(2)); b.setOnClickListener(v -> click.run()); return b;
    }
    private void showLogin() {
        base("login");
        addHeader(content,"ReglerPro","Умный контроль отопления");
        LinearLayout emblem=column(); emblem.setGravity(Gravity.CENTER);
        emblem.setBackground(gradient(0xFF163B60,0xFF0C203B,0xFF28617B,28));
        TextView logo=text("♨",72,CYAN,true); logo.setGravity(Gravity.CENTER);
        emblem.addView(logo,new LinearLayout.LayoutParams(-1,dp(126)));
        content.addView(emblem,new LinearLayout.LayoutParams(-1,dp(142)));
        gap(content,16);
        TextView brand=text("REGLERPRO",28,WHITE,true); brand.setGravity(Gravity.CENTER); content.addView(brand);
        TextView tagline=text("ОТОПЛЕНИЕ ПОД КОНТРОЛЕМ",10,CYAN,true); tagline.setGravity(Gravity.CENTER); content.addView(tagline);
        gap(content,28);
        loginInput=field("Логин",false); content.addView(loginInput,new LinearLayout.LayoutParams(-1,dp(56)));
        gap(content,12);
        passInput=field("Пароль",true); content.addView(passInput,new LinearLayout.LayoutParams(-1,dp(56)));
        gap(content,18);
        Button enter=button("Войти",()->doLogin());
        content.addView(enter,new LinearLayout.LayoutParams(-1,dp(54)));
        gap(content,12);
        TextView note=text("Вход выполняется напрямую через официальный сервер ReglerPro. Пароль не записывается в приложение.",12,MUTED,false);
        content.addView(note);
        status=text("",13,RED,false); gap(content,12); content.addView(status);
    }
    private void setStatus(String s, boolean error) {
        if(status!=null){ status.setText(s); status.setTextColor(error?RED: MUTED); }
    }
    private void doLogin() {
        if(busy) return;
        login=loginInput.getText().toString().trim();
        password=passInput.getText().toString();
        if(login.isEmpty() || password.isEmpty()){setStatus("Введите логин и пароль",true);return;}
        hideKeyboard(); setStatus("Подключаемся…",false); busy=true;
        io.execute(() -> {
            try {
                JSONObject req = new JSONObject();
                req.put("action","login_user"); req.put("login",login); req.put("password",password);
                req.put("action_value1",""); req.put("action_value2","");
                JSONObject res = post(req);
                if(!res.optBoolean("bool",false)) throw new Exception(res.optString("text","Не удалось войти"));
                homeId=res.optString("home_now_id","");
                homeName=res.optString("home_now_name","Мой дом");
                main.post(() -> { busy=false; showDashboard(); loadDevices(); });
            } catch(Exception ex) {
                main.post(() -> { busy=false; setStatus("Ошибка входа: "+safe(ex.getMessage()),true); });
            }
        });
    }
    private void hideKeyboard(){
        try { ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(root.getWindowToken(),0); } catch(Exception ignored){}
    }
    private JSONObject post(JSONObject body) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(API).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(12000); c.setReadTimeout(15000);
        c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        byte[] data=body.toString().getBytes(StandardCharsets.UTF_8);
        c.getOutputStream().write(data);
        int code=c.getResponseCode();
        InputStream in=(code>=200 && code<300)?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[4096]; int n; while((n=in.read(buf))!=-1)out.write(buf,0,n);
        c.disconnect();
        String raw=new String(out.toByteArray(),StandardCharsets.UTF_8).trim();
        if(code<200 || code>=300) throw new Exception("HTTP "+code);
        if(raw.startsWith("[")) throw new Exception("Ожидался объект ответа");
        return new JSONObject(raw);
    }
    private JSONArray postArray(JSONObject body) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(API).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(12000); c.setReadTimeout(15000);
        c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        c.getOutputStream().write(body.toString().getBytes(StandardCharsets.UTF_8));
        int code=c.getResponseCode();
        InputStream in=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n;
        while((n=in.read(buf))!=-1)out.write(buf,0,n); c.disconnect();
        String raw=new String(out.toByteArray(),StandardCharsets.UTF_8).trim();
        if(code<200||code>=300)throw new Exception("HTTP "+code);
        return new JSONArray(raw);
    }
    private void showDashboard() {
        base("dashboard");
        LinearLayout top=row();
        LinearLayout titles=column();
        titles.addView(text("REGLERPRO",12,CYAN,true));
        titles.addView(text(homeName.isEmpty()?"Мой дом":homeName,24,WHITE,true));
        titles.addView(text("ПАНЕЛЬ УПРАВЛЕНИЯ",10,MUTED,true));
        top.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        Button refresh=button("Обновить",()->loadDevices());
        top.addView(refresh,new LinearLayout.LayoutParams(dp(112),dp(44)));
        content.addView(top); gap(content,18);
        LinearLayout hero=column(); panel(hero,16);
        hero.addView(text("УМНЫЙ КЛИМАТ ДОМА",11,CYAN,true)); gap(hero,5);
        hero.addView(text("Отопление и оборудование",20,WHITE,true));
        hero.addView(text("Контроль показаний в одном месте",12,MUTED,false));
        content.addView(hero,new LinearLayout.LayoutParams(-1,-2)); gap(content,18);
        TextView caption=text("МОЁ ОБОРУДОВАНИЕ",12,CYAN,true); content.addView(caption); gap(content,10);
        LinearLayout nav=row();
        Button schedule=button("Расписание",()->showSchedule()); nav.addView(schedule,new LinearLayout.LayoutParams(0,dp(44),1));
        Button equipment=button("Управление",()->showEquipment()); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,dp(44),1);ep.leftMargin=dp(8);nav.addView(equipment,ep);
        content.addView(nav);gap(content,12);
        Button fullControl=button("Полное управление • официальный ReglerPro",()->showOfficialWeb());
        content.addView(fullControl,new LinearLayout.LayoutParams(-1,dp(52))); gap(content,12);
        TextView fullNote=text("Откроется оригинальный интерфейс ReglerPro со всеми доступными командами, настройками климата, расписаниями и оборудованием. При первом открытии потребуется войти на сайте.",12,MUTED,false);
        content.addView(fullNote); gap(content,12);
        status=text("Загружаем данные…",13,MUTED,false); content.addView(status);
        gap(content,10);
        TextView warning=text("Пока доступен мониторинг. Команды включения/остановки и изменения настроек не активированы, пока не подтверждены точные параметры API.",12,MUTED,false);
        warning.setPadding(dp(14),dp(12),dp(14),dp(12)); warning.setBackground(gradient(0xFF3B2E27,0xFF2A2428,0xFF78503D,16));
        content.addView(warning);
        gap(content,12);
    }
    private void loadDevices() {
        if(homeId.isEmpty()) return;
        if(status!=null) setStatus("Обновляем данные…",false);
        io.execute(() -> {
            try {
                JSONObject req=new JSONObject();
                req.put("action","get_all_dev"); req.put("range",50);
                req.put("userId",""); req.put("id_name",""); req.put("login",login);
                req.put("password",password); req.put("action_value1",homeId);
                req.put("action_value2",""); req.put("climat_war1","");
                JSONArray arr=postArray(req);
                main.post(()->renderDevices(arr));
            } catch(Exception ex) {
                main.post(()->setStatus("Не удалось получить устройства: "+safe(ex.getMessage()),true));
            }
        });
    }
    private void renderDevices(JSONArray arr) {
        devices=arr;
        // Rebuild dashboard retaining the actual server payload.
        showDashboard();
        if(arr.length()==0){setStatus("Устройства не найдены в выбранном доме",false);return;}
        status.setText("Обновлено с официального сервера • "+arr.length()+" записей");
        status.setTextColor(GREEN);
        for(int i=0;i<arr.length();i++){
            JSONObject dev=arr.optJSONObject(i); if(dev==null)continue;
            String type=dev.optString("type","");
            if(!type.equals("contr")&&!type.equals("dt"))continue;
            content.addView(deviceCard(dev));
            gap(content,12);
        }
        Button reload=button("Обновить показания",()->loadDevices());
        content.addView(reload,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView foot=text("Автообновление не включено. Нажимайте «Обновить показания» для нового запроса.",11,MUTED,false);
        gap(content,10); content.addView(foot);
    }
    private View deviceCard(JSONObject dev) {
        LinearLayout card=column(); card.setPadding(dp(16),dp(15),dp(16),dp(15));
        card.setBackground(gradient(0xFF183453,0xFF10243F,0xFF2B526F,20));
        card.setElevation(dp(3));
        String name=dev.optString("name","Устройство");
        boolean contr="contr".equals(dev.optString("type"));
        TextView title=text((contr?"♨  КОТЁЛ  ":"🌡  ДАТЧИК  ")+name,17,WHITE,true);
        card.addView(title); gap(card,10);
        if(contr){
            Map<String,Double> p=parseParams(dev.optString("params",""));
            double water=p.getOrDefault("temp_w",Double.NaN);
            double set=p.getOrDefault("temp_w_ust",Double.NaN);
            String state=stateText(p.getOrDefault("sost_rab",-1d));
            LinearLayout temps=row();
            LinearLayout left=column(); left.addView(text("ТЕМПЕРАТУРА ВОДЫ",11,MUTED,true));
            left.addView(text(fmt(water)+" °C",38,CYAN,true));
            temps.addView(left,new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout right=column(); right.addView(text("ЗАДАНО",11,MUTED,true));
            right.addView(text(fmt(set)+" °C",25,WHITE,true)); temps.addView(right);
            card.addView(temps); gap(card,8);
            card.addView(text(state,15,state.contains("Работает")?GREEN:MUTED,true));
            gap(card,5);
            card.addView(text("Связь: "+(dev.optString("mqtt_online","0").equals("1")?"онлайн":"нет подтверждения")+
                    "   •   ID: "+dev.optString("id_name",""),11,MUTED,false));
            JSONObject ts=parseObject(dev.optString("tstatArr",""));
            if(ts!=null && ts.optInt("tstatOn",0)==1){
                gap(card,5); card.addView(text("Климат-контроль: включён",13,CYAN,true));
            }
        } else {
            card.addView(text("Температура датчика",12,MUTED,false));
            card.addView(text(dev.optString("temp","—")+" °C",32,CYAN,true));
            card.addView(text("Связь: "+(dev.optLong("time",999999)<3600?"активен":"давно не обновлялся"),12,MUTED,false));
        }
        gap(card,12);
        LinearLayout actions=row();
        Button graphBtn=button("График",()->openGraph(dev));
        actions.addView(graphBtn,new LinearLayout.LayoutParams(0,dp(44),1));
        if(contr){
            Button climateBtn=button("Климат",()->openClimate(dev));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(44),1); cp.leftMargin=dp(8);
            actions.addView(climateBtn,cp);
        }
        card.addView(actions);
        return card;
    }

    private void openGraph(JSONObject dev){
        String id=dev.optString("id_name","");
        if(id.isEmpty()) return;
        setStatus("Загружаем историю…",false);
        io.execute(()->{
            try{
                JSONObject q=new JSONObject(); q.put("action","dt".equals(dev.optString("type"))?"get_big_dt":"get_big_contr"); q.put("range",50);
                q.put("userId",homeId); q.put("id_name",id); q.put("login",login); q.put("password",password);
                q.put("climat_war1","");
                JSONObject data=post(q);
                main.post(()->showGraph(data));
            }catch(Exception e){main.post(()->setStatus("График: "+safe(e.getMessage()),true));}
        });
    }
    private void showGraph(JSONObject data){
        base("graph"); addHeader(content,"История температур",data.optString("name","Оборудование"));
        JSONArray values=data.optJSONArray("graf"), labels=data.optJSONArray("time_for_graf");
        if(values==null) values=parseArray(data.optString("graf",""));
        if(labels==null) labels=parseArray(data.optString("time_for_graf",""));
        if(values==null||values.length()==0){content.addView(text("Сервер не вернул точки графика",14,RED,false));return;}
        content.addView(new TrendView(values),new LinearLayout.LayoutParams(-1,dp(250)));
        gap(content,10);
        content.addView(text("Показано точек: "+values.length()+" • Интервал и глубина определяются официальным сервером.",12,MUTED,false));
        gap(content,16); content.addView(button("Назад к оборудованию",()->{showDashboard();renderDevices(devices);}));
    }
    private JSONArray parseArray(String s){try{return new JSONArray(s);}catch(Exception e){return null;}}
    private class TrendView extends View{
        final JSONArray vals; final Paint paint=new Paint(3);
        TrendView(JSONArray a){super(MainActivity.this);vals=a;setBackground(gradient(0xFF183453,0xFF10243F,0xFF2B526F,18));}
        @Override protected void onDraw(Canvas c){super.onDraw(c); int n=vals.length(); if(n<2)return;
            float left=dp(34),right=getWidth()-dp(16),top=dp(20),bottom=getHeight()-dp(28);
            double min=Double.MAX_VALUE,max=-Double.MAX_VALUE; double[] v=new double[n];
            for(int i=0;i<n;i++){v[i]=vals.optDouble(i,Double.NaN);if(!Double.isNaN(v[i])){min=Math.min(min,v[i]);max=Math.max(max,v[i]);}}
            if(min==Double.MAX_VALUE)return; if(max-min<0.1){max+=1;min-=1;}
            paint.setColor(0xFF31547D);paint.setStrokeWidth(dp(1)); for(int k=0;k<4;k++){float y=top+(bottom-top)*k/3f;c.drawLine(left,y,right,y,paint);}
            paint.setColor(CYAN);paint.setStrokeWidth(dp(2.5f));paint.setStyle(Paint.Style.STROKE);android.graphics.Path path=new android.graphics.Path();
            boolean started=false;for(int i=0;i<n;i++){if(Double.isNaN(v[i]))continue;float x=left+(right-left)*i/(n-1f);float y=bottom-(float)((v[i]-min)/(max-min))*(bottom-top);if(!started){path.moveTo(x,y);started=true;}else path.lineTo(x,y);}c.drawPath(path,paint);paint.setStyle(Paint.Style.FILL);
            paint.setColor(WHITE);paint.setTextSize(dp(11));c.drawText(String.format(Locale.getDefault(),"%.1f °C",max),dp(8),top+dp(4),paint);c.drawText(String.format(Locale.getDefault(),"%.1f °C",min),dp(8),bottom,paint);
        }
    }
    private void openClimate(JSONObject dev){
        base("climate"); addHeader(content,"Климат-контроль",dev.optString("name","Контроллер"));
        JSONObject t=parseObject(dev.optString("tstatArr",""));
        content.addView(text("Термостат: "+(t!=null&&t.optInt("tstatOn",0)==1?"включён":"выключен / не настроен"),17,CYAN,true));gap(content,8);
        content.addView(text("Заданная температура: "+(t==null?"—":t.optString("tstatTemp","—"))+" °C",16,WHITE,false));gap(content,12);
        content.addView(text("Датчик климата: "+(t==null?"не выбран":t.optString("tstatDtId","не выбран")),13,MUTED,false));gap(content,18);
        TextView info=text("Экран подключён к данным контроллера. Переключение термостата, выбор режима и изменение уставки пока заблокированы: в переданном HAR нет подтверждённых запросов записи. Не отправляю непроверенные команды на отопительное оборудование.",13,MUTED,false);
        info.setPadding(dp(14),dp(14),dp(14),dp(14));info.setBackground(gradient(0xFF183453,0xFF10243F,0xFF2B526F,18));content.addView(info);gap(content,16);
        content.addView(button("Назад",()->{showDashboard();renderDevices(devices);}));
    }
    private void showOfficialWeb() {
        officialScreen = true;
        root = column(); root.setBackgroundColor(BG);
        LinearLayout bar = row(); bar.setPadding(dp(10),dp(8),dp(10),dp(8));
        Button back = button("← Назад", () -> { officialScreen=false; officialWebView=null; showDashboard(); });
        bar.addView(back, new LinearLayout.LayoutParams(dp(105),dp(44)));
        TextView title = text("Официальный ReglerPro",16,WHITE,true);
        title.setGravity(Gravity.CENTER);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(44),1));
        Button reload = button("↻", () -> { if(officialWebView!=null) officialWebView.reload(); });
        bar.addView(reload,new LinearLayout.LayoutParams(dp(58),dp(44)));
        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(60)));
        officialWebView = new WebView(this);
        officialWebView.setBackgroundColor(Color.WHITE);
        officialWebView.getSettings().setJavaScriptEnabled(true);
        officialWebView.getSettings().setDomStorageEnabled(true);
        officialWebView.getSettings().setDatabaseEnabled(true);
        officialWebView.getSettings().setLoadsImagesAutomatically(true);
        officialWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        officialWebView.getSettings().setSupportMultipleWindows(false);
        officialWebView.getSettings().setUserAgentString(officialWebView.getSettings().getUserAgentString()+" ReglerProAndroid/1.0");
        CookieManager cookies=CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(officialWebView,true);
        officialWebView.setWebViewClient(new WebViewClient());
        officialWebView.setWebChromeClient(new WebChromeClient());
        root.addView(officialWebView,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        officialWebView.loadUrl("https://app.reglerpro.ru/");
    }

    private void showSchedule(){
        base("schedule");addHeader(content,"Расписание","Локальный редактор расписания");
        EditText time=field("Время, например 06:30",false);content.addView(time,new LinearLayout.LayoutParams(-1,dp(54)));
        gap(content,10);EditText temp=field("Температура, °C",false);temp.setInputType(8194);content.addView(temp,new LinearLayout.LayoutParams(-1,dp(54)));
        gap(content,12);TextView note=text("Можно подготовить временные интервалы, но сохранение расписания в контроллер пока не включено: в HAR нет подтверждённого метода записи расписания. Значения не будут выдаваться за отправленные на котёл.",13,MUTED,false);note.setPadding(dp(14),dp(14),dp(14),dp(14));note.setBackground(gradient(0xFF183453,0xFF10243F,0xFF2B526F,18));content.addView(note);
        gap(content,14);content.addView(button("Назад",()->{showDashboard();renderDevices(devices);}));
    }
    private void showEquipment(){
        base("equipment");addHeader(content,"Управление оборудованием","Состояния и доступные действия");
        for(int i=0;i<devices.length();i++){JSONObject d=devices.optJSONObject(i);if(d==null)continue;content.addView(deviceCard(d));gap(content,10);}
        TextView note=text("Команды включения/остановки, насосов, горелки и шнека не активированы до проверки точных параметров API и безопасных ограничений конкретного контроллера.",13,MUTED,false);note.setPadding(dp(14),dp(14),dp(14),dp(14));note.setBackground(gradient(0xFF183453,0xFF10243F,0xFF2B526F,18));content.addView(note);
        gap(content,14);content.addView(button("Назад",()->{showDashboard();renderDevices(devices);}));
    }
    private JSONObject parseObject(String s){try{return new JSONObject(s);}catch(Exception e){return null;}}
    private Map<String,Double> parseParams(String s){
        Map<String,Double> m=new HashMap<>();
        // The live API returns params as a JSON array, not as letter-delimited text.
        // Confirmed against the captured get_all_dev response: [45,0,0,40,1,...]
        // where 45 matches the controller's current boiler-water graph (43-48 C).
        try {
            JSONArray a = new JSONArray(s);
            putParam(m, "temp_w", a, 0);
            putParam(m, "temp_w_ust", a, 3);
            putParam(m, "sost_rab", a, 4);
            putParam(m, "temp_w_min", a, 5);
            putParam(m, "vent_on", a, 6);
            putParam(m, "shnek_temp", a, 10);
            putParam(m, "tstatNow", a, 11);
            return m;
        } catch (Exception ignored) { }
        // Compatibility fallback for older server payloads.
        String[][] keys={{"temp_w_ust","a","b"},{"temp_w","d","e"},{"sost_rab","e","f"},
            {"vers","f","g"},{"temp_w_min","F","G"},{"vent_on","G","H"},
            {"shnek_temp","H","I"},{"tstatNow","k","l"}};
        for(String[] k:keys){
            int a=s.indexOf(k[1]), b=s.indexOf(k[2],a+1);
            if(a>=0&&b>a+1){try{m.put(k[0],Double.parseDouble(s.substring(a+1,b)));}catch(Exception ignored){}}
        }
        return m;
    }
    private void putParam(Map<String,Double> out, String key, JSONArray a, int index) {
        if(index < a.length() && !a.isNull(index)) {
            double v = a.optDouble(index, Double.NaN);
            if(!Double.isNaN(v)) out.put(key, v);
        }
    }
    private String stateText(double s){
        if(s==0)return "⏸  Остановлен";
        if(s==1)return "●  Работает";
        if(s>=0)return "◉  Розжиг / угасание";
        return "Состояние не определено";
    }
    private String fmt(double v){return Double.isNaN(v)?"—":String.format(Locale.getDefault(),"%.1f",v);}
    private String safe(String s){return s==null?"неизвестная ошибка":s.replaceAll("[\\r\\n]"," ");}
    @Override public void onBackPressed(){
        if(officialScreen){
            if(officialWebView!=null && officialWebView.canGoBack()) officialWebView.goBack();
            else { officialScreen=false; officialWebView=null; showDashboard(); }
            return;
        }
        if(!homeId.isEmpty()){homeId="";password="";login="";showLogin();}else super.onBackPressed();
    }
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
